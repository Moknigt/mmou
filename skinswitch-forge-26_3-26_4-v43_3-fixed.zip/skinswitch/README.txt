Skin Switch (Forge 26.3) - v43.2
Build:  ./gradlew build   (needs internet + Java 25)  -> build/libs/skinswitch-1.0.0.jar
Put the jar in the mods folder.
Done: skin library + head icons + favourites (star), 3D preview with idle animation, capes panel, cape editor, build-time official cape downloads from capes-sources.txt, up to 50 extra cape textures from the MIT-licensed devvyyxyz/abc-capes GitHub collection, plus your own capes in capes-local/.
Build note: the extra 50-cape collection is fetched during ./gradlew build when internet is available. Invalid images, duplicates and unavailable links are skipped; the build continues with the capes that are available. Official Minecraft cape textures are included as visual textures only; the mod does not grant account entitlements.
Files with API-RISK comments (SkinScreen.java, PixelPainter.java) may need small name fixes for 26.3.

v18: language follows the game language (ar_sa added - Minecraft has no ar_eg; en_us is the fallback), gear button next to
Change Skin on title/pause/options = character side (left/right) + size (title and in-game menus saved separately),
character now also shown on the title screen, new "body proportions" button around the character (head/torso/arms/legs,
width/height/depth, saved in skinswitch/ui.properties), 13 original capes in capes-local/ (42 downloaded + 13 = 55).
Body proportions are shown in the Skin screen preview and the title-screen character; the pause-menu character is the real
player entity and in-world rendering is still part of step 4.

v20: skin applied in game + sharing with friends: your selected skin now shows on YOUR player, and skin + body proportions are shared with
friends who also have Skin Switch (LAN or any server) through hidden chat messages [[ss]] - no server mod needed. Skin takes a few
seconds to arrive (anti-spam throttle). Cape is applied and shared too (first frame if animated). See client/sync/.
v19: body proportions now apply IN GAME to your own player (copied from MySkins): head/torso/arms/legs width/height/depth on the real
model (third person, inventory, pause menu), parts shifted so the body stays connected, name tag follows head height, camera + eye
height follow body height, first-person hand uses the arm scale. Camera/Hand toggles are in the body-proportions panel.
Uses Mixin (src/main/java/com/skinswitch/mixin, skinswitch.mixins.json, [[mixins]] in mods.toml). Client-only: other players don't see it.

v23: animated capes now animate on the player in game (8 fps) and on friends' screens (bundled capes are shared by name, imported ones as pixels,
frames reduced if needed so they arrive faster). 8 new animated original capes in capes-local/ + 2 more official capes in capes-sources.txt.

v24: 6 buttons around the character (capes, body, arm model, armor [locked], held item [locked], animation play/pause).

v25: armor + held item buttons removed in favour of lock signs (they always show automatically, nothing to toggle).

v26: armor + held-item slots are now plain lock icons (no button). The animation button cycles stand -> walk -> run -> paused
(walk/run swing arms and legs, the character turns slightly sideways so the stride is visible). Preview only; title screen stays idle.

v27: faster sharing when you change skins a lot (client/sync/ChatSync.java, PlayerLook.java): (1) a skin/cape that was already fully sent
is not sent again when you switch back to it - friends keep it, only the 1-message header goes out (a new player joining makes everything
resendable); (2) sending is paced by a copy of the server's chat-spam counter: a burst of ~6 messages, then 1 per second, instead of a
flat 1 per 1.25 s; (3) skins/capes with <=256 colours are sent as indexed PNG, chunks are 190 chars, settle time before announcing is ~1 s,
your own "hello" no longer triggers a pointless full resend. If a server kicks you for chat spam, lower SPAM_ALLOW in ChatSync.java.

v28: 10 new animated original capes in capes-local/ (see capes-local/README.txt). 18 animated capes now in total.

v35 (skin editor, step 1 of 3): new "Create Skin" button at the bottom of the skin screen (next to CONFIRM) opens the Skin Editor
(client/SkinEditorScreen.java + data/SkinEditorModel.java). Pick a part (head/body/arms/legs), a layer (Base = the skin, Details = raised
hat/jacket/sleeves/pants), a tool (pencil, eraser [details only], fill, colour picker), brush 1-3, mirror painting, undo/redo, colour picker
(square + hue bar + hex + recent colours), arms wide/slim, live 3D preview (drag to spin). Save writes a new PNG into skinswitch/skins and
selects it. Next: step 2 = cape editor (static cape + elytra auto/manual), step 3 = animated cape frames.

v36 (cape editor, step 2 of 3): in the capes view a "Create Cape" button (above Import/Remove/Done) opens the Cape Editor
(client/CapeEditorScreen.java + data/CapeEditorModel.java). Tabs: Cape (outer/inner/sides/top/bottom) and Elytra (the 24x22 wing at 22,0 of the
same PNG). Elytra Auto = wings are generated from the cape's outer face every time you edit the cape; Manual = paint the wings yourself.
Same tools as the skin editor, 3D preview wearing the cape (drag to spin), Save -> skinswitch/capes/<name>.png and it gets selected.
The model already supports several frames (animated strip 64 x 32n); the frame timeline UI is step 3.

v37 (cape editor, step 2 of 3 - review + fixes): (1) FIX: pressing Undo right after opening the Cape Editor crashed it (the empty start state was
an undo step) - the fresh editor now has no history. (2) The Elytra tab now shows the WINGS on the 3D preview (folded vanilla-style pose, right
wing mirrored) instead of the cape, so you see what you paint. (3) "Elytra: Auto" now builds a real wing shape (outline, feather ribs, tapered
tip) from the cape's outer face, frame by frame, instead of a plain rectangle; same code as the in-game fallback (render/ElytraArt.java).
Tested outside Minecraft: editor model (paint/fill/erase/mirror/undo/redo/frames/auto-manual elytra), save into skinswitch/capes (never
overwrites), reload of static / animated / old 22x17 / HD capes, and the 3D preview renders.

v38 (skin editor review): (1) FIX: the colour picker (hue bar, hex box, recent colours) was cut off at the bottom of the Skin Editor on the normal
GUI sizes (GUI height 240-288 = Auto GUI scale 3/4 on 720p/768p/1080p screens; it needed 302). The left column is now compact (it fits from 240 up)
and Blank / From skin / Arms wide-slim moved to a row above the drawing area. (2) FIX: Undo on a freshly opened Skin Editor turned the base layer
transparent (the grey start skin counted as an undo step) - a fresh editor now has no history. Everything else in the Skin Editor checked out
(paint / mirror / fill / eraser rules / slim arms / opaque base on save / load + undo), tested outside Minecraft.

v41 (Cosmetics, part 1 of 3 - the accessories themselves): 30 purely visual accessories (render/Accessories.java), same pure-Java box style as the pets.
They are fixed to the head / torso / right arm, follow the body proportions and the idle/walk/run poses, and give no abilities and no effects.
Slots stop overlapping pieces (one hat, one face piece, one floating piece, ...; quiver + sword + cape + parrot + dragon... can be worn together).
A pet on the head sits on top of the hat; floating pieces (halo, star, planet, crystal) hover above both.
Saved in skinswitch/ui.properties as  acc=royal_crown,parrot,...  (UiPrefs.accessories / toggleAccessory / clearAccessories).
Shown in the character preview (Skin screen + title/pause screen). To try before the menu exists, add a line to ui.properties, e.g.
    acc=royal_crown,future_glasses,scarf,royal_cape,parrot
Next: part 2 = the menu (Animals | Accessories tabs, preview, equip, remove), part 3 = shown on the real player in game + sent to friends.

v42 (Cosmetics, part 2 of 3 - the menu): new gold "Cosmetics" button next to the star button above the skin list (Skin screen). It opens a panel on the
left (the character slides to the right) with two tabs: ANIMALS | ACCESSORIES (client/SkinScreen.java, data/CosmeticsModel.java, render/CosmeticThumbs.java).
 - Every tile is a close-up picture of YOUR skin wearing that piece. Accessories are grouped by place (Head, Face, Above head, Ear, Neck, Shoulder, Back, Body),
   the Animals tab starts with a "None" tile. Scroll with the mouse wheel. Hover = name + category.
 - PREVIEW: one click puts the piece on the big character without saving anything (the line under the tiles says "Replaces: ..." when it would push off a piece
   in the same slot). EQUIP saves it. REMOVE takes the selected worn piece off, REMOVE ALL clears the tab, DONE closes. Double-click = equip / take off.
 - Several accessories can be worn at once (slots stop overlaps: one hat, one face piece, one back piece, ...). A green tick marks what you wear.
 - Saved per player in skinswitch/ui.properties (acc=..., pet=...). The old "Pet" arrows in the body-proportions panel still work and stay in sync.
 - FIX: 22 animals (horse ... armadillo) had no display name (the raw key was shown) - names added in en_us / ar_sa / ar_eg. New texts for the menu in all 3 languages.
 - PreviewRenderer got an optional fixed-camera overload (used for the thumbnails); normal rendering is unchanged.
Tested outside Minecraft: menu logic (preview not saved, equip, remove, clear, slot conflicts, several pieces together, animals incl. None, double-click),
all 30 + 45 thumbnails render, 30 thumbnails in ~0.2 s. The panel itself (SkinScreen.java) is new code written against the same Minecraft calls the screen already
uses; it type-checks against stubs but has not been run inside the game yet.
Next: part 3 = shown on the real player in the world + sent to friends (ChatSync / PlayerLook).

v43.1 (Accessory visual polish):
 - Worn accessories now receive a soft self-coloured glow shell with a gentle brightness pulse. This is cosmetic rendering only and does not alter light levels or gameplay.
 - Floating head accessories (halo, star, mini planet, floating crystal and geo halo) have a restrained idle bob and slow sway. Pet models and their animation were intentionally left unchanged.

v43 (Cosmetics, part 3 of 3 - in-world rendering + client chat sync):
 - Added the compact hidden chat payload X|uuid|petIndex|accIndexes. The existing A message is unchanged for compatibility; older clients simply ignore X.
 - Cosmetics are stored per remote UUID in PlayerLook.COSMETICS, so they survive entity replacement / respawn. The map is cleared with the other remote look data when the client changes worlds/dimensions.
 - X payload validation rejects the local UUID, malformed/out-of-range indexes, more than 12 accessories, and excessive per-sender message rates. Accessory selections pass through Accessories.normalize().
 - Added a real 26.3 submit-stage renderer through a Mixin immediately before the entity-pose pop in LivingEntityRenderer.submit (the implementation inherited by AvatarRenderer). It builds coloured quads from Accessories.ABox / PetModels.PBox, samples ABox.color() for decals/noise, respects tilted boxes, uses a single white texture, and uses full-bright only for ABox.lit().
 - Geometry is cached by accessory list, slim model, pet and elytra state. Accessories are built with unit proportions and attached through PlayerModel head/body/rightArm transforms, so the existing PlayerModelMixin scales them once rather than baking body scales twice. Pet idle rotations use PetModels.animate(..., mode=0).
 - No cosmetics are submitted for invisible/spectator players or players farther than 48 blocks. Local first-person view suppresses head/face/floating accessories and the pet. Headgear is lifted slightly with a helmet; body geometry is offset slightly with chest equipment; royal_cape is omitted with elytra.
 - Added pure-Java codec tests for X parsing, invalid indexes, the 12-piece cap and Accessories.normalize().
 - Build/game verification status for this handoff: not run successfully in this environment. The bundled wrapper needs Gradle 9.7.1 from the network, network DNS is unavailable, and only Java 21 is installed here (project requires Java 25). Do not treat the build or in-game rendering as verified.

v42b: the Skin screen now has a BLURRED background (the menu / world behind it, like the reference look) with a light dark veil on top.
The blur method of Minecraft's Screen is looked up by name at runtime (SkinScreen.blurBackground); if this version has none it falls back to the old dark
background. It needs Options > Video > "Menu Background Blur" above 0. Not tested in the game yet.


v43.2 (Cape collection + accessory effects):
 - Kept v43.1 accessory glow and floating idle effects.
 - Build now fetches up to 50 additional valid cape textures from the MIT-licensed devvyyxyz/abc-capes GitHub collection, in addition to the existing official Minecraft texture URLs and original capes-local designs.
 - Cape downloads are deduplicated by SHA-256 and checked for Minecraft cape sheet dimensions before being bundled. Network errors and invalid images are skipped without failing the build.
 - Bundled source/attribution notes and upstream MIT license when the community archive is reachable.
 - Official Minecraft cape PNGs are visual copies only; this does not unlock or grant the associated Mojang account cape.
