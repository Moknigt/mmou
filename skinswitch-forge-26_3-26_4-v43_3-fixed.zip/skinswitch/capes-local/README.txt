PNG capes put here are bundled into the mod at build time (no link needed).
The 13 capes here (Crimson Stripe ... Night Stars) are original designs made for Skin Switch.
Format: 64x32 PNG (animated = vertical strip 64 x 32*frames). Drop your own PNGs here and rebuild.

v23: 8 ANIMATED originals (8 frames, 64x256 strips): Aurora Wave, Neon Pulse, Fire Flicker, Rainbow Flow, Matrix Rain, Starfield Twinkle, Ocean Ripple, Electric Storm.
They animate in the Skin screen AND on your player in game, and on friends' screens.

v28: 10 more ANIMATED originals (8 frames, 64x256 strips): Plasma Swirl, Molten Core, Snowfall, Galaxy Spin, Candy Stripe, Firefly Night,
Heartbeat, Golden Shine, Portal Rings, Rainy Day. (Total in this folder: 31 = 21 + 10.)

v31: 10 more ANIMATED originals (8 frames, 64x256 strips): Sakura Drift, Cyber Grid, Lava Lamp, Emerald Flow, Confetti Party,
Thunder Cloud, Ice Crystal, Dragon Scales, Hypno Spiral, Sunrise Waves. (Total in this folder: 41.)
