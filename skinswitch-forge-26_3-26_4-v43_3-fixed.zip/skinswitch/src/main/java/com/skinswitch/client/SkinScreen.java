package com.skinswitch.client;

import com.skinswitch.SkinSwitchMod;
import com.skinswitch.data.*;
import com.skinswitch.render.CapeImage;
import com.skinswitch.render.PreviewRenderer;
import com.skinswitch.render.SkinImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Supplier;

/**
 * Skin screen. Skins view: head grid on the left, character in the centre with buttons around it.
 * Capes view (button "C"): the character slides right and turns its back; on the left a "My Capes" section
 * (None + Import/drop zone + your capes) and a "Downloaded Capes" grid (capes fetched at build time),
 * with Import Cape / Remove Cape / Done at the bottom.
 */
public class SkinScreen extends Screen {
    private static final int BG = 0xCC0E1116, PANEL = 0xFF2B2F38, EDGE = 0xFF8B93A5, SELECT = 0xFF3B8EEA, WHITE = 0xFFFFFFFF, GOLD = 0xFFFFD040;
    private static final int PW = 96, PH = 176, PSCALE = 2;
    private static final int GRID_X = 14, GRID_Y = 56;

    // 1-bit icons ('#' = pixel), drawn on top of the buttons
    private static final String[] I_TRASH = {"...###...", "#########", ".#######.", ".#.#.#.#.", ".#.#.#.#.", ".#.#.#.#.", ".#######."};
    private static final String[] I_SORT = {"#########", ".........", "#######..", ".........", "#####...."};
    private static final String[] I_CAPE = {"..#####..", "..#...#..", ".#######.", ".#######.", ".#######.", ".#######.", "#########", "#########"};
    private static final String[] I_DOWN = {"....#....", "....#....", "..#.#.#..", "...###...", "....#....", ".........", "#.......#", "#########"};
    private static final String[] I_WIDE = {"....###....", "....###....", "###########", "###########", "###########", "...##.##...", "...##.##..."};
    private static final String[] I_SLIM = {"....###....", "....###....", ".#########.", ".#########.", ".#########.", "...##.##...", "...##.##..."};
    private static final String[] I_PENCIL = {"......##.", ".....####", "....###.#", "...###.#.", "..###.#..", ".###.#...", "####.#...", "####.....", "###......"};
    private static final String[] I_CHECK = {"........#", ".......##", "......##.", "#....##..", "##..##...", ".####....", "..##....."};
    private static final String[] I_LOCK = {"..#####..", ".#.....#.", ".#.....#.", "#########", "#########", "####.####", "####.####", "#########"};
    private static final String[] I_ARMOR = {"#########", "#.#####.#", "#.#####.#", ".#######.", ".#######.", "..#####..", "...###..."};
    private static final String[] I_HELD = {"......###", ".....###.", "....###..", "#..###...", ".####....", "..##.....", ".#.##....", "#.....##."};
    private static final String[] I_PLAY = {"##.......", "####.....", "######...", "########.", "######...", "####.....", "##......."};
    private static final String[] I_PAUSE = {"###..###", "###..###", "###..###", "###..###", "###..###", "###..###", "###..###"};
    private static final String[] I_IDLE = {"..###..", "..###..", ".#####.", ".#####.", ".#####.", "..#.#..", "..#.#..", "..#.#.."};
    private static final String[] I_WALK = {"...###...", "...###...", "..#####..", "..#####..", "..#####..", "..##.##..", ".##...##.", ".#.....#."};
    private static final String[] I_RUN = {"....###..", "....###..", "..######.", ".#.####..", "#..####..", "...##.##.", "..##...#.", ".##....##"};
    private static final int[] RING_DX = {-78, -86, -78, 78, 86, 78}, RING_DY = {-70, -10, 50, -70, -10, 50};
    private static final String[] I_BODY = {"..#####..", "..#####..", "..#####..", ".#######.", "#.#####.#", "#.#####.#", "..##.##..", "..##.##.."};
    private record IconBtn(Button b, Supplier<String[]> rows, int scale) {}
    private final List<IconBtn> icons = new ArrayList<>();
    private final List<Integer> ringSlots = new ArrayList<>();

    private static void drawIcon(GuiGraphicsExtractor g, String[] rows, int cx, int cy, int scale, int color) {
        int w = rows[0].length() * scale, h = rows.length * scale, x0 = cx - w / 2, y0 = cy - h / 2;
        for (int r = 0; r < rows.length; r++)
            for (int c = 0; c < rows[r].length(); c++)
                if (rows[r].charAt(c) == '#') g.fill(x0 + c * scale, y0 + r * scale, x0 + (c + 1) * scale, y0 + (r + 1) * scale, color);
    }

    /** Corner brackets like the reference drop zones. */
    private static void brackets(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int len, int color) {
        g.fill(x0, y0, x0 + len, y0 + 2, color); g.fill(x0, y0, x0 + 2, y0 + len, color);
        g.fill(x1 - len, y0, x1, y0 + 2, color); g.fill(x1 - 2, y0, x1, y0 + len, color);
        g.fill(x0, y1 - 2, x0 + len, y1, color); g.fill(x0, y1 - len, x0 + 2, y1, color);
        g.fill(x1 - len, y1 - 2, x1, y1, color); g.fill(x1 - 2, y1 - len, x1, y1, color);
    }

    private static void dashed(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int color) {
        for (int x = x0; x < x1; x += 4) { int e = Math.min(x + 2, x1); g.fill(x, y0, e, y0 + 1, color); g.fill(x, y1 - 1, e, y1, color); }
        for (int y = y0; y < y1; y += 4) { int e = Math.min(y + 2, y1); g.fill(x0, y, x0 + 1, e, color); g.fill(x1 - 1, y, x1, e, color); }
    }

    private int dropH() { return Math.max(60, height - 14 - (GRID_Y + model.gridHeight() + 10)); }

    private final Screen parent;
    private final SkinLibrary skins;
    private final SkinScreenModel model;
    private final CapeLibrary capes;
    private final Map<String, SkinImage> skinCache = new HashMap<>();
    private final Map<String, int[]> headCache = new HashMap<>();

    private EditBox nameBox;
    private Button nameBtn;
    private boolean editingName;
    private final List<Button> ring = new ArrayList<>();
    private final List<Button> skinWidgets = new ArrayList<>(), capeWidgets = new ArrayList<>();
    private boolean capeMode, bodyMode;
    private int animMode;      // 0 = stand, 1 = walk, 2 = run, 3 = paused
    private float walkYaw;     // turns the character a bit to the side while walking / running so the stride is visible
    private int panelKind; // which side panel is (or was last) open: 1 = capes, 2 = body proportions
    private float capeT, turnT;
    private int bodyPart = UiPrefs.HEAD;
    private final List<net.minecraft.client.gui.components.AbstractWidget> bodyWidgets = new ArrayList<>();
    private final Button[] tabs = new Button[4];
    private final PrefSlider[] sliders = new PrefSlider[3];
    private static final String[] PART_KEYS = {"head", "torso", "arms", "legs"}, AXIS_KEYS = {"width", "height", "depth"};
    private long lastNanos = System.nanoTime();
    private float time;
    private int scroll;
    private CapeEntry pendingCape;
    private boolean capeDirty;
    private Button armsButton;
    private Boolean lastSlim;
    private int hoverX, hoverY;
    // drag-to-rotate the character
    private boolean dragging;
    private float dragYaw, swayFactor = 1f;

    // cape-view layout (recomputed every frame, cheap)
    private record Cell(int kind, CapeEntry cape, int x, int y, int w, int h) {} // kind: 0 none, 1 import zone, 2 cape
    private record Header(Component title, int count, int y) {}
    private final List<Cell> cells = new ArrayList<>();
    private final List<Header> headers = new ArrayList<>();
    private int contentHeight, panelX0, panelX1;

    // cosmetics view (button "Cosmetics" above the skin list): tabs Animals | Accessories, preview, equip, remove
    private record CosCell(int kind, String id, int x, int y, int w, int h) {} // kind: 0 = None tile, 1 = animal, 2 = accessory
    private record CosHeader(String category, int y) {}
    private static final int COS_TOP = 52;
    private boolean cosMode;
    private final List<Button> cosWidgets = new ArrayList<>();
    private final Button[] cosTabs = new Button[2];
    private Button equipBtn, removeBtn, clearBtn;
    private CosmeticsModel cos;
    private final com.skinswitch.render.CosmeticThumbs thumbs = new com.skinswitch.render.CosmeticThumbs();
    private final List<CosCell> cosCells = new ArrayList<>();
    private final List<CosHeader> cosHeaders = new ArrayList<>();
    private int cosContentHeight, cosScroll;

    /** Connects the Cosmetics menu to the saved choices (ui.properties). */
    private static CosmeticsModel.Store prefsStore() {
        return new CosmeticsModel.Store() {
            public String pet() { return UiPrefs.get().pet(); }
            public void setPet(String id) { UiPrefs.get().setPet(id); }
            public List<String> accessories() { return UiPrefs.get().accessories(); }
            public void setAccessories(List<String> ids) { UiPrefs.get().setAccessories(ids); }
        };
    }

    public SkinScreen(Screen parent) {
        super(Component.translatable("skinswitch.button.change_skin"));
        this.parent = parent;
        Path root = Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch");
        skins = new SkinLibrary(root);
        capes = new CapeLibrary(root);
        try { skins.load(); capes.load(); } catch (IOException e) { SkinSwitchMod.LOGGER.error("Cannot load library", e); }
        model = new SkinScreenModel(skins);
        pendingCape = capes.selected();
        cos = new CosmeticsModel(prefsStore());
    }

    @Override
    protected void init() {
        skinWidgets.clear(); capeWidgets.clear(); bodyWidgets.clear(); cosWidgets.clear(); ring.clear(); icons.clear(); ringSlots.clear();
        // display name over the character: text + pencil; the pencil turns the text into an edit box (name your friends see over your head)
        nameBox = new EditBox(font, width / 2 - 70, 36, 140, 18, Component.translatable("skinswitch.name.hint"));
        nameBox.setHint(Component.translatable("skinswitch.name.hint"));
        nameBox.setMaxLength(UiPrefs.NAME_MAX);
        nameBox.visible = false;
        addRenderableWidget(nameBox);
        nameBtn = add(Button.builder(Component.empty(), b -> toggleNameEdit()).bounds(width / 2 + 40, 36, 18, 18)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.name.edit")
                .append(Component.literal("\n")).append(Component.translatable("skinswitch.name.edit.desc").withStyle(net.minecraft.ChatFormatting.GRAY)))).build());
        skinWidgets.add(nameBtn);
        icons.add(new IconBtn(nameBtn, () -> editingName ? I_CHECK : I_PENCIL, 1));
        Button del = add(Button.builder(Component.empty(), b -> run(model::deleteSelected)).bounds(14, 30, 20, 20).build());
        Button sort = add(Button.builder(Component.empty(), b -> model.toggleSort()).bounds(38, 30, 20, 20).build());
        skinWidgets.add(del); skinWidgets.add(sort);
        icons.add(new IconBtn(del, () -> I_TRASH, 1)); icons.add(new IconBtn(sort, () -> I_SORT, 1));
        skinWidgets.add(add(Button.builder(Component.literal("★"), b -> run(model::toggleFavoriteSelected)).bounds(62, 30, 20, 20).build()));
        // "Cosmetics": opens the panel with the tabs Animals | Accessories
        skinWidgets.add(add(Button.builder(Component.translatable("skinswitch.acc.title").withStyle(net.minecraft.ChatFormatting.GOLD), b -> openCosmetics())
            .bounds(86, 30, 4 * (SkinScreenModel.SLOT + SkinScreenModel.GAP) - SkinScreenModel.GAP - 72, 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.acc.open.tip"))).build()));
        skinWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.confirm"), b -> {
            run(model::confirm);
            if (capeDirty) run(() -> capes.select(pendingCape));
            onClose();
        }).bounds(width / 2 - 100, height - 30, 200, 20).build()));

        // "Create Skin": opens the skin editor (paint a skin yourself: colours + raised details)
        skinWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.create_skin"), b -> openEditor())
            .bounds(width / 2 + 104, height - 30, Math.max(60, Math.min(130, width - (width / 2 + 104) - 6)), 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.screen.create_skin.desc"))).build()));

        Button capesBtn = ringButton(0, b -> { capeMode = !capeMode; bodyMode = false; cosMode = false; panelKind = 1; dragYaw = 0; });
        capesBtn.setTooltip(Tooltip.create(Component.translatable("skinswitch.tip.capes")));
        icons.add(new IconBtn(capesBtn, () -> I_CAPE, 2));
        Button bodyBtn = ringButton(1, b -> { bodyMode = !bodyMode; capeMode = false; cosMode = false; panelKind = 2; dragYaw = 0; });
        bodyBtn.setTooltip(Tooltip.create(Component.translatable("skinswitch.tip.body")
            .append(Component.literal("\n")).append(Component.translatable("skinswitch.tip.body.desc").withStyle(net.minecraft.ChatFormatting.GRAY))));
        icons.add(new IconBtn(bodyBtn, () -> I_BODY, 2));
        armsButton = ringButton(3, b -> run(model::toggleSlimSelected));
        armsButton.setTooltip(Tooltip.create(Component.translatable("skinswitch.tip.arms")));
        icons.add(new IconBtn(armsButton, () -> model.selected() != null && model.selected().slim() ? I_SLIM : I_WIDE, 2));
        // armor + held item are shown automatically: slots 2 and 4 are just a plain lock icon (no button, no tooltip), drawn in extractRenderState
        // 6th button: cycles the preview animation  stand -> walk -> run -> paused
        Button animBtn = ringButton(5, b -> { animMode = (animMode + 1) % 4; b.setTooltip(animTip()); });
        animBtn.setTooltip(animTip());
        icons.add(new IconBtn(animBtn, () -> animMode == 0 ? I_IDLE : animMode == 1 ? I_WALK : animMode == 2 ? I_RUN : I_PLAY, 2));

        // capes view bottom row: Import Cape | Remove Cape | star | Done
        panelX0 = 14; panelX1 = (int) (width * 0.58f);
        int bw = (panelX1 - panelX0 - 24 - 12) / 3, y = height - 28;
        // "Create Cape": opens the cape editor (cape + elytra)
        capeWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.create_cape"), b -> openCapeEditor())
            .bounds(panelX0, y - 24, panelX1 - panelX0, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.screen.create_cape.desc"))).build()));
        capeWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.import_cape"), b -> pickFiles(true)).bounds(panelX0, y, bw, 20).build()));
        capeWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.remove_cape"), b -> { pendingCape = null; capeDirty = true; }).bounds(panelX0 + bw + 4, y, bw, 20).build()));
        capeWidgets.add(add(Button.builder(Component.literal("★"), b -> toggleCapeFavorite()).bounds(panelX0 + 2 * bw + 8, y, 20, 20).build()));
        capeWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.done").withStyle(net.minecraft.ChatFormatting.GREEN), b -> {
            if (capeDirty) run(() -> capes.select(pendingCape));
            capeMode = false;
        }).bounds(panelX0 + 2 * bw + 8 + 24, y, bw, 20).build()));

        // body view: part tabs (Head / Torso / Arms / Legs), width / height / depth sliders, reset + done
        UiPrefs prefs = UiPrefs.get();
        int pw = panelX1 - panelX0, tabW = (pw - 12) / 4;
        for (int i = 0; i < 4; i++) {
            final int part = i;
            tabs[i] = add(Button.builder(tabLabel(i), b -> selectPart(part)).bounds(panelX0 + i * (tabW + 4), 48, tabW, 20).build());
            bodyWidgets.add(tabs[i]);
        }
        for (int a = 0; a < 3; a++) {
            final int axis = a;
            sliders[a] = new PrefSlider(panelX0, 82 + a * 28, pw, 20, Component.translatable("skinswitch.slider." + AXIS_KEYS[a]),
                UiPrefs.MIN_PART, UiPrefs.MAX_PART, prefs.scale(bodyPart, a), v -> UiPrefs.get().setScale(bodyPart, axis, (float) v));
            bodyWidgets.add(addRenderableWidget(sliders[a]));
        }
        int half = (pw - 4) / 2, ty = 82 + 3 * 28;
        bodyWidgets.add(add(Button.builder(onOff("skinswitch.body.camera", prefs.cameraFollows()), b -> {
            prefs.setCameraFollows(!prefs.cameraFollows()); b.setMessage(onOff("skinswitch.body.camera", prefs.cameraFollows()));
        }).bounds(panelX0, ty, half, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.body.camera.desc"))).build()));
        bodyWidgets.add(add(Button.builder(onOff("skinswitch.body.hand", prefs.scaleHand()), b -> {
            prefs.setScaleHand(!prefs.scaleHand()); b.setMessage(onOff("skinswitch.body.hand", prefs.scaleHand()));
        }).bounds(panelX0 + half + 4, ty, half, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.body.hand.desc"))).build()));
        int py = ty + 24;
        bodyWidgets.add(add(Button.builder(Component.literal("<"), b -> { prefs.cyclePet(-1); petBtn.setMessage(petLabel()); }).bounds(panelX0, py, 20, 20).build()));
        petBtn = add(Button.builder(petLabel(), b -> { prefs.cyclePet(1); b.setMessage(petLabel()); })
            .bounds(panelX0 + 24, py, pw - 48, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.pet.desc"))).build());
        bodyWidgets.add(petBtn);
        bodyWidgets.add(add(Button.builder(Component.literal(">"), b -> { prefs.cyclePet(1); petBtn.setMessage(petLabel()); }).bounds(panelX0 + pw - 20, py, 20, 20).build()));
        int b3 = (pw - 8) / 3;
        bodyWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.reset_part"), b -> { UiPrefs.get().resetPart(bodyPart); syncSliders(); })
            .bounds(panelX0, y, b3, 20).build()));
        bodyWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.reset_all"), b -> { UiPrefs.get().resetAllParts(); syncSliders(); })
            .bounds(panelX0 + b3 + 4, y, b3, 20).build()));
        bodyWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.done").withStyle(net.minecraft.ChatFormatting.GREEN), b -> bodyMode = false)
            .bounds(panelX0 + 2 * (b3 + 4), y, b3, 20).build()));

        // cosmetics view: tabs (Animals | Accessories) on top, tiles in the middle, Equip | Remove | Remove all | Done at the bottom
        int tabHalf = (pw - 4) / 2;
        for (int i = 0; i < 2; i++) {
            final int t = i;
            cosTabs[i] = add(Button.builder(cosTabLabel(i), b -> selectCosTab(t)).bounds(panelX0 + i * (tabHalf + 4), 26, tabHalf, 20).build());
            cosWidgets.add(cosTabs[i]);
        }
        int cw = (pw - 12) / 4;
        equipBtn = add(Button.builder(Component.translatable("skinswitch.acc.equip").withStyle(net.minecraft.ChatFormatting.GREEN), b -> cos.equip()).bounds(panelX0, y, cw, 20).build());
        removeBtn = add(Button.builder(Component.translatable("skinswitch.acc.remove"), b -> cos.remove()).bounds(panelX0 + (cw + 4), y, cw, 20).build());
        clearBtn = add(Button.builder(Component.translatable("skinswitch.acc.clear"), b -> cos.clear())
            .bounds(panelX0 + 2 * (cw + 4), y, cw, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.acc.clear.tip"))).build());
        cosWidgets.add(equipBtn); cosWidgets.add(removeBtn); cosWidgets.add(clearBtn);
        cosWidgets.add(add(Button.builder(Component.translatable("skinswitch.screen.done").withStyle(net.minecraft.ChatFormatting.GREEN), b -> cosMode = false)
            .bounds(panelX0 + 3 * (cw + 4), y, cw, 20).build()));
    }

    // ---- cosmetics panel -------------------------------------------------------------------------------------------------
    private void openCosmetics() {
        boolean open = !cosMode;
        cosMode = open; capeMode = false; bodyMode = false; panelKind = 3; dragYaw = 0; cosScroll = 0;
        if (open) { int tab = cos.tab(); cos = new CosmeticsModel(prefsStore()); cos.setTab(tab); refreshCosTabs(); }
    }

    private Component cosTabLabel(int i) {
        return Component.translatable(i == CosmeticsModel.ANIMALS ? "skinswitch.acc.tab.animals" : "skinswitch.acc.tab.items")
            .withStyle(cos != null && i == cos.tab() ? net.minecraft.ChatFormatting.GOLD : net.minecraft.ChatFormatting.WHITE);
    }

    private void refreshCosTabs() { for (int i = 0; i < 2; i++) if (cosTabs[i] != null) cosTabs[i].setMessage(cosTabLabel(i)); }

    private void selectCosTab(int t) { cos.setTab(t); cosScroll = 0; refreshCosTabs(); }

    private int cosBottom() { return height - 58; }
    private int cosScreenY(int y) { return COS_TOP + y - cosScroll; }
    private boolean cosVisible(int sy, int h) { return sy >= COS_TOP - 2 && sy + h <= cosBottom(); }

    private void layoutCos() {
        cosCells.clear(); cosHeaders.clear();
        int pw = panelX1 - panelX0;
        int cols = Math.max(3, Math.min(8, (pw - 10 + GAP) / (44 + GAP)));
        int tw = (pw - 10 - (cols - 1) * GAP) / cols, th = tw, y = 0;
        if (cos.tab() == CosmeticsModel.ANIMALS) {
            List<String> pets = CosmeticsModel.animals();
            cosCells.add(new CosCell(0, null, panelX0, y, tw, th));
            for (int i = 0; i < pets.size(); i++) {
                int slot = i + 1;
                cosCells.add(new CosCell(1, pets.get(i), panelX0 + (slot % cols) * (tw + GAP), y + (slot / cols) * (th + GAP), tw, th));
            }
            y += ((pets.size() + 1 + cols - 1) / cols) * (th + GAP);
        } else {
            for (String cat : CosmeticsModel.CATEGORIES) {
                List<String> ids = CosmeticsModel.itemsOf(cat);
                if (ids.isEmpty()) continue;
                cosHeaders.add(new CosHeader(cat, y)); y += 16;
                for (int i = 0; i < ids.size(); i++)
                    cosCells.add(new CosCell(2, ids.get(i), panelX0 + (i % cols) * (tw + GAP), y + (i / cols) * (th + GAP), tw, th));
                y += ((ids.size() + cols - 1) / cols) * (th + GAP) + 4;
            }
        }
        cosContentHeight = y;
        cosScroll = Math.max(0, Math.min(cosScroll, cosContentHeight - (cosBottom() - COS_TOP)));
    }

    private String cosName(CosCell c) {
        return c.kind() == 0 ? Component.translatable("skinswitch.pet.none").getString()
            : Component.translatable(c.kind() == 1 ? "skinswitch.pet." + c.id() : "skinswitch.acc." + c.id()).getString();
    }

    private void drawCos(GuiGraphicsExtractor g) {
        g.fill(panelX0 - 6, 8, panelX1 + 6, height - 6, 0x55000000);
        g.text(font, Component.translatable("skinswitch.acc.title"), panelX0, 14, WHITE, true);
        equipBtn.active = cos.canEquip(); removeBtn.active = cos.canRemove(); clearBtn.active = cos.canClear();
        int active = cos.tab();
        int tabHalf = (panelX1 - panelX0 - 4) / 2;
        g.fill(panelX0 + active * (tabHalf + 4), 47, panelX0 + active * (tabHalf + 4) + tabHalf, 49, GOLD); // underline of the open tab

        SkinEntry cur = model.selected();
        SkinImage skin = skinImage(cur);
        boolean slim = cur != null && cur.slim();
        if (cur != null) thumbs.setSkin(cur.id() + "@" + cur.file().toFile().lastModified() + (slim ? "s" : "w"));
        thumbs.beginFrame();

        for (CosHeader h : cosHeaders) {
            int sy = cosScreenY(h.y());
            if (!cosVisible(sy, 12)) continue;
            Component title = Component.translatable("skinswitch.acc.cat." + h.category());
            int n = CosmeticsModel.itemsOf(h.category()).size();
            String ns = Integer.toString(n);
            g.text(font, title, panelX0, sy, WHITE, true);
            g.text(font, Component.literal(ns), panelX1 - font.width(ns), sy, 0xFFAAAAAA, false);
            g.fill(panelX0 + font.width(title) + 6, sy + 4, panelX1 - font.width(ns) - 6, sy + 5, 0x55FFFFFF);
        }
        for (CosCell c : cosCells) {
            int sy = cosScreenY(c.y());
            if (!cosVisible(sy, c.h())) continue;
            boolean worn = c.kind() == 0 ? cos.wornPet() == null : c.kind() == 1 ? cos.isWornPet(c.id()) : cos.isWornItem(c.id());
            boolean sel = c.kind() == 0 ? cos.noneSelected() : c.kind() == 1 ? c.id().equals(cos.selectedAnimal()) : c.id().equals(cos.selectedItem());
            g.fill(c.x() - 2, sy - 2, c.x() + c.w() + 2, sy + c.h() + 2, sel ? SELECT : worn && c.kind() != 0 ? 0xFF55DD66 : EDGE);
            g.fill(c.x(), sy, c.x() + c.w(), sy + c.h(), sel ? 0xFF55678C : PANEL);
            if (c.kind() == 0) {
                dashed(g, c.x() + 4, sy + 4, c.x() + c.w() - 4, sy + c.h() - 4, 0xAAFFFFFF);
                g.centeredText(font, Component.translatable("skinswitch.pet.none"), c.x() + c.w() / 2, sy + c.h() / 2 - 4, WHITE);
                continue;
            }
            int[] px = skin == null ? null : c.kind() == 1 ? thumbs.animal(skin, slim, c.id()) : thumbs.item(skin, slim, c.id());
            if (px != null) {
                int s = Math.max(1, Math.min((c.w() - 2) / com.skinswitch.render.CosmeticThumbs.SIZE, (c.h() - 2) / com.skinswitch.render.CosmeticThumbs.SIZE));
                int sz = com.skinswitch.render.CosmeticThumbs.SIZE * s;
                PixelPainter.draw(g, px, com.skinswitch.render.CosmeticThumbs.SIZE, com.skinswitch.render.CosmeticThumbs.SIZE, c.x() + (c.w() - sz) / 2, sy + (c.h() - sz) / 2, s);
            } else g.centeredText(font, Component.literal("..."), c.x() + c.w() / 2, sy + c.h() / 2 - 4, 0xFF8890A0);
            if (worn) { // small green tick in the corner = equipped
                g.fill(c.x() + c.w() - 11, sy + 1, c.x() + c.w() - 1, sy + 10, 0xCC10301A);
                drawIcon(g, I_CHECK, c.x() + c.w() - 6, sy + 5, 1, 0xFF55FF77);
            }
        }
        if (cosCells.isEmpty()) g.text(font, Component.translatable("skinswitch.acc.pick"), panelX0, COS_TOP + 4, 0xFFAAAAAA, false);

        // status line above the buttons: what is selected + what happens
        String id = cos.selectedId();
        Component l1, l2;
        if (id == null && !cos.noneSelected()) { l1 = Component.translatable("skinswitch.acc.pick").withStyle(net.minecraft.ChatFormatting.GRAY); l2 = Component.empty(); }
        else {
            String nm = id == null ? Component.translatable("skinswitch.pet.none").getString()
                : Component.translatable(cos.tab() == CosmeticsModel.ANIMALS ? "skinswitch.pet." + id : "skinswitch.acc." + id).getString();
            l1 = Component.literal(nm).withStyle(net.minecraft.ChatFormatting.GOLD);
            if (cos.selectedWorn()) l2 = Component.translatable("skinswitch.acc.worn").withStyle(net.minecraft.ChatFormatting.GREEN);
            else if (id == null) l2 = Component.translatable("skinswitch.acc.none.tip").withStyle(net.minecraft.ChatFormatting.GRAY);
            else {
                List<String> rep = cos.replacedBySelection();
                StringBuilder sb = new StringBuilder();
                for (String r : rep) { if (sb.length() > 0) sb.append(", "); sb.append(Component.translatable("skinswitch.acc." + r).getString()); }
                l2 = rep.isEmpty() ? Component.translatable("skinswitch.acc.preview").withStyle(net.minecraft.ChatFormatting.AQUA)
                                   : Component.translatable("skinswitch.acc.replaces", sb.toString()).withStyle(net.minecraft.ChatFormatting.YELLOW);
            }
        }
        g.text(font, l1, panelX0, height - 54, WHITE, true);
        g.text(font, l2, panelX0, height - 43, WHITE, true);
    }

    /** Hover tooltip on a tile: name, kind / category, equipped, hint. */
    private void drawCosTooltip(GuiGraphicsExtractor g) {
        for (CosCell c : cosCells) {
            int sy = cosScreenY(c.y());
            if (!cosVisible(sy, c.h()) || hoverX < c.x() || hoverX >= c.x() + c.w() || hoverY < sy || hoverY >= sy + c.h()) continue;
            List<Component> lines = new ArrayList<>();
            lines.add(Component.literal(cosName(c)).withStyle(net.minecraft.ChatFormatting.GOLD, net.minecraft.ChatFormatting.BOLD));
            if (c.kind() == 2) lines.add(Component.translatable("skinswitch.acc.cat." + com.skinswitch.render.Accessories.category(c.id())).withStyle(net.minecraft.ChatFormatting.GRAY));
            boolean worn = c.kind() == 0 ? cos.wornPet() == null : c.kind() == 1 ? cos.isWornPet(c.id()) : cos.isWornItem(c.id());
            if (worn && c.kind() != 0) lines.add(Component.translatable("skinswitch.acc.worn").withStyle(net.minecraft.ChatFormatting.GREEN));
            lines.add(Component.translatable("skinswitch.acc.click").withStyle(net.minecraft.ChatFormatting.ITALIC, net.minecraft.ChatFormatting.DARK_PURPLE));
            int tw = 0;
            for (Component l : lines) tw = Math.max(tw, font.width(l));
            int bw = tw + 10, bh = lines.size() * 11 + 6;
            int bx = Math.min(hoverX + 12, width - bw - 2), by = Math.min(hoverY - 4, height - bh - 2);
            g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF5A2FC8);
            g.fill(bx, by, bx + bw, by + bh, 0xF0160A2E);
            for (int i = 0; i < lines.size(); i++) g.text(font, lines.get(i), bx + 5, by + 4 + i * 11, WHITE, true);
            return;
        }
    }

    /** Opens the skin editor; the saved skin lands in the library and gets selected here. */
    private void openEditor() {
        SkinEntry cur = model.selected();
        SkinImage si = cur == null ? null : skinImage(cur);
        minecraft.setScreen(new SkinEditorScreen(this, si == null ? null : si.toClassic64(), cur != null && cur.slim(), id -> {
            run(skins::load);
            skinCache.clear(); headCache.clear();
            model.refresh();
            selectById(id);
        }));
    }

    /** Opens the cape editor; the saved cape lands in the capes folder and becomes the selected cape here. */
    private void openCapeEditor() {
        SkinEntry cur = model.selected();
        SkinImage si = cur == null ? null : skinImage(cur);
        CapeImage ci = capes.image(pendingCape);
        minecraft.setScreen(new CapeEditorScreen(this, si == null ? null : si.toClassic64(), cur != null && cur.slim(), ci == null ? null : ci.toClassic(), id -> {
            run(capes::load);
            pendingCape = capes.capes().stream().filter(c -> c.id().equals(id)).findFirst().orElse(null);
            capeDirty = true;
        }));
    }

    private Button petBtn;

    private static Component petLabel() {
        String id = UiPrefs.get().pet();
        return Component.translatable("skinswitch.pet.label").append(Component.literal(": "))
            .append(Component.translatable(id == null ? "skinswitch.pet.none" : "skinswitch.pet." + id));
    }

    private static Component onOff(String key, boolean on) {
        return Component.translatable(key).append(Component.literal(": ")).append(Component.translatable(on ? "skinswitch.body.on" : "skinswitch.body.off"));
    }

    private Tooltip animTip() {
        String[] names = {"skinswitch.anim.idle", "skinswitch.anim.walk", "skinswitch.anim.run", "skinswitch.anim.paused"};
        return Tooltip.create(Component.translatable("skinswitch.tip.anim").append(Component.literal(": "))
            .append(Component.translatable(names[animMode]))
            .append(Component.literal("\n")).append(Component.translatable("skinswitch.tip.anim.desc").withStyle(net.minecraft.ChatFormatting.GRAY)));
    }

    private Component tabLabel(int i) {
        return Component.translatable("skinswitch.part." + PART_KEYS[i])
            .withStyle(i == bodyPart ? net.minecraft.ChatFormatting.GOLD : net.minecraft.ChatFormatting.WHITE);
    }

    private void selectPart(int part) {
        bodyPart = part;
        for (int i = 0; i < 4; i++) if (tabs[i] != null) tabs[i].setMessage(tabLabel(i));
        syncSliders();
    }

    private void syncSliders() {
        for (int a = 0; a < 3; a++) if (sliders[a] != null) sliders[a].setCurrent(UiPrefs.get().scale(bodyPart, a));
    }

    private Button add(Button b) { return addRenderableWidget(b); }
    private Button ringButton(int slot, Button.OnPress press) {
        Button b = add(Button.builder(Component.empty(), press).bounds(0, 0, 26, 26).build());
        ring.add(b); ringSlots.add(slot);
        return b;
    }

    private interface IoAction { void run() throws IOException; }
    private void run(IoAction a) { try { a.run(); } catch (IOException e) { SkinSwitchMod.LOGGER.error("Action failed", e); } }

    private void toggleCapeFavorite() {
        if (pendingCape == null) return;
        String id = pendingCape.id();
        run(() -> capes.toggleFavorite(pendingCape));
        pendingCape = capes.capes().stream().filter(c -> c.id().equals(id)).findFirst().orElse(null);
    }

    // ---- helpers -------------------------------------------------------------------------------------------------
    private SkinImage skinImage(SkinEntry e) {
        if (e == null) return null;
        return skinCache.computeIfAbsent(e.id() + "@" + e.file().toFile().lastModified(), k -> {
            try { return SkinImage.load(e.file()); } catch (IOException ex) { return null; }
        });
    }
    private int[] head(SkinEntry e) {
        SkinImage img = skinImage(e);
        return img == null ? null : headCache.computeIfAbsent(e.id() + "@" + e.file().toFile().lastModified(), k -> img.headIcon());
    }
    private float ease(float t) { return t * t * (3 - 2 * t); }
    // ---- display name (pencil) -----------------------------------------------------------------------------------
    private String shownName() {
        String n = UiPrefs.get().displayName();
        return n != null ? n : minecraft.getUser().getName();
    }

    private void positionNameRow() {
        if (nameBtn == null) return;
        int cx = width / 2;
        nameBtn.setX(editingName ? cx + 70 + 4 : cx + font.width(shownName()) / 2 + 6);
        nameBtn.setY(editingName ? 36 : 38);
    }

    private void toggleNameEdit() {
        if (editingName) { commitName(); return; }
        editingName = true;
        String cur = UiPrefs.get().displayName();
        nameBox.setValue(cur == null ? "" : cur);
        nameBox.visible = true;
        setFocused(nameBox);
    }

    /** Saves the typed name (empty = go back to your normal name); ChatSync sends it to friends a moment later. */
    private void commitName() {
        if (!editingName) return;
        editingName = false;
        UiPrefs.get().setDisplayName(nameBox.getValue());
        nameBox.visible = false;
    }

    private int previewCenterX() { return Math.round(width / 2f + ease(capeT) * width * 0.28f); }

    // ---- cape layout ---------------------------------------------------------------------------------------------
    private static final int COLS = 5, GAP = 8, CAPE_TOP = 34;

    private void layoutCapes() {
        cells.clear(); headers.clear();
        int pw = panelX1 - panelX0;
        int tw = (pw - 10 - (COLS - 1) * GAP) / COLS, th = Math.round(tw * 1.45f);
        List<CapeEntry> mine = new ArrayList<>(), pack = new ArrayList<>();
        for (CapeEntry c : capes.capes()) (c.resource() == null ? mine : pack).add(c);

        int y = 0;
        headers.add(new Header(Component.translatable("skinswitch.screen.my_capes"), mine.size(), y)); y += 16;
        cells.add(new Cell(0, null, panelX0, y, tw, th));
        cells.add(new Cell(1, null, panelX0 + tw + GAP, y, pw - 10 - tw - GAP, th));
        y += th + GAP;
        y = addGrid(mine, y, tw, th);
        y += 6;
        headers.add(new Header(Component.translatable("skinswitch.screen.downloaded_capes"), pack.size(), y)); y += 16;
        y = addGrid(pack, y, tw, th);
        contentHeight = y;
    }

    private int addGrid(List<CapeEntry> list, int y, int tw, int th) {
        for (int i = 0; i < list.size(); i++)
            cells.add(new Cell(2, list.get(i), panelX0 + (i % COLS) * (tw + GAP), y + (i / COLS) * (th + GAP), tw, th));
        return y + ((list.size() + COLS - 1) / COLS) * (th + GAP);
    }

    private int viewBottom() { return height - 58; }
    private int screenY(int y) { return CAPE_TOP + y - scroll; }
    private boolean fullyVisible(int sy, int h) { return sy >= CAPE_TOP - 2 && sy + h <= viewBottom(); }

    // ---- rendering -----------------------------------------------------------------------------------------------
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) { // API-RISK: name/signature in 26.3
        long now = System.nanoTime();
        float dt = (now - lastNanos) / 1e9f; lastNanos = now; time += animMode != 3 ? dt : 0f;
        walkYaw += ((animMode == 1 || animMode == 2 ? 32f : 0f) - walkYaw) * Math.min(1f, dt * 4f);
        capeT = Math.max(0, Math.min(1, capeT + (capeMode || bodyMode || cosMode ? dt : -dt) * 3.2f));
        turnT = Math.max(0, Math.min(1, turnT + (capeMode ? dt : -dt) * 3.2f)); // only the capes view turns the character around
        boolean skinsView = capeT < 0.5f;
        boolean capeView = !skinsView && panelKind == 1, bodyView = !skinsView && panelKind == 2, cosView = !skinsView && panelKind == 3;
        if (!skinsView && editingName) commitName();
        nameBox.visible = skinsView && editingName;
        positionNameRow();
        for (Button b : skinWidgets) b.visible = skinsView;
        for (Button b : capeWidgets) b.visible = capeView;
        for (var w : bodyWidgets) w.visible = bodyView;
        for (Button b : cosWidgets) b.visible = cosView;

        swayFactor += ((dragging ? 0f : 1f) - swayFactor) * Math.min(1f, dt * 4f);

        hoverX = mouseX; hoverY = mouseY;
        SkinEntry cs = model.selected();
        boolean slimNow = cs != null && cs.slim();
        if (armsButton != null && (lastSlim == null || lastSlim != slimNow)) {
            lastSlim = slimNow;
            armsButton.setTooltip(Tooltip.create(Component.translatable(slimNow ? "skinswitch.tip.arms.slim" : "skinswitch.tip.arms.wide")
                .append(Component.literal("\n")).append(Component.translatable("skinswitch.tip.arms.desc").withStyle(net.minecraft.ChatFormatting.GRAY))));
        }

        // blurred background (the title-screen / world behind the menu, like the reference look); plain dark veil if this version has no blur
        if (blurBackground(g, partialTick)) g.fill(0, 0, width, height, 0x38101820); else g.fill(0, 0, width, height, BG);
        if (skinsView) drawSkinList(g); else if (capeView) { layoutCapes(); drawCapes(g); } else if (cosView) { layoutCos(); drawCos(g); } else drawBodyPanel(g);
        drawPreview(g);
        layoutRing();
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        for (IconBtn ib : icons)
            if (ib.b().visible) drawIcon(g, ib.rows().get(), ib.b().getX() + ib.b().getWidth() / 2, ib.b().getY() + ib.b().getHeight() / 2, ib.scale(), ib.b().active ? WHITE : 0xFF6B7080);
        int lcx = previewCenterX(), lcy = height / 2 + 8; // armor (slot 2) + held item (slot 4): plain lock icons
        drawIcon(g, I_LOCK, lcx + RING_DX[2], lcy + RING_DY[2], 2, 0xFF6B7080);
        drawIcon(g, I_LOCK, lcx + RING_DX[4], lcy + RING_DY[4], 2, 0xFF6B7080);
        if (capeView) drawCapeTooltip(g);
        if (cosView) drawCosTooltip(g);
    }

    // ---- blurred background ----------------------------------------------------------------------------------------------
    // Vanilla's Screen has a "blurred background" method (name / arguments changed between versions), so it is found by name at
    // runtime: no compile error if it moves, and the screen simply falls back to the dark veil. Needs the game's "Menu Background Blur" > 0.
    private java.lang.reflect.Method blurMethod;
    private boolean blurSearched, blurFailed;

    private boolean blurBackground(GuiGraphicsExtractor g, float partialTick) {
        if (blurFailed) return false;
        try {
            if (!blurSearched) {
                blurSearched = true;
                for (Class<?> c = getClass(); c != null && blurMethod == null; c = c.getSuperclass())
                    for (java.lang.reflect.Method m : c.getDeclaredMethods()) {
                        if (!m.getName().toLowerCase(java.util.Locale.ROOT).contains("blurredbackground")) continue;
                        boolean ok = true;
                        for (Class<?> p : m.getParameterTypes()) if (p != float.class && !p.isAssignableFrom(g.getClass())) ok = false;
                        if (ok) { m.setAccessible(true); blurMethod = m; break; }
                    }
                if (blurMethod == null) { blurFailed = true; return false; }
            }
            Class<?>[] pt = blurMethod.getParameterTypes();
            Object[] args = new Object[pt.length];
            for (int i = 0; i < pt.length; i++) args[i] = pt[i] == float.class ? (Object) partialTick : g;
            blurMethod.invoke(this, args);
            return true;
        } catch (ReflectiveOperationException | RuntimeException e) {
            blurFailed = true;
            SkinSwitchMod.LOGGER.error("Blurred background not available", e);
            return false;
        }
    }

    private void drawBodyPanel(GuiGraphicsExtractor g) {
        g.fill(panelX0 - 6, 8, panelX1 + 6, height - 6, 0x55000000);
        g.text(font, Component.translatable("skinswitch.screen.body"), panelX0, 22, WHITE, true);
    }

    private void drawSkinList(GuiGraphicsExtractor g) {
        g.text(font, Component.translatable("skinswitch.screen.skins", model.selectedNumber(), model.count()), 14, 14, WHITE, true);
        List<SkinEntry> list = model.entries();
        for (int i = 0; i < list.size(); i++) {
            var r = model.slot(i, GRID_X, GRID_Y);
            boolean sel = list.get(i) == model.selected();
            g.fill(r.x() - 2, r.y() - 2, r.x() + r.w() + 2, r.y() + r.h() + 2, sel ? SELECT : EDGE);
            g.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), PANEL);
            int[] h = head(list.get(i));
            if (h != null) PixelPainter.draw(g, h, 8, 8, r.x() + 6, r.y() + 6, 4);
            if (model.isFavorite(list.get(i))) g.text(font, Component.literal("★"), r.x() + r.w() - 9, r.y() + 2, GOLD, true);
        }
        int dropY = GRID_Y + model.gridHeight() + 10, dropW = 4 * (SkinScreenModel.SLOT + SkinScreenModel.GAP) - SkinScreenModel.GAP;
        int dh = dropH();
        g.fill(GRID_X, dropY, GRID_X + dropW, dropY + dh, 0x33FFFFFF);
        brackets(g, GRID_X, dropY, GRID_X + dropW, dropY + dh, 10, 0xCCFFFFFF);
        drawIcon(g, I_DOWN, GRID_X + dropW / 2, dropY + dh / 2 - 12, 2, WHITE);
        g.centeredText(font, Component.translatable("skinswitch.screen.drop"), GRID_X + dropW / 2, dropY + dh / 2 + 6, 0xFFDDDDDD);
        g.centeredText(font, Component.translatable("skinswitch.screen.drop2"), GRID_X + dropW / 2, dropY + dh / 2 + 18, 0xFFAAAAAA);
        if (!editingName) g.centeredText(font, Component.literal(shownName()), width / 2, 42, WHITE); // name above the character (the pencil sits next to it)
    }

    private void drawCapes(GuiGraphicsExtractor g) {
        g.fill(panelX0 - 6, 8, panelX1 + 6, height - 6, 0x55000000);
        for (Header h : headers) {
            int sy = screenY(h.y());
            if (!fullyVisible(sy, 12)) continue;
            g.text(font, h.title(), panelX0, sy, WHITE, true);
            String n = Integer.toString(h.count());
            g.text(font, Component.literal(n), panelX1 - font.width(n), sy, 0xFFAAAAAA, false);
            g.fill(panelX0 + font.width(h.title()) + 6, sy + 4, panelX1 - font.width(n) - 6, sy + 5, 0x55FFFFFF);
        }
        for (Cell c : cells) {
            int sy = screenY(c.y());
            if (!fullyVisible(sy, c.h())) continue;
            if (c.kind() == 1) {
                g.fill(c.x(), sy, c.x() + c.w(), sy + c.h(), 0x33FFFFFF);
                brackets(g, c.x(), sy, c.x() + c.w(), sy + c.h(), 8, 0xCCFFFFFF);
                drawIcon(g, I_DOWN, c.x() + c.w() / 2, sy + c.h() / 2 - 16, 2, WHITE);
                g.centeredText(font, Component.translatable("skinswitch.screen.import"), c.x() + c.w() / 2, sy + c.h() / 2 + 2, WHITE);
                g.centeredText(font, Component.translatable("skinswitch.screen.or_drop"), c.x() + c.w() / 2, sy + c.h() / 2 + 13, 0xFFAAAAAA);
                continue;
            }
            boolean none = c.kind() == 0;
            boolean sel = none ? pendingCape == null : pendingCape != null && pendingCape.id().equals(c.cape().id());
            g.fill(c.x() - 2, sy - 2, c.x() + c.w() + 2, sy + c.h() + 2, sel ? SELECT : EDGE);
            g.fill(c.x(), sy, c.x() + c.w(), sy + c.h(), sel ? 0xFF55678C : PANEL);
            if (!none && c.cape().resource() != null) g.fill(c.x() + c.w() - 8, sy + c.h() - 8, c.x() + c.w() - 3, sy + c.h() - 3, 0xFFB0B8D0);
            if (none) { dashed(g, c.x() + 4, sy + 4, c.x() + c.w() - 4, sy + c.h() - 4, 0xAAFFFFFF); g.centeredText(font, Component.translatable("skinswitch.screen.none"), c.x() + c.w() / 2, sy + c.h() / 2 - 4, WHITE); continue; }
            CapeImage img = capes.image(c.cape());
            if (img != null) {
                int s = Math.max(1, Math.min((c.w() - 4) / 10, (c.h() - 4) / 16));
                PixelPainter.draw(g, img.thumbnail(time), 10, 16, c.x() + (c.w() - 10 * s) / 2, sy + (c.h() - 16 * s) / 2, s);
                if (img.animated()) g.text(font, Component.literal("GIF"), c.x() + 2, sy + 2, 0xFF7FD4FF, true);
            }
            if (capes.isFavorite(c.cape())) {
                g.fill(c.x() + c.w() - 12, sy + 1, c.x() + c.w() - 1, sy + 12, 0xCC1A1A2E);
                g.text(font, Component.literal("★"), c.x() + c.w() - 11, sy + 2, GOLD, false);
            }
        }
        if (capes.capes().isEmpty())
            g.text(font, Component.translatable("skinswitch.screen.no_capes_hint"), panelX0, screenY(contentHeight) + 4, 0xFFAAAAAA, false);
    }

    /** Hover tooltip on a cape tile: gold name, type, "Click to preview" (purple box like the reference). */
    private void drawCapeTooltip(GuiGraphicsExtractor g) {
        for (Cell c : cells) {
            if (c.kind() != 2) continue;
            int sy = screenY(c.y());
            if (!fullyVisible(sy, c.h()) || hoverX < c.x() || hoverX >= c.x() + c.w() || hoverY < sy || hoverY >= sy + c.h()) continue;
            CapeImage img = capes.image(c.cape());
            List<Component> lines = List.of(
                Component.literal(c.cape().name()).withStyle(net.minecraft.ChatFormatting.GOLD, net.minecraft.ChatFormatting.BOLD),
                Component.translatable(img != null && img.animated() ? "skinswitch.tip.cape.animated" : "skinswitch.tip.cape.static").withStyle(net.minecraft.ChatFormatting.GRAY),
                Component.translatable("skinswitch.tip.cape.click").withStyle(net.minecraft.ChatFormatting.ITALIC, net.minecraft.ChatFormatting.DARK_PURPLE));
            int tw = 0;
            for (Component l : lines) tw = Math.max(tw, font.width(l));
            int bw = tw + 10, bh = lines.size() * 11 + 6;
            int bx = Math.min(hoverX + 12, width - bw - 2), by = Math.min(hoverY - 4, height - bh - 2);
            g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF5A2FC8);
            g.fill(bx, by, bx + bw, by + bh, 0xF0160A2E);
            for (int i = 0; i < lines.size(); i++) g.text(font, lines.get(i), bx + 5, by + 4 + i * 11, WHITE, true);
            return;
        }
    }

    private void drawPreview(GuiGraphicsExtractor g) {
        SkinEntry cur = model.selected();
        SkinImage skin = skinImage(cur);
        if (skin == null) return;
        float yaw = ease(turnT) * 160f + dragYaw + (float) Math.sin(time * 0.7) * 14f * swayFactor + walkYaw;
        CapeImage cape = capes.image(pendingCape);
        // while the Cosmetics panel is open the character also shows the piece being previewed (not saved until Equip)
        String pet = cosMode ? cos.previewPet() : UiPrefs.get().pet();
        List<String> acc = cosMode ? cos.previewItems() : UiPrefs.get().accessories();
        int[] px = PreviewRenderer.render(skin, cape, cur.slim(), yaw, time, PW, PH, UiPrefs.get().scales(), animMode == 1 || animMode == 2 ? animMode : 0, pet, false, acc);
        int x = previewCenterX() - PW * PSCALE / 2, y = height / 2 - PH * PSCALE / 2 + 4;
        int ex = x + PW * PSCALE / 2, ey = y + PH * PSCALE - 6;
        for (int r = -5; r <= 5; r++) { // flat ellipse platform under the feet
            int half = (int) (60 * Math.sqrt(1 - (r * r) / 36.0));
            g.fill(ex - half, ey + r, ex + half, ey + r + 1, Math.abs(r) >= 5 ? 0xCCFFFFFF : 0x44FFFFFF);
        }
        PixelPainter.draw(g, px, PW, PH, x, y, PSCALE);
    }

    private boolean overPreview(double mx, double my) {
        int x = previewCenterX() - PW * PSCALE / 2, y = height / 2 - PH * PSCALE / 2 + 4;
        return mx >= x && mx < x + PW * PSCALE && my >= y && my < y + PH * PSCALE;
    }

    private void layoutRing() {
        int cx = previewCenterX(), cy = height / 2 + 8;
        for (int i = 0; i < ring.size(); i++) { int sl = ringSlots.get(i); ring.get(i).setX(cx + RING_DX[sl] - 13); ring.get(i).setY(cy + RING_DY[sl] - 13); }
    }

    // ---- input ---------------------------------------------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) { // API-RISK: signature in 26.3
        if (super.mouseClicked(event, doubleClick)) return true;
        double mx = event.x(), my = event.y();
        if (overPreview(mx, my)) { dragging = true; return true; } // hold + move the mouse to spin the character
        if (capeT < 0.5f) {
            int i = model.slotAt(mx, my, GRID_X, GRID_Y);
            if (i >= 0) { model.select(i); return true; }
            int dropY = GRID_Y + model.gridHeight() + 10, dropW = 4 * (SkinScreenModel.SLOT + SkinScreenModel.GAP);
            if (mx >= GRID_X && mx < GRID_X + dropW && my >= dropY && my < dropY + dropH()) { pickFiles(false); return true; }
        } else if (panelKind == 1) {
            for (Cell c : cells) {
                int sy = screenY(c.y());
                if (!fullyVisible(sy, c.h()) || mx < c.x() || mx >= c.x() + c.w() || my < sy || my >= sy + c.h()) continue;
                if (c.kind() == 1) pickFiles(true);
                else { pendingCape = c.kind() == 0 ? null : c.cape(); capeDirty = true; }
                return true;
            }
        } else if (panelKind == 3) {
            for (CosCell c : cosCells) { // click = preview on the character, double-click = equip / take off
                int sy = cosScreenY(c.y());
                if (!cosVisible(sy, c.h()) || mx < c.x() || mx >= c.x() + c.w() || my < sy || my >= sy + c.h()) continue;
                if (c.kind() == 0) cos.selectNone(); else if (c.kind() == 1) cos.selectAnimal(c.id()); else cos.selectItem(c.id());
                if (doubleClick) cos.quickToggle();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) { // API-RISK: signature in 26.3
        if (dragging) { dragYaw += (float) dragX * 1.2f; return true; } // if it spins the wrong way, flip the sign
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) { // API-RISK: signature in 26.3
        if (dragging) { dragging = false; return true; }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) { // API-RISK: signature in 26.3
        if (capeT > 0.5f && panelKind == 1) {
            int max = Math.max(0, contentHeight - (viewBottom() - CAPE_TOP));
            scroll = Math.max(0, Math.min(max, scroll - (int) (sy * 24)));
            return true;
        }
        if (capeT > 0.5f && panelKind == 3) {
            int max = Math.max(0, cosContentHeight - (cosBottom() - COS_TOP));
            cosScroll = Math.max(0, Math.min(max, cosScroll - (int) (sy * 24)));
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public void onFilesDrop(List<Path> files) { importAll(files, capeMode); }

    private void pickFiles(boolean asCape) {
        String f = org.lwjgl.util.tinyfd.TinyFileDialogs.tinyfd_openFileDialog(Component.translatable(asCape ? "skinswitch.screen.select_cape" : "skinswitch.screen.select_skin").getString(), "", null, "PNG images", true);
        if (f != null) importAll(Arrays.stream(f.split("\\|")).map(Path::of).toList(), asCape);
    }

    private void importAll(List<Path> files, boolean asCape) {
        for (Path p : files) {
            if (!p.toString().toLowerCase().endsWith(".png") || !Files.isRegularFile(p)) continue;
            try {
                if (asCape) { pendingCape = capes.importFile(p); capeDirty = true; }
                else { SkinEntry e = skins.importFile(p); model.refresh(); selectById(e.id()); }
            } catch (IOException ex) { SkinSwitchMod.LOGGER.error("Import failed", ex); }
        }
        model.refresh();
    }

    private void selectById(String id) {
        for (int i = 0; i < model.entries().size(); i++) if (model.entries().get(i).id().equals(id)) model.select(i);
    }

    @Override
    public void onClose() { commitName(); minecraft.setScreen(parent); }
}
