package com.skinswitch.client.sync;

import com.skinswitch.SkinSwitchMod;
import com.skinswitch.client.BodyScale;
import com.skinswitch.render.Accessories;
import com.skinswitch.render.PetModels;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.TickEvent;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Base64;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Shares your skin, cape and body proportions with friends who also have Skin Switch, on LAN or any server.
 *
 * No server mod is needed: the data travels as hidden chat messages that start with "[[ss]]". Skin Switch on the other side
 * reads them and hides them (players without the mod would just see some odd text, so use it with friends who have it).
 * Messages are paced to stay under the server's chat-spam kick (see SPAM_* below): a short burst, then 1 per second; the
 * skin is stored as a compact indexed PNG (roughly 10-25 messages). A skin / cape that was already fully sent
 * is NOT sent again when you switch back to it (friends keep it in memory) - only the 1-message header goes out, so
 * changing skins a lot while playing is cheap. A new player joining (their "hello") makes everything resendable.
 *
 *   H|uuid                                     "hello" - a player who just joined asks everyone to send their look
 *   A|uuid|slim|scales(12 ints=x100)|skinHash|capeHash|capeRef|name   look header (hash 0 = nothing custom; capeRef = bundled cape id or -; name = base64 display name or -)
 *   D|uuid|hash|i|n|chunk                      skin PNG (64x64) split in n base64 chunks
 *   C|uuid|hash|i|n|chunk                      cape strip PNG (64 x 32*frames) split in n base64 chunks (only for non-bundled capes)
 */
public final class ChatSync {
    private ChatSync() {}

    private static final String MARK = "[[ss]]";
    // chat limit is 256 chars: MARK(6) + header(<=58) + CHUNK stays under it
    private static final int CHUNK = 190, MAX_PARTS = 160;
    // Vanilla kicks for spam when the server's counter reaches 200; each chat message adds 20 and the counter drops by 1 per
    // tick. We mirror that counter and only send while it is <= SPAM_ALLOW, which leaves room for your own typed chat.
    // If a server kicks you for spam, lower SPAM_ALLOW (e.g. 60) or raise MIN_GAP_TICKS.
    private static final int SPAM_STEP = 20, SPAM_ALLOW = 100, MIN_GAP_TICKS = 3;

    private static final Deque<String> QUEUE = new ArrayDeque<>();
    private static final Map<String, String[]> ASSEMBLY = new HashMap<>();   // "type:uuid:hash" -> chunks
    private static final Map<UUID, String> WANT_SKIN = new HashMap<>(), WANT_CAPE = new HashMap<>(); // uuid -> hash we wait for
    private static final Set<String> SENT = new HashSet<>();     // "D"+hash / "C"+hash of skins / capes whose chunks were fully sent
    private static Object lastLevel;
    private static int gap, spam, joinDelay, tick, stable;      // spam = our estimate of the server's chat-spam counter
    private static String pendingSig = "", sentSig = "";
    private static long lastHelloReply;
    private static final Map<UUID, long[]> COSMETIC_RATE = new HashMap<>();

    public static void register() {
        TickEvent.ClientTickEvent.Post.BUS.addListener(e -> onTick());
        // API-RISK: cancellable-event listener shape in 26.3 (returns true to hide the message)
        ClientChatReceivedEvent.BUS.addListener(ChatSync::onChat);
    }

    // ---- sending --------------------------------------------------------------------------------------------------
    private static void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) { lastLevel = null; spam = 0; gap = 0; return; }
        if (mc.level != lastLevel) { // joined a world / server
            lastLevel = mc.level;
            PlayerLook.clearOthers(); ASSEMBLY.clear(); WANT_SKIN.clear(); WANT_CAPE.clear(); COSMETIC_RATE.clear(); QUEUE.clear();
            sentSig = ""; pendingSig = ""; SENT.clear(); stable = 0; joinDelay = 80;
        }
        if (spam > 0) spam--;
        if (++tick % 20 == 0) {
            PlayerLook.refreshLocal(); // applies a newly selected skin / cape to yourself right away
            String sig = signature();
            if (!sig.equals(pendingSig)) { pendingSig = sig; stable = 0; } else stable++;
            if (joinDelay == 0 && stable >= 1 && !sig.equals(sentSig)) { // settled for ~1 s (not mid-slider-drag)
                sentSig = sig;
                announce(false);
            }
        }
        if (joinDelay > 0 && --joinDelay == 0) QUEUE.addFirst("H|" + hex(mc.player.getUUID()));
        if (gap > 0) { gap--; return; }
        String msg = QUEUE.peekFirst();
        if (msg != null && spam <= SPAM_ALLOW) {
            QUEUE.pollFirst();
            mc.getConnection().sendChat(MARK + msg);
            spam += SPAM_STEP; gap = MIN_GAP_TICKS;
            noteSent(msg);
        }
    }

    /** When the LAST chunk of a skin / cape goes out, remember it so switching back to it later costs only the header. */
    private static void noteSent(String msg) {
        if (!msg.startsWith("D|") && !msg.startsWith("C|")) return;
        try {
            String[] p = msg.split("\\|", -1);
            if (p.length >= 5 && Integer.parseInt(p[3]) + 1 == Integer.parseInt(p[4])) SENT.add(p[0] + p[2]);
        } catch (RuntimeException ignored) { }
    }

    private static String signature() {
        UUID me = Minecraft.getInstance().player.getUUID();
        return PlayerLook.localSkinHash + "|" + PlayerLook.localCapeHash + "|" + PlayerLook.localCapeRef + "|" + scalesCsv(BodyScale.forPlayer(me)) + "|" + slim() + "|" + nameField() + "|" + cosmeticsField();
    }

    private static String slim() {
        var l = PlayerLook.lookFor(Minecraft.getInstance().player.getUUID());
        return l != null && l.slim() ? "1" : "0";
    }

    private static String scalesCsv(float[] s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i++) { if (i > 0) sb.append(','); sb.append(Math.round((s == null ? 1f : s[i]) * 100f)); }
        return sb.toString();
    }

    /** The custom display name as URL-safe base64 (so it can hold any character, even "|"), or "-" for none. */
    private static String nameField() {
        String n = com.skinswitch.data.UiPrefs.get().displayName();
        return n == null ? "-" : Base64.getUrlEncoder().withoutPadding().encodeToString(n.getBytes(StandardCharsets.UTF_8));
    }

    /** Compact X payload. Catalogue indices keep the complete message well below the 256-char chat limit. */
    private static String cosmeticsField() {
        UiPrefsSnapshot p = cosmeticsSnapshot();
        return p.petIndex + "|" + p.accessoryIndexes;
    }

    private record UiPrefsSnapshot(int petIndex, String accessoryIndexes) {}
    private static UiPrefsSnapshot cosmeticsSnapshot() {
        var prefs = com.skinswitch.data.UiPrefs.get();
        String pet = prefs.pet();
        int petIndex = pet == null ? -1 : java.util.Arrays.asList(PetModels.IDS).indexOf(pet);
        StringBuilder indexes = new StringBuilder();
        for (String id : Accessories.normalize(prefs.accessories())) {
            int ix = java.util.Arrays.asList(Accessories.IDS).indexOf(id);
            if (ix < 0) continue;
            if (indexes.length() > 0) indexes.append(',');
            indexes.append(ix);
        }
        return new UiPrefsSnapshot(petIndex, indexes.toString());
    }

    private static String hex(UUID id) { return id.toString().replace("-", ""); }

    private static UUID unhex(String h) {
        return new UUID(Long.parseUnsignedLong(h.substring(0, 16), 16), Long.parseUnsignedLong(h.substring(16), 16));
    }

    /** Queues our look: header, plus skin / cape chunks when they changed since last time (or when forced). */
    private static void announce(boolean force) {
        QUEUE.removeIf(m -> m.startsWith("A|") || m.startsWith("X|") || m.startsWith("D|") || m.startsWith("C|"));
        UUID me = Minecraft.getInstance().player.getUUID();
        String skin = PlayerLook.localSkinHash, cape = PlayerLook.localCapeHash;
        QUEUE.addLast("A|" + hex(me) + "|" + slim() + "|" + scalesCsv(BodyScale.forPlayer(me)) + "|" + skin + "|" + cape + "|" + PlayerLook.localCapeRef + "|" + nameField());
        UiPrefsSnapshot cosmetics = cosmeticsSnapshot();
        QUEUE.addLast("X|" + hex(me) + "|" + cosmetics.petIndex + "|" + cosmetics.accessoryIndexes);
        if (PlayerLook.localSkinPng != null && !skin.equals("0") && (force || !SENT.contains("D" + skin))) queueChunks("D", me, skin, PlayerLook.localSkinPng);
        if (PlayerLook.localCapePng != null && PlayerLook.localCapeRef.equals("-") && !cape.equals("0") && (force || !SENT.contains("C" + cape))) queueChunks("C", me, cape, PlayerLook.localCapePng);
    }

    private static void queueChunks(String type, UUID me, String hash, byte[] png) {
        String b64 = Base64.getUrlEncoder().withoutPadding().encodeToString(png);
        int n = (b64.length() + CHUNK - 1) / CHUNK;
        for (int i = 0; i < n; i++)
            QUEUE.addLast(type + "|" + hex(me) + "|" + hash + "|" + i + "|" + n + "|" + b64.substring(i * CHUNK, Math.min(b64.length(), (i + 1) * CHUNK)));
    }

    // ---- receiving ------------------------------------------------------------------------------------------------
    /** @return true = hide the chat message */
    private static boolean onChat(ClientChatReceivedEvent event) {
        String s = event.getMessage().getString();
        int i = s.indexOf(MARK);
        if (i < 0) return false;
        try { handle(s.substring(i + MARK.length()).trim()); }
        catch (RuntimeException ex) { SkinSwitchMod.LOGGER.debug("Ignored bad sync message", ex); }
        return true;
    }

    private static void handle(String m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        String[] p = m.split("\\|", -1);
        switch (p[0]) {
            case "H" -> {
                if (p.length > 1 && unhex(p[1]).equals(mc.player.getUUID())) return; // my own hello echoed back
                SENT.clear(); // someone new is here: chunks we sent before may be missing on their side, so allow resending
                long now = System.currentTimeMillis();
                if (now - lastHelloReply > 60_000 && joinDelay == 0) { lastHelloReply = now; announce(true); }
            }
            case "A" -> {
                UUID id = unhex(p[1]);
                if (id.equals(mc.player.getUUID())) return;
                boolean slim = p[2].equals("1");
                float[] sc = new float[12];
                String[] v = p[3].split(",");
                for (int k = 0; k < 12; k++) sc[k] = Math.max(0.5f, Math.min(2.0f, Integer.parseInt(v[k]) / 100f));
                String skinHash = p[4], capeHash = p[5], capeRef = p[6];
                Identifier skin = skinHash.equals("0") ? null : PlayerLook.texture("s" + skinHash);
                Identifier[] cape = null;
                if (!capeRef.equals("-")) { cape = PlayerLook.packCape(capeRef); capeHash = "0"; } // bundled cape: load from our own copy
                else if (!capeHash.equals("0")) cape = PlayerLook.cape(capeHash);
                PlayerLook.OTHERS.put(id, new PlayerLook.Look(skin, cape, slim, sc));
                String shown = null; // 8th field (added later): custom display name; older versions do not send it
                if (p.length > 7 && !p[7].equals("-")) {
                    try { String n = com.skinswitch.data.UiPrefs.clean(new String(Base64.getUrlDecoder().decode(p[7]), StandardCharsets.UTF_8)); if (!n.isEmpty()) shown = n; }
                    catch (IllegalArgumentException ignored) { }
                }
                if (shown == null) PlayerLook.NAMES.remove(id); else PlayerLook.NAMES.put(id, shown);
                if (skinHash.equals("0") || skin != null) WANT_SKIN.remove(id); else WANT_SKIN.put(id, skinHash);
                if (capeHash.equals("0") || cape != null) WANT_CAPE.remove(id); else WANT_CAPE.put(id, capeHash);
            }
            case "X" -> {
                if (p.length != 4 || p[1].length() != 32) return;
                UUID id = unhex(p[1]);
                if (id.equals(mc.player.getUUID()) || !allowCosmetics(id)) return;
                CosmeticsMessageCodec.Parsed cosmetics = CosmeticsMessageCodec.parse(p[2], p[3]);
                PlayerLook.COSMETICS.put(id, new PlayerLook.Cosmetics(cosmetics.pet(), cosmetics.accessories()));
            }
            case "D", "C" -> {
                boolean isSkin = p[0].equals("D");
                UUID id = unhex(p[1]);
                String hash = p[2];
                int idx = Integer.parseInt(p[3]), n = Integer.parseInt(p[4]);
                if (id.equals(mc.player.getUUID()) || n < 1 || n > MAX_PARTS || idx < 0 || idx >= n || p[5].length() > 256) return;
                if (isSkin ? PlayerLook.hasTexture("s" + hash) : PlayerLook.hasCape(hash)) return;
                String ak = p[0] + ":" + hex(id) + ":" + hash;
                String[] parts = ASSEMBLY.computeIfAbsent(ak, k -> new String[n]);
                if (parts.length != n) return;
                parts[idx] = p[5];
                for (String part : parts) if (part == null) return;
                ASSEMBLY.remove(ak);
                byte[] png = Base64.getUrlDecoder().decode(String.join("", parts).getBytes(StandardCharsets.US_ASCII));
                if (png.length > 40_000 || !PlayerLook.crc(png).equals(hash)) return;
                var old = PlayerLook.OTHERS.get(id);
                Map<UUID, String> want = isSkin ? WANT_SKIN : WANT_CAPE;
                if (isSkin) {
                    Identifier tex = PlayerLook.register("s" + hash, png, 64, 64);
                    if (tex == null || old == null || !hash.equals(want.get(id))) return;
                    PlayerLook.OTHERS.put(id, new PlayerLook.Look(tex, old.cape(), old.slim(), old.scales()));
                } else {
                    Identifier[] frames = PlayerLook.registerCape(hash, png);
                    if (frames == null || old == null || !hash.equals(want.get(id))) return;
                    PlayerLook.OTHERS.put(id, new PlayerLook.Look(old.skin(), frames, old.slim(), old.scales()));
                }
                want.remove(id);
            }
            default -> { }
        }
    }

    /** Fixed one-second window per sender, preventing cosmetic chat floods. */
    private static boolean allowCosmetics(UUID id) {
        long now = System.currentTimeMillis();
        long[] state = COSMETIC_RATE.computeIfAbsent(id, k -> new long[]{now, 0});
        if (now - state[0] >= 1000) { state[0] = now; state[1] = 0; }
        if (++state[1] > 4) return false;
        return true;
    }
}
