package com.skinswitch.client;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import java.util.function.DoubleConsumer;

/** A percent slider (e.g. 50%..200%) that snaps to 5% steps and reports the real value through a callback. */
final class PrefSlider extends AbstractSliderButton {
    private final Component label;
    private final double min, max;
    private final DoubleConsumer onChange;

    PrefSlider(int x, int y, int w, int h, Component label, double min, double max, double current, DoubleConsumer onChange) {
        super(x, y, w, h, Component.empty(), (current - min) / (max - min));
        this.label = label; this.min = min; this.max = max; this.onChange = onChange;
        updateMessage();
    }

    private double real() { return Math.round((min + value * (max - min)) * 20.0) / 20.0; } // 5% steps

    /** Move the knob without firing the callback (used when the part tab changes or on reset). */
    void setCurrent(double current) {
        this.value = Math.max(0, Math.min(1, (current - min) / (max - min)));
        updateMessage();
    }

    @Override
    protected void updateMessage() {
        if (label == null) return; // called from the super constructor
        setMessage(label.copy().append(Component.literal(": " + Math.round(real() * 100) + "%")));
    }

    @Override
    protected void applyValue() { onChange.accept(real()); }
}
