package com.skinswitch.client;

import com.skinswitch.data.UiPrefs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Where the character is shown on the title screen / pause menu / options and how big.
 * The character is drawn live behind the controls, so you see the change while you drag the slider.
 */
public final class CharacterSettingsScreen extends Screen {
    private final Screen parent;
    private final boolean onTitle;
    private Button sideButton;
    private PrefSlider sizeSlider;

    public CharacterSettingsScreen(Screen parent, boolean title) {
        super(Component.translatable("skinswitch.settings.title"));
        this.parent = parent; this.onTitle = title;
    }

    private Component sideLabel() {
        return Component.translatable("skinswitch.settings.side",
            Component.translatable(UiPrefs.get().rightSide(onTitle) ? "skinswitch.settings.right" : "skinswitch.settings.left"));
    }

    @Override
    protected void init() {
        UiPrefs prefs = UiPrefs.get();
        int cx = width / 2, y = height / 2 - 34;
        sideButton = addRenderableWidget(Button.builder(sideLabel(), b -> {
            prefs.setRightSide(onTitle, !prefs.rightSide(onTitle));
            b.setMessage(sideLabel());
        }).bounds(cx - 100, y, 200, 20).build());
        sizeSlider = addRenderableWidget(new PrefSlider(cx - 100, y + 26, 200, 20, Component.translatable("skinswitch.settings.size"),
            UiPrefs.MIN_SIZE, UiPrefs.MAX_SIZE, prefs.size(onTitle), v -> prefs.setSize(onTitle, (float) v)));
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.settings.reset"), b -> {
            prefs.resetDisplay(onTitle);
            sideButton.setMessage(sideLabel());
            sizeSlider.setCurrent(prefs.size(onTitle));
        }).bounds(cx - 100, y + 52, 98, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.screen.done"), b -> onClose())
            .bounds(cx + 2, y + 52, 98, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) { // API-RISK: name/signature in 26.3
        g.fill(0, 0, width, height, 0xCC0E1116);
        ClientEvents.drawCharacter(g, this, onTitle);
        g.centeredText(font, getTitle(), width / 2, height / 2 - 52, 0xFFFFFFFF);
        super.extractRenderState(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
