package com.skinswitch.client.sync;

import com.skinswitch.render.Accessories;
import com.skinswitch.render.PetModels;

import java.util.ArrayList;
import java.util.List;

/** Pure-Java codec for the compact X|uuid|petIndex|accIndexes chat payload. */
public final class CosmeticsMessageCodec {
    private CosmeticsMessageCodec() {}

    public record Parsed(String pet, List<String> accessories) {}

    public static Parsed parse(String petField, String accessoriesField) {
        if (petField == null || accessoriesField == null) throw new IllegalArgumentException("missing cosmetics fields");
        final int petIndex;
        try { petIndex = Integer.parseInt(petField); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("invalid pet index", e); }
        if (petIndex < -1 || petIndex >= PetModels.IDS.length) throw new IllegalArgumentException("pet index out of range");

        if (accessoriesField.length() > 35) throw new IllegalArgumentException("accessory payload too long");
        String[] raw = accessoriesField.isEmpty() ? new String[0] : accessoriesField.split(",", -1);
        if (raw.length > 12) throw new IllegalArgumentException("too many accessories");
        List<String> selected = new ArrayList<>(raw.length);
        for (String value : raw) {
            if (value.isEmpty() || value.length() > 2) throw new IllegalArgumentException("invalid accessory index");
            final int index;
            try { index = Integer.parseInt(value); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("invalid accessory index", e); }
            if (index < 0 || index >= Accessories.IDS.length) throw new IllegalArgumentException("accessory index out of range");
            selected.add(Accessories.IDS[index]);
        }
        return new Parsed(petIndex < 0 ? null : PetModels.IDS[petIndex],
            List.copyOf(Accessories.normalize(selected)));
    }
}
