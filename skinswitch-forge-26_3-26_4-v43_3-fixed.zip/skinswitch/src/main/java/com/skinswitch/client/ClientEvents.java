package com.skinswitch.client;

import com.skinswitch.data.SkinEntry;
import com.skinswitch.data.SkinLibrary;
import com.skinswitch.data.UiPrefs;
import com.skinswitch.render.PreviewRenderer;
import com.skinswitch.render.SkinImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ScreenEvent;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Adds the "Change Skin" + settings (gear) buttons to the title screen, the pause menu and the Options screen, and draws
 * the character there:
 *  - pause / options: a copy of YOU (the real player entity: same pose, same held item - modded weapons included)
 *  - title screen: your selected library skin, drawn by the preview renderer (with your body proportions)
 * Side (left/right) and size come from UiPrefs and are edited in CharacterSettingsScreen (the gear button).
 */
public final class ClientEvents {
    private ClientEvents() {}

    private static final int PW = 96, PH = 176;
    private static final long START = System.nanoTime();
    private static SkinImage menuSkin;
    private static boolean menuSlim;

    public static void register() {
        ScreenEvent.Init.Post.BUS.addListener(ClientEvents::onScreenInit);
        ScreenEvent.Render.Post.BUS.addListener(ClientEvents::onScreenRender); // API-RISK: event + getter names in 26.3
    }

    /** Box of the character on the screen: {x1, y1, x2, y2}. Side and width follow the saved settings. */
    static int[] box(Screen screen, boolean title) {
        UiPrefs p = UiPrefs.get();
        int bw = Math.round(120 * p.size(title)), y1 = 30, y2 = screen.height - 40, x1, x2;
        if (p.rightSide(title)) { x2 = screen.width - 12; x1 = Math.max(screen.width / 2 + 112, x2 - bw); }
        else { x1 = 12; x2 = Math.min(screen.width / 2 - 112, x1 + bw); }
        return new int[]{x1, y1, x2, y2};
    }

    private static boolean isMenu(Screen screen) {
        return (screen instanceof PauseScreen || screen instanceof OptionsScreen) && Minecraft.getInstance().player != null;
    }

    private static void onScreenInit(ScreenEvent.Init.Post event) {
        var screen = event.getScreen();
        boolean title = screen instanceof TitleScreen;
        if (!title && !isMenu(screen)) return;
        if (title) loadMenuSkin();
        event.addListener(NightVision.button(screen.width - 26, 4)); // night vision: very top right
        int[] r = box(screen, title); // buttons right under the character
        if (r[2] - r[0] >= 50) {
            int w = r[2] - r[0];
            event.addListener(skinButton(r[0], r[3] + 6, w - 24));
            event.addListener(gearButton(r[0] + w - 20, r[3] + 6, title));
        } else {
            event.addListener(skinButton(8, screen.height - 28, 100));
            event.addListener(gearButton(112, screen.height - 28, title));
        }
    }

    private static void onScreenRender(ScreenEvent.Render.Post event) {
        var screen = event.getScreen();
        boolean title = screen instanceof TitleScreen;
        if (!title && !isMenu(screen)) return;
        drawCharacter(event.getGuiGraphics(), screen, title);
    }

    /** Draws the character in its box (also used live by CharacterSettingsScreen). */
    static void drawCharacter(GuiGraphicsExtractor g, Screen screen, boolean title) {
        Minecraft mc = Minecraft.getInstance();
        int[] r = box(screen, title);
        int h = r[3] - r[1];
        if (r[2] - r[0] < 50 || h < 40) return; // window too small
        float size = UiPrefs.get().size(title);
        if (!title) {
            if (mc.player == null) return;
            int scale = Math.max(20, Math.round(h / 3f * size));
            // mouse = centre of the box so the character just stands facing you; API-RISK: method name/signature in 26.3
            InventoryScreen.extractEntityInInventoryFollowsMouse(g, r[0], r[1], r[2], r[3], scale, 0.0625f,
                (r[0] + r[2]) / 2f, r[1] + h * 0.3f, mc.player);
            return;
        }
        if (menuSkin == null) loadMenuSkin();
        if (menuSkin == null) return; // no skin in the library yet
        float t = (System.nanoTime() - START) / 1e9f;
        float yaw = (float) Math.sin(t * 0.7) * 14f;
        int[] px = PreviewRenderer.render(menuSkin, null, menuSlim, yaw, t, PW, PH, UiPrefs.get().scales(), 0, UiPrefs.get().pet(), false, UiPrefs.get().accessories());
        float s = Math.min(h * size * 0.0042f, (h + 30f) / PH);
        PixelPainter.drawScaled(g, px, PW, PH, (r[0] + r[2]) / 2f - PW * s / 2f, r[1] + (h - PH * s) / 2f, s);
    }

    private static void loadMenuSkin() {
        try {
            SkinLibrary lib = new SkinLibrary(Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch"));
            lib.load();
            SkinEntry pick = null;
            for (SkinEntry e : lib.skins()) if (e.id().equals(lib.selectedId())) pick = e;
            if (pick == null && !lib.skins().isEmpty()) pick = lib.skins().get(0);
            if (pick == null) { menuSkin = null; return; }
            menuSkin = SkinImage.load(pick.file());
            menuSlim = pick.slim();
        } catch (IOException | RuntimeException e) { menuSkin = null; }
    }

    private static Button skinButton(int x, int y, int w) {
        return Button.builder(Component.translatable("skinswitch.button.change_skin"),
                b -> Minecraft.getInstance().setScreen(new SkinScreen(Minecraft.getInstance().screen)))
            .bounds(x, y, w, 20).build();
    }

    private static Button gearButton(int x, int y, boolean title) {
        return Button.builder(Component.literal("\u2699"),
                b -> Minecraft.getInstance().setScreen(new CharacterSettingsScreen(Minecraft.getInstance().screen, title)))
            .bounds(x, y, 20, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.tip.settings"))).build();
    }
}
