package com.skinswitch.client;

import com.skinswitch.data.UiPrefs;
import net.minecraft.client.Minecraft;

import java.util.UUID;

/**
 * Applies the "body proportions" (UiPrefs) to the real in-game player. Used by the mixins in com.skinswitch.mixin.
 * Same maths as MySkins: each part is scaled around its pivot and the parts below are shifted so nothing floats or sinks.
 * Your own body comes from the settings; friends' bodies come from what their Skin Switch sent (see client.sync.ChatSync).
 */
public final class BodyScale {
    private BodyScale() {}

    /** 12 floats: head xyz, arms xyz, torso xyz, legs xyz (same order as MySkins). You: live from settings; friends: what they sent. */
    public static float[] forPlayer(UUID id) {
        Minecraft mc = Minecraft.getInstance();
        if (id == null) return null;
        if (mc.player == null || !id.equals(mc.player.getUUID())) return com.skinswitch.client.sync.PlayerLook.scalesFor(id);
        float[][] s = UiPrefs.get().scales();
        return new float[]{
            s[UiPrefs.HEAD][0], s[UiPrefs.HEAD][1], s[UiPrefs.HEAD][2],
            s[UiPrefs.ARMS][0], s[UiPrefs.ARMS][1], s[UiPrefs.ARMS][2],
            s[UiPrefs.TORSO][0], s[UiPrefs.TORSO][1], s[UiPrefs.TORSO][2],
            s[UiPrefs.LEGS][0], s[UiPrefs.LEGS][1], s[UiPrefs.LEGS][2]};
    }

    /** Extra body height in blocks (negative = shorter) from head / torso / legs height scales. */
    public static float heightOffset() {
        float[][] s = UiPrefs.get().scales();
        return (4f * (s[UiPrefs.HEAD][1] - 1f) + 12f * (s[UiPrefs.TORSO][1] - 1f) + 12f * (s[UiPrefs.LEGS][1] - 1f)) / 16f;
    }

    /** How far to move the camera / eyes (blocks). 0 if the "camera" option is off. */
    public static float cameraOffset() { return UiPrefs.get().cameraFollows() ? heightOffset() : 0f; }

    /** Name tag offset (blocks) so the name stays above the head. */
    public static float nameTagOffset(float[] s) {
        return (8f * (s[1] - 1f) + 12f * (s[7] - 1f) + 12f * (s[10] - 1f)) / 16f;
    }
}
