package com.skinswitch.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draws int[] ARGB pixel buffers with GuiGraphics.fill, merging equal horizontal runs to keep the fill count low. */
final class PixelPainter {
    private PixelPainter() {}

    static void draw(GuiGraphicsExtractor g, int[] px, int w, int h, int x, int y, int scale) {
        for (int j = 0; j < h; j++) {
            int i = 0;
            while (i < w) {
                int c = px[j * w + i];
                int k = i + 1;
                while (k < w && px[j * w + k] == c) k++;
                if (c != 0) g.fill(x + i * scale, y + j * scale, x + k * scale, y + (j + 1) * scale, c);
                i = k;
            }
        }
    }

    /** Same as draw, but with a fractional pixel size (used for the resizable menu character). */
    static void drawScaled(GuiGraphicsExtractor g, int[] px, int w, int h, float x, float y, float scale) {
        for (int j = 0; j < h; j++) {
            int i = 0;
            int y0 = Math.round(y + j * scale), y1 = Math.max(y0 + 1, Math.round(y + (j + 1) * scale));
            while (i < w) {
                int c = px[j * w + i];
                int k = i + 1;
                while (k < w && px[j * w + k] == c) k++;
                if (c != 0) g.fill(Math.round(x + i * scale), y0, Math.round(x + k * scale), y1, c);
                i = k;
            }
        }
    }
}
