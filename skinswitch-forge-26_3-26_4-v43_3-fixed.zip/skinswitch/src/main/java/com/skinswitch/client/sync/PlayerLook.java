package com.skinswitch.client.sync;

import com.mojang.blaze3d.platform.NativeImage;
import com.skinswitch.SkinSwitchMod;
import com.skinswitch.data.CapeEntry;
import com.skinswitch.data.CapeLibrary;
import com.skinswitch.data.SkinEntry;
import com.skinswitch.data.SkinLibrary;
import com.skinswitch.render.CapeImage;
import com.skinswitch.render.ElytraArt;
import com.skinswitch.render.SkinImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.CRC32;

/**
 * What every player looks like in game: skin, cape, arm model and body proportions.
 * - local player: skin + cape selected in Skin Switch (applied by AbstractClientPlayerMixin)
 * - other players: whatever their Skin Switch sent us (see ChatSync)
 */
public final class PlayerLook {
    private PlayerLook() {}

    /**
     * @param skin   null = keep the normal skin
     * @param cape   cape animation frames (1 = still), null = keep the normal cape
     * @param scales 12 floats (head xyz, arms xyz, torso xyz, legs xyz) or null
     */
    public record Look(Identifier skin, Identifier[] cape, boolean slim, float[] scales) {}

    static final Map<UUID, Look> OTHERS = new ConcurrentHashMap<>();
    /** Cosmetics received from another client; keyed by UUID so respawns do not lose them. */
    public record Cosmetics(String pet, java.util.List<String> accessories) {}
    static final Map<UUID, Cosmetics> COSMETICS = new ConcurrentHashMap<>();
    public static Cosmetics cosmeticsFor(UUID id) { return id == null ? null : COSMETICS.get(id); }
    /** Custom names other Skin Switch players chose (shown over their head). */
    static final Map<UUID, String> NAMES = new ConcurrentHashMap<>();

    public static String nameFor(UUID id) { return id == null ? null : NAMES.get(id); }
    private static final Map<String, Identifier> TEXTURES = new HashMap<>();
    private static final Map<String, Identifier[]> CAPES = new HashMap<>();
    public static final int MAX_FRAMES = 16, SEND_LIMIT = 12_000;

    private static Look local;                 // scales come live from UiPrefs
    static byte[] localSkinPng, localCapePng;  // canonical PNGs (skin 64x64, cape 64x32) for sending
    static String localSkinHash = "0", localCapeHash = "0"; // "0" = nothing custom
    static String localCapeRef = "-";                        // "pack:xxx.png" for bundled capes (friends load it from their own copy)
    private static String skinSig = "", capeSig = "";

    public static Look lookFor(UUID id) {
        Minecraft mc = Minecraft.getInstance();
        if (id == null) return null;
        if (mc.player != null && id.equals(mc.player.getUUID())) return local;
        return OTHERS.get(id);
    }

    public static float[] scalesFor(UUID id) {
        Look l = OTHERS.get(id);
        return l == null ? null : l.scales();
    }

    /** Re-reads the selected skin and cape from the libraries; returns true if something changed. Main thread only. */
    static boolean refreshLocal() {
        boolean changed = false;
        Path root = Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch");
        Identifier skin = local == null ? null : local.skin();
        Identifier[] cape = local == null ? null : local.cape();
        boolean slim = local != null && local.slim();
        try {
            SkinLibrary lib = new SkinLibrary(root);
            lib.load();
            SkinEntry pick = null;
            for (SkinEntry e : lib.skins()) if (e.id().equals(lib.selectedId())) pick = e;
            String sig = pick == null ? "" : pick.id() + "@" + pick.file().toFile().lastModified() + "@" + pick.slim();
            if (!sig.equals(skinSig)) {
                skinSig = sig; changed = true;
                if (pick == null) { skin = null; slim = false; localSkinPng = null; localSkinHash = "0"; }
                else {
                    byte[] png = skinPng(pick);
                    String hash = crc(png);
                    skin = register("s" + hash, png, 64, 64);
                    slim = pick.slim();
                    localSkinPng = png; localSkinHash = skin == null ? "0" : hash;
                }
            }
        } catch (IOException | RuntimeException e) { SkinSwitchMod.LOGGER.warn("Cannot apply selected skin", e); }
        try {
            CapeLibrary lib = new CapeLibrary(root);
            lib.load();
            CapeEntry pick = lib.selected();
            String sig = pick == null ? "" : pick.id() + "@" + (pick.file() == null ? 0 : pick.file().toFile().lastModified());
            if (!sig.equals(capeSig)) {
                capeSig = sig; changed = true;
                CapeImage img = pick == null ? null : lib.image(pick);
                if (img == null) { cape = null; localCapePng = null; localCapeHash = "0"; localCapeRef = "-"; }
                else {
                    byte[] png = capeStrip(img, 1);
                    String hash = crc(png);
                    cape = registerCape(hash, png);
                    localCapePng = shrinkForSending(img, png); // may have fewer frames so it travels faster
                    localCapeHash = cape == null ? "0" : crc(localCapePng);
                    localCapeRef = pick.resource() != null ? pick.id() : "-";
                }
            }
        } catch (IOException | RuntimeException e) { SkinSwitchMod.LOGGER.warn("Cannot apply selected cape", e); }
        if (changed) local = (skin == null && cape == null) ? null : new Look(skin, cape, slim, null);
        return changed;
    }

    /** 64x64 PNG (legacy 64x32 skins are converted, HD skins are scaled down) so it is small enough to send. */
    private static byte[] skinPng(SkinEntry e) throws IOException {
        SkinImage img = SkinImage.load(e.file());
        BufferedImage out = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) out.setRGB(x, y, img.argb(x + .5f, y + .5f));
        return png(out);
    }

    /** Vertical strip 64 x (32*frames) PNG of the cape; step = take every step-th frame (fewer frames = smaller). */
    private static byte[] capeStrip(CapeImage img, int step) throws IOException {
        int n = Math.max(1, Math.min(MAX_FRAMES, (img.frames() + step - 1) / step));
        BufferedImage out = new BufferedImage(64, 32 * n, BufferedImage.TYPE_INT_ARGB);
        for (int f = 0; f < n; f++) {
            float t = (f * step + 0.5f) / CapeImage.FPS;
            for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) {
                boolean outside = img.legacy() && (x >= 22 || y >= 17);
                out.setRGB(x, f * 32 + y, outside ? 0 : img.argb(x + .5f, y + .5f, t));
            }
            if (!img.legacy()) fillElytra(out, f * 32);
        }
        return png(out);
    }

    /**
     * Elytra wings use the cape texture too. Capes without wing art (imported ones, bundled ones that have none) would
     * leave the wings invisible, so a wing is built from the cape's outer face (see {@link ElytraArt}).
     * Does nothing if the wing art already exists (official capes, capes made in the Cape Editor).
     */
    private static void fillElytra(BufferedImage im, int oy) { ElytraArt.fillIfEmpty(im, oy); }

    /** Animated capes can be big; for sending, drop frames until the PNG is small (a few KB = a few seconds of chat). */
    private static byte[] shrinkForSending(CapeImage img, byte[] png) throws IOException {
        int step = 1;
        while (png.length > SEND_LIMIT && step < 16) { step *= 2; png = capeStrip(img, step); }
        return png;
    }

    /** Strip PNG -> one texture per frame. Main thread only. Returns null if the PNG is not a valid cape strip. */
    static Identifier[] registerCape(String hash, byte[] strip) {
        Identifier[] cached = CAPES.get(hash);
        if (cached != null) return cached;
        try {
            BufferedImage im = ImageIO.read(new ByteArrayInputStream(strip));
            if (im == null || im.getWidth() != 64 || im.getHeight() % 32 != 0) return null;
            int n = im.getHeight() / 32;
            if (n < 1 || n > MAX_FRAMES) return null;
            Identifier[] ids = new Identifier[n];
            for (int i = 0; i < n; i++) {
                ids[i] = register("c" + hash + "_" + i, png(im.getSubimage(0, i * 32, 64, 32)), 64, 32);
                if (ids[i] == null) return null;
            }
            CAPES.put(hash, ids);
            return ids;
        } catch (IOException | RuntimeException e) {
            SkinSwitchMod.LOGGER.warn("Bad cape", e);
            return null;
        }
    }

    static Identifier[] cape(String hash) { return CAPES.get(hash); }
    static boolean hasCape(String hash) { return CAPES.containsKey(hash); }

    /** A bundled (build-time) cape by its library id, e.g. "pack:Frost.png": every Skin Switch has the same ones. */
    static Identifier[] packCape(String ref) {
        try {
            CapeLibrary lib = new CapeLibrary(Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch"));
            lib.load();
            for (CapeEntry e : lib.capes()) if (e.id().equals(ref) && e.resource() != null) {
                CapeImage img = lib.image(e);
                if (img == null) return null;
                byte[] png = capeStrip(img, 1);
                return registerCape(crc(png), png);
            }
        } catch (IOException | RuntimeException e) { SkinSwitchMod.LOGGER.warn("Bad pack cape", e); }
        return null;
    }

    /**
     * Encodes a PNG as small as possible: skins / capes with 256 colours or fewer (almost all of them) become an indexed
     * PNG, which is somewhat smaller than RGBA (fewer chat messages to reach friends). More colours = plain RGBA.
     */
    private static byte[] png(BufferedImage im) throws IOException {
        int w = im.getWidth(), h = im.getHeight();
        Map<Integer, Integer> pal = new java.util.LinkedHashMap<>();
        int[] idxs = new int[w * h];
        boolean fits = true;
        scan:
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int argb = im.getRGB(x, y);
            Integer i = pal.get(argb);
            if (i == null) {
                if (pal.size() >= 256) { fits = false; break scan; }
                i = pal.size(); pal.put(argb, i);
            }
            idxs[y * w + x] = i;
        }
        BufferedImage out = im;
        if (fits) {
            int n = pal.size();
            byte[] r = new byte[n], g = new byte[n], b = new byte[n], a = new byte[n];
            for (Map.Entry<Integer, Integer> e : pal.entrySet()) {
                int c = e.getKey(), i = e.getValue();
                a[i] = (byte) (c >>> 24); r[i] = (byte) (c >> 16); g[i] = (byte) (c >> 8); b[i] = (byte) c;
            }
            out = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_INDEXED, new java.awt.image.IndexColorModel(8, n, r, g, b, a));
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) out.getRaster().setSample(x, y, 0, idxs[y * w + x]);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ImageIO.write(out, "png", bos);
        return bos.toByteArray();
    }

    static String crc(byte[] b) { CRC32 c = new CRC32(); c.update(b); return String.format("%08x", c.getValue()); }

    /** key = "s"+hash for skins, "c"+hash+"_"+frame for cape frames. */
    static boolean hasTexture(String key) { return TEXTURES.containsKey(key); }
    static Identifier texture(String key) { return TEXTURES.get(key); }

    /** Registers a PNG of exactly w x h as a texture (once per key). Main thread only. */
    static Identifier register(String key, byte[] png, int w, int h) {
        Identifier cached = TEXTURES.get(key);
        if (cached != null) return cached;
        try (var in = new ByteArrayInputStream(png)) {
            NativeImage ni = NativeImage.read(in);
            if (ni.getWidth() != w || ni.getHeight() != h) { ni.close(); return null; }
            Identifier id = Identifier.fromNamespaceAndPath(SkinSwitchMod.MODID, "look/" + key);
            Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(() -> "skinswitch " + key, ni));
            TEXTURES.put(key, id);
            return id;
        } catch (IOException | RuntimeException e) {
            SkinSwitchMod.LOGGER.warn("Bad texture", e);
            return null;
        }
    }

    static void clearOthers() { OTHERS.clear(); NAMES.clear(); COSMETICS.clear(); }
}
