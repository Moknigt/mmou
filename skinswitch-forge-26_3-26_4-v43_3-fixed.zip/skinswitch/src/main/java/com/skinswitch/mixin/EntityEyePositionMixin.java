package com.skinswitch.mixin;

import com.skinswitch.client.BodyScale;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Eyes (where you look / raycast from) follow the camera height. */
@Mixin(Entity.class)
public abstract class EntityEyePositionMixin {
    @Inject(method = "getEyePosition(F)Lnet/minecraft/world/phys/Vec3;", at = @At("RETURN"), cancellable = true)
    private void skinswitch$eye(float partialTick, CallbackInfoReturnable<Vec3> cir) {
        if (!((Object) this instanceof LocalPlayer)) return;
        float dy = BodyScale.cameraOffset();
        if (dy != 0f) cir.setReturnValue(cir.getReturnValue().add(0, dy, 0));
    }
}
