package com.skinswitch.mixin;

import com.skinswitch.client.sync.PlayerLook;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shows the Skin Switch skin and cape on you (and on friends who sent theirs). */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void skinswitch$getSkin(CallbackInfoReturnable<PlayerSkin> cir) {
        PlayerLook.Look look = PlayerLook.lookFor(((AbstractClientPlayer) (Object) this).getUUID());
        if (look == null || (look.skin() == null && look.cape() == null)) return;
        PlayerSkin o = cir.getReturnValue();
        ClientAsset.Texture body = look.skin() != null ? new ClientAsset.ResourceTexture(look.skin()) : o.body();
        ClientAsset.Texture cape = o.cape(), elytra = o.elytra();
        if (look.cape() != null && look.cape().length > 0) { // animated capes: pick the frame from the clock
            Identifier[] f = look.cape();
            cape = new ClientAsset.ResourceTexture(f[(int) (System.currentTimeMillis() * 8L / 1000L % f.length)]);
            elytra = cape; // the elytra wings use the same (animated) texture as the cape
        }
        PlayerModelType model = look.skin() == null ? o.model() : (look.slim() ? PlayerModelType.SLIM : PlayerModelType.WIDE);
        cir.setReturnValue(new PlayerSkin(body, cape, elytra, model, o.secure()));
    }
}
