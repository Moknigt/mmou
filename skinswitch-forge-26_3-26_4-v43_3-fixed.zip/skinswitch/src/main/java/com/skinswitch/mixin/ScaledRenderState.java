package com.skinswitch.mixin;

import java.util.UUID;

/** Lets the model know which player a render state belongs to. */
public interface ScaledRenderState {
    void skinswitch$setPlayerUuid(UUID id);
    UUID skinswitch$getPlayerUuid();
}
