package com.skinswitch.mixin;

import com.skinswitch.client.BodyScale;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Moves the camera up / down with your body height. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private Vec3 position;
    @Shadow protected abstract void setPosition(double x, double y, double z);

    @Inject(method = "update", at = @At("TAIL"))
    private void skinswitch$onUpdate(DeltaTracker tracker, CallbackInfo ci) {
        if (Minecraft.getInstance().player == null) return;
        float dy = BodyScale.cameraOffset();
        if (dy != 0f) setPosition(position.x, position.y + dy, position.z);
    }
}
