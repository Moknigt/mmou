package com.skinswitch.render;

import java.awt.image.BufferedImage;

/**
 * Elytra wing art inside a 64x32 cape frame: the wing box is 10 x 20 x 2 and its texture net sits at x 22..45, y 0..21
 * (right side 22..23, front 24..33, left side 34..35, back 36..45, top 24..33 / bottom 34..43 in rows 0..1).
 * The wing is built from the cape's OUTER face (x 1..10, y 1..16): same colours (and, for animated capes, the same
 * animation frame by frame), cut to a wing shape - wide at the shoulder, tapering to a rounded tip - with an outline
 * and feather ribs. Pure Java; used by the cape editor ("Elytra: Auto") and by PlayerLook for capes without wing art.
 */
public final class ElytraArt {
    private ElytraArt() {}

    public static final int W = 64, H = 32, X0 = 22, X1 = 46, Y1 = 22;

    /** true if the frame already has any wing pixel. */
    public static boolean hasArt(int[] f) {
        for (int y = 0; y < Y1; y++) for (int x = X0; x < X1; x++) if ((f[y * W + x] >>> 24) != 0) return true;
        return false;
    }

    /** Clears the wing area of one 64x32 frame and rebuilds the wing from the cape's outer face. */
    public static void generate(int[] f) {
        for (int y = 0; y < Y1; y++) for (int x = X0; x < X1; x++) f[y * W + x] = 0;
        for (int y = 0; y < Y1; y++) for (int x = X0; x < X1; x++) {
            int u, v;
            if (y < 2) { // top (x 24..33) / bottom (x 34..43) of the wing box
                if (x < 24 || x > 43) continue;
                u = (x - 24) % 10; v = x < 34 ? 0 : 19;
            } else {
                v = y - 2;
                u = x < 24 ? 0 : x < 34 ? x - 24 : x < 36 ? 9 : x - 36;
            }
            if (!wing(u, v)) continue;
            int c = f[(1 + v * 16 / 20) * W + 1 + u];
            if ((c >>> 24) == 0) continue;
            double k = 1;
            boolean sideOrCap = x < 24 || (x >= 34 && x < 36) || y < 2;
            if (sideOrCap) k = 0.8;
            else if (!wing(u - 1, v) || !wing(u + 1, v) || !wing(u, v + 1)) k = 0.65;                    // outline
            else if (((v + (int) (Math.abs(u - 4.5) * 1.3)) % 6) == 0 || u == 4 || u == 5) k = 0.78;     // feather ribs + spine
            int r = (int) ((c >> 16 & 255) * k), g = (int) ((c >> 8 & 255) * k), b = (int) ((c & 255) * k);
            f[y * W + x] = 0xFF000000 | r << 16 | g << 8 | b;
        }
    }

    /** For a cape strip image: builds the wing of the frame starting at row oy, only if that frame has no wing art yet. */
    public static void fillIfEmpty(BufferedImage im, int oy) {
        int[] f = im.getRGB(0, oy, W, H, null, 0, W);
        if (hasArt(f)) return;
        generate(f);
        im.setRGB(0, oy, W, H, f, 0, W);
    }

    /** Wing silhouette on the 10x20 face: full width near the shoulder, tapering to a rounded tip at the bottom. */
    private static boolean wing(int u, int v) {
        if (u < 0 || u > 9 || v < 0 || v > 19) return false;
        double half = v < 6 ? 5.0 : Math.max(1.2, 5.0 - (v - 5) * 0.29);
        if (v >= 18) half = Math.min(half, 1.6);
        return Math.abs(u + 0.5 - 5.0) <= half;
    }
}
