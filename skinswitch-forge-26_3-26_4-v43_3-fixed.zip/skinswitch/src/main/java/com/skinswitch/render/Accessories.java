package com.skinswitch.render;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cosmetics: 30 purely visual accessories worn on the player model (no abilities, no effects, nothing that reacts to the game).
 * Same style as {@link PetModels}: pure Java (no Minecraft classes), every accessory is a handful of coloured boxes in
 * Minecraft model pixels (16 px = 1 block). Each box is fixed to a body part (head / torso / right arm) so it follows the
 * player's movement and the body proportions of {@code UiPrefs}. Used by {@link PreviewRenderer}.
 *
 * Local coordinates inside a model: HEAD: y 0..8 = the head (x +-4, z +-4), BODY: y 0..12 = the torso (x +-4, z +-2),
 * RARM: x/y relative to the top-centre of the arm. z+ = front, x+ = the character's left.
 */
public final class Accessories {
    private Accessories() {}

    public static final int HEAD = 0, BODY = 1, RARM = 2; // same ids as PreviewRenderer

    public static final String[] IDS = {
        "royal_crown", "halo", "classic_hat", "headphones", "cat_ears", "future_glasses", "head_star", "winter_hat", "aviator_glasses", "headband",
        "cowboy_hat", "flower_crown", "mini_planet", "floating_crystal", "knight_helmet", "headset", "backpack", "scarf", "royal_cape", "parrot",
        "baby_dragon", "quiver", "back_sword", "shoulder_armor", "earring", "samurai_mask", "robot_mask", "neck_collar", "shoulder_strap", "geo_halo"
    };

    // ---- info: menu category, the body "slots" an accessory occupies (two accessories sharing a slot conflict), height ----
    private record Info(String cat, String[] slots, float lift) {}
    private static final Map<String, Info> INFO = new LinkedHashMap<>();
    private static void reg(String id, String cat, float lift, String... slots) { INFO.put(id, new Info(cat, slots, lift)); }
    static {
        reg("royal_crown", "head", 4.6f, "hat");
        reg("halo", "float", 0f, "float");
        reg("classic_hat", "head", 7.6f, "hat");
        reg("headphones", "head", 1.9f, "hat", "band", "ear");
        reg("cat_ears", "head", 3.9f, "hat");
        reg("future_glasses", "face", 0f, "face");
        reg("head_star", "float", 0f, "float");
        reg("winter_hat", "head", 7.2f, "hat", "band");
        reg("aviator_glasses", "face", 0f, "face");
        reg("headband", "head", 0f, "band");
        reg("cowboy_hat", "head", 6.2f, "hat");
        reg("flower_crown", "head", 2.2f, "hat");
        reg("mini_planet", "float", 0f, "float");
        reg("floating_crystal", "float", 0f, "float");
        reg("knight_helmet", "head", 5.5f, "hat", "band", "ear", "face");
        reg("headset", "head", 1.9f, "hat", "band", "ear");
        reg("backpack", "back", 0f, "back", "back2", "chest");
        reg("scarf", "neck", 0f, "neck");
        reg("royal_cape", "back", 0f, "cape");
        reg("parrot", "shoulder", 0f, "shoulderR");
        reg("baby_dragon", "shoulder", 0f, "shoulderL");
        reg("quiver", "back", 0f, "back");
        reg("back_sword", "back", 0f, "back2");
        reg("shoulder_armor", "shoulder", 0f, "shoulderR");
        reg("earring", "ear", 0f, "ear");
        reg("samurai_mask", "face", 0f, "face");
        reg("robot_mask", "face", 0f, "face");
        reg("neck_collar", "neck", 0f, "neck");
        reg("shoulder_strap", "body", 0f, "chest");
        reg("geo_halo", "float", 0f, "float");
    }

    public static boolean exists(String id) { return id != null && INFO.containsKey(id); }
    /** Menu category: head, face, float, neck, back, shoulder, ear, body. */
    public static String category(String id) { return INFO.get(id).cat; }

    /** True when the two accessories would overlap on the body (same slot). */
    public static boolean conflict(String a, String b) {
        if (a.equals(b)) return true;
        for (String s : INFO.get(a).slots) for (String t : INFO.get(b).slots) if (s.equals(t)) return true;
        return false;
    }

    /** Puts on / takes off an accessory. Putting one on removes the ones it conflicts with. Returns the new list. */
    public static List<String> toggle(List<String> cur, String id) {
        List<String> out = new ArrayList<>();
        if (!exists(id)) return normalize(cur);
        boolean had = cur.contains(id);
        for (String o : normalize(cur)) if (!o.equals(id) && (had || !conflict(o, id))) out.add(o);
        if (!had) out.add(id);
        return out;
    }

    /** Drops unknown ids, duplicates and conflicting entries (the first one wins), keeps the catalogue order. */
    public static List<String> normalize(List<String> in) {
        List<String> out = new ArrayList<>();
        if (in == null) return out;
        for (String id : IDS) {
            if (!in.contains(id)) continue;
            boolean bad = false;
            for (String o : out) if (conflict(o, id)) { bad = true; break; }
            if (!bad) out.add(id);
        }
        return out;
    }

    public static List<String> parse(String csv) {
        List<String> l = new ArrayList<>();
        if (csv != null) for (String s : csv.split(",")) { s = s.trim(); if (exists(s) && !l.contains(s)) l.add(s); }
        return normalize(l);
    }
    public static String join(List<String> ids) { return String.join(",", normalize(ids)); }

    /** How far (model px, un-scaled) the highest worn piece of headgear rises above the top of the head. */
    public static float hatLift(List<String> ids) {
        float m = 0;
        if (ids != null) for (String id : ids) if (exists(id) && Arrays.asList(INFO.get(id).slots).contains("hat")) m = Math.max(m, INFO.get(id).lift);
        return m;
    }

    // ---- built boxes ----------------------------------------------------------------------------------------------
    /** One box of a worn accessory (final coordinates). Tilted boxes are rotated by {@code tiltF} about (tcx,tcy,tcz) first. */
    public static final class ABox {
        public final float x0, y0, z0, x1, y1, z1, px, py, pz, noise, cell, lw, lh, tcx, tcy, tcz;
        public final int part, rgb;
        public final boolean lit;
        public final double[][] tiltF, tiltT; // null = not tilted
        private final PetModels.Decal[] decals;

        ABox(Raw r, Frame f) {
            x0 = f.ox + r.x0 * f.sx; x1 = f.ox + r.x1 * f.sx;
            y0 = f.oy + r.y0 * f.sy; y1 = f.oy + r.y1 * f.sy;
            z0 = f.oz + r.z0 * f.sz; z1 = f.oz + r.z1 * f.sz;
            px = f.px; py = f.py; pz = f.pz;
            part = r.part; rgb = r.rgb; lit = r.lit; noise = r.noise;
            cell = (f.sx + f.sy + f.sz) / 3f;
            lw = r.x1 - r.x0; lh = r.y1 - r.y0;
            decals = r.decals.isEmpty() ? null : r.decals.toArray(new PetModels.Decal[0]);
            if (r.tilted) {
                tiltF = mul(rotY(r.ty), mul(rotZ(r.tz), rotX(r.tx)));
                tiltT = transpose(tiltF);
                tcx = f.ox + r.cx * f.sx; tcy = f.oy + r.cy * f.sy; tcz = f.oz + r.cz * f.sz;
            } else { tiltF = null; tiltT = null; tcx = tcy = tcz = 0; }
        }

        /** Colour of the face hit at (hx,hy,hz) in the box's own (un-tilted) frame. */
        public int color(int axis, int sign, double hx, double hy, double hz) {
            int c = rgb;
            boolean hit = false;
            if (decals != null && axis == 2 && sign > 0) {
                float u = (float) ((hx - x0) / (x1 - x0)) * lw, v = (1f - (float) ((hy - y0) / (y1 - y0))) * lh;
                for (PetModels.Decal d : decals) if (u >= d.u0() && u < d.u1() && v >= d.v0() && v < d.v1()) { c = d.rgb(); hit = true; }
            }
            if (!hit && noise > 0f) {
                int n = hash((int) Math.floor(hx / cell), (int) Math.floor(hy / cell), (int) Math.floor(hz / cell), axis * 2 + (sign > 0 ? 1 : 0)) & 255;
                double k = 1 + (n / 255.0 - 0.5) * noise;
                int r = (int) Math.min(255, ((c >> 16) & 255) * k), g = (int) Math.min(255, ((c >> 8) & 255) * k), b = (int) Math.min(255, (c & 255) * k);
                c = r << 16 | g << 8 | b;
            }
            return 0xFF000000 | c;
        }
        private static int hash(int a, int b, int c, int d) {
            int h = a * 374761393 ^ b * 668265263 ^ c * 1274126177 ^ d * 40503;
            h = (h ^ (h >>> 13)) * 1274126177;
            return h ^ (h >>> 16);
        }
    }

    /** Builds the boxes of the worn accessories for a body with proportions {@code sc} (see PreviewRenderer). petH = height of a pet on the head (world px) or 0. */
    public static ABox[] build(List<String> ids, float[][] sc, boolean slim, float petH) {
        List<String> worn = normalize(ids);
        if (worn.isEmpty()) return new ABox[0];
        float hw = sc[0][0], hh = sc[0][1], hd = sc[0][2], tw = sc[1][0], th = sc[1][1], td = sc[1][2];
        float aws = sc[2][0], ah = sc[2][1], ad = sc[2][2], lh = sc[3][1];
        float legH = 12 * lh, neck = legH + 12 * th, armW = (slim ? 3 : 4) * aws, cxR = -4 * tw - armW / 2f;
        Frame[] fr = new Frame[3];
        fr[HEAD] = new Frame(0, neck, 0, hw, hh, hd, 0, neck, 0);
        fr[BODY] = new Frame(0, legH, 0, tw, th, td, 0, neck, 0);
        fr[RARM] = new Frame(cxR, neck, 0, aws, ah, ad, cxR, neck - 2 * ah, 0);
        Ctx ctx = new Ctx();
        ctx.fy = 8 + hatLift(worn) + (petH > 0 ? petH / hh + 0.8f : 0f) + 1.6f; // floating pieces hover above hats and pets
        ctx.zb = worn.contains("royal_cape") ? 1.3f : 0f;                       // back pieces sit behind a cape
        List<ABox> out = new ArrayList<>();
        for (String id : worn) {
            M m = new M();
            make(id, ctx, m);
            for (Raw r : m.out) out.add(new ABox(r, fr[r.part]));
        }
        return out.toArray(new ABox[0]);
    }

    private record Frame(float ox, float oy, float oz, float sx, float sy, float sz, float px, float py, float pz) {}
    private static final class Ctx { float fy, zb; }

    // ---- model building --------------------------------------------------------------------------------------------
    private static final class Raw {
        float x0, y0, z0, x1, y1, z1, noise = 0.06f, tz, tx, ty, cx, cy, cz;
        int part, rgb;
        boolean lit, tilted;
        final List<PetModels.Decal> decals = new ArrayList<>();
    }

    private static final class M {
        final List<Raw> out = new ArrayList<>();
        int part = HEAD;
        Raw last;
        boolean g;
        float gtz, gtx, gty, gcx, gcy, gcz;

        M part(int p) { part = p; return this; }
        M b(float x0, float y0, float z0, float x1, float y1, float z1, int rgb) {
            Raw r = new Raw();
            r.part = part; r.x0 = x0; r.y0 = y0; r.z0 = z0; r.x1 = x1; r.y1 = y1; r.z1 = z1; r.rgb = rgb;
            if (g) { r.tilted = true; r.tz = gtz; r.tx = gtx; r.ty = gty; r.cx = gcx; r.cy = gcy; r.cz = gcz; }
            out.add(r); last = r; return this;
        }
        M lit() { last.lit = true; return this; }
        M nz(float n) { last.noise = n; return this; }
        M dec(float u0, float v0, float u1, float v1, int rgb) { last.decals.add(new PetModels.Decal(u0, v0, u1, v1, rgb, false)); return this; }
        /** Everything added until end() is rotated as one piece about (cx,cy,cz): z first, then x, then y (radians). */
        M grp(float tz, float tx, float ty, float cx, float cy, float cz) { g = true; gtz = tz; gtx = tx; gty = ty; gcx = cx; gcy = cy; gcz = cz; return this; }
        M end() { g = false; return this; }
        /** Tilts the last box on its own about its centre. */
        M tilt(float tz, float tx, float ty) {
            Raw r = last; r.tilted = true; r.tz = tz; r.tx = tx; r.ty = ty;
            r.cx = (r.x0 + r.x1) / 2; r.cy = (r.y0 + r.y1) / 2; r.cz = (r.z0 + r.z1) / 2; return this;
        }
        /** Adds the mirror image (x -> -x) of the last box. */
        M pair() {
            Raw s = last, r = new Raw();
            r.part = s.part; r.x0 = -s.x1; r.x1 = -s.x0; r.y0 = s.y0; r.y1 = s.y1; r.z0 = s.z0; r.z1 = s.z1;
            r.rgb = s.rgb; r.lit = s.lit; r.noise = s.noise;
            float w = s.x1 - s.x0;
            for (PetModels.Decal d : s.decals) r.decals.add(new PetModels.Decal(w - d.u1(), d.v0(), w - d.u0(), d.v1(), d.rgb(), false));
            if (s.tilted) { r.tilted = true; r.tz = -s.tz; r.tx = s.tx; r.ty = -s.ty; r.cx = -s.cx; r.cy = s.cy; r.cz = s.cz; }
            out.add(r); last = r; return this;
        }
        /** Horizontal ring of n boxes (a polygon that reads as a circle) around the vertical axis through (cx,cz). */
        M ringH(float cx, float y, float cz, float rad, int n, float h, float thick, int rgb, float rot) {
            float len = (float) (2 * rad * Math.tan(Math.PI / n)) * 1.06f;
            for (int i = 0; i < n; i++) {
                double a = rot + i * 2 * Math.PI / n;
                float x = cx + (float) (rad * Math.cos(a)), z = cz + (float) (rad * Math.sin(a));
                b(x - len / 2, y, z - thick / 2, x + len / 2, y + h, z + thick / 2, rgb).tilt(0, 0, (float) -(a + Math.PI / 2));
            }
            return this;
        }
        /** Vertical ring (in the x/y plane, facing front) around (cx,cy) at depth z. */
        M ringV(float cx, float cy, float z, float rad, int n, float thick, float depth, int rgb, float rot) {
            float len = (float) (2 * rad * Math.tan(Math.PI / n)) * 1.06f;
            for (int i = 0; i < n; i++) {
                double a = rot + i * 2 * Math.PI / n;
                float x = cx + (float) (rad * Math.cos(a)), y = cy + (float) (rad * Math.sin(a));
                b(x - len / 2, y - thick / 2, z - depth / 2, x + len / 2, y + thick / 2, z + depth / 2, rgb).tilt((float) (a + Math.PI / 2), 0, 0);
            }
            return this;
        }
        /** Pixel art: rows from the top, '#' = a cell. Cells of a row are merged. Faces front, centred on x = cx, base on y. */
        M bitmap(String[] rows, float cx, float y, float z, float cell, float depth, int rgb) {
            int w = rows[0].length(), n = rows.length;
            for (int r = 0; r < n; r++) {
                int i = 0;
                while (i < w) {
                    if (rows[r].charAt(i) != '#') { i++; continue; }
                    int j = i; while (j < w && rows[r].charAt(j) == '#') j++;
                    float x0 = cx + (i - w / 2f) * cell, x1 = cx + (j - w / 2f) * cell, y0 = y + (n - 1 - r) * cell;
                    b(x0, y0, z - depth / 2, x1, y0 + cell, z + depth / 2, rgb);
                    i = j;
                }
            }
            return this;
        }
    }

    private static int c(int r, int g, int b) { return r << 16 | g << 8 | b; }
    private static final int GOLD = c(252, 200, 40), GOLD_D = c(196, 142, 24), GOLD_L = c(255, 232, 120), STEEL = c(150, 158, 172), STEEL_D = c(104, 112, 126),
        LEATHER = c(128, 84, 48), LEATHER_D = c(78, 50, 30), RED = c(200, 36, 48), BLACK = c(28, 28, 34);

    private static void make(String id, Ctx x, M m) {
        float fy = x.fy, zb = x.zb;
        switch (id) {
            case "royal_crown" -> {
                m.part(HEAD);
                m.b(-4.8f, 8, 4.3f, 4.8f, 9.6f, 4.8f, GOLD).nz(0.05f).dec(4.0f, 0.3f, 5.6f, 1.3f, c(220, 30, 50)).dec(1.5f, 0.4f, 2.5f, 1.2f, c(40, 90, 220)).dec(7.1f, 0.4f, 8.1f, 1.2f, c(40, 90, 220));
                m.b(-4.8f, 8, -4.8f, 4.8f, 9.6f, -4.3f, GOLD).nz(0.05f);
                m.b(4.3f, 8, -4.8f, 4.8f, 9.6f, 4.8f, GOLD).nz(0.05f);
                m.b(-4.8f, 8, -4.8f, -4.3f, 9.6f, 4.8f, GOLD).nz(0.05f);
                m.b(-4.9f, 8, -4.9f, 4.9f, 8.5f, 4.9f, GOLD_D); // lower rim
                float[] px = {-3.6f, -1.2f, 1.2f, 3.6f};
                for (float p : px) {
                    float h = Math.abs(p) < 2 ? 3.2f : 2.2f;
                    m.b(p - 0.8f, 9.6f, 4.3f, p + 0.8f, 9.6f + h, 4.8f, GOLD).nz(0.05f);
                    m.b(p - 0.8f, 9.6f, -4.8f, p + 0.8f, 9.6f + h, -4.3f, GOLD).nz(0.05f);
                }
                float[] pz = {-2.4f, 0f, 2.4f};
                for (float p : pz) {
                    float h = p == 0 ? 3.2f : 2.2f;
                    m.b(4.3f, 9.6f, p - 0.8f, 4.8f, 9.6f + h, p + 0.8f, GOLD).nz(0.05f);
                    m.b(-4.8f, 9.6f, p - 0.8f, -4.3f, 9.6f + h, p + 0.8f, GOLD).nz(0.05f);
                }
                m.b(-0.6f, 12.8f, 4.3f, 0.6f, 13.2f, 4.8f, c(220, 30, 50)).lit(); // gem on the tallest point
                m.b(-0.55f, 9.7f, 4.8f, 0.55f, 10.8f, 5.0f, c(220, 30, 50)).lit();
            }
            case "halo" -> {
                m.part(HEAD);
                m.ringH(0, fy + 0.2f, 0, 5.4f, 16, 0.9f, 1.3f, c(255, 226, 110), 0).lit();
                m.ringH(0, fy + 0.35f, 0, 5.4f, 16, 0.6f, 0.6f, c(255, 244, 190), 0.1f).lit();
            }
            case "classic_hat" -> {
                m.part(HEAD);
                m.b(-6.4f, 8, -6.4f, 6.4f, 8.9f, 6.4f, BLACK).nz(0.05f);
                m.b(-4.4f, 8.9f, -4.4f, 4.4f, 15.2f, 4.4f, BLACK).nz(0.05f);
                m.b(-4.55f, 8.9f, -4.55f, 4.55f, 10.6f, 4.55f, c(150, 30, 45));
                m.b(-1.1f, 9.3f, 4.55f, 1.1f, 10.3f, 4.75f, GOLD);
                m.b(-4.4f, 15.2f, -4.4f, 4.4f, 15.5f, 4.4f, c(52, 52, 60));
            }
            case "headphones" -> {
                m.part(HEAD);
                m.b(4.4f, 5.4f, -0.7f, 5.2f, 9.0f, 0.7f, c(40, 42, 52));
                m.pair();
                m.b(-5.2f, 9.0f, -0.7f, 5.2f, 9.8f, 0.7f, c(40, 42, 52));
                m.b(4.5f, 2.0f, -2.4f, 6.6f, 6.4f, 2.4f, c(62, 66, 84)).nz(0.08f);
                m.pair();
                m.b(4.5f, 2.4f, -2.0f, 4.9f, 6.0f, 2.0f, c(190, 50, 62));
                m.pair();
                m.b(6.6f, 3.0f, -1.5f, 6.9f, 5.4f, 1.5f, c(240, 80, 92)).lit();
                m.pair();
            }
            case "cat_ears" -> {
                m.part(HEAD);
                m.grp(-0.2f, 0, 0, 2.5f, 8, -0.7f);
                m.b(1.0f, 7.8f, -1.8f, 4.0f, 9.4f, 0.4f, BLACK_FUR());
                m.b(1.4f, 9.4f, -1.5f, 3.6f, 10.8f, 0.1f, BLACK_FUR());
                m.b(1.9f, 10.8f, -1.2f, 3.1f, 11.8f, -0.2f, BLACK_FUR());
                m.b(1.5f, 8.0f, 0.4f, 3.5f, 9.8f, 0.7f, c(240, 150, 172));
                m.b(2.0f, 9.8f, 0.1f, 3.1f, 10.7f, 0.4f, c(240, 150, 172));
                m.end();
                // mirrored ear
                m.grp(0.2f, 0, 0, -2.5f, 8, -0.7f);
                m.b(-4.0f, 7.8f, -1.8f, -1.0f, 9.4f, 0.4f, BLACK_FUR());
                m.b(-3.6f, 9.4f, -1.5f, -1.4f, 10.8f, 0.1f, BLACK_FUR());
                m.b(-3.1f, 10.8f, -1.2f, -1.9f, 11.8f, -0.2f, BLACK_FUR());
                m.b(-3.5f, 8.0f, 0.4f, -1.5f, 9.8f, 0.7f, c(240, 150, 172));
                m.b(-3.1f, 9.8f, 0.1f, -2.0f, 10.7f, 0.4f, c(240, 150, 172));
                m.end();
            }
            case "future_glasses" -> {
                m.part(HEAD);
                m.b(-4.9f, 2.2f, 4.6f, 4.9f, 4.8f, 5.3f, c(30, 34, 50));
                m.b(-4.3f, 2.7f, 5.3f, 4.3f, 4.3f, 5.6f, c(60, 225, 255)).lit().dec(0.8f, 0.2f, 2.2f, 0.6f, c(235, 255, 255)).dec(6.2f, 1.0f, 7.8f, 1.4f, c(255, 80, 200));
                m.b(4.55f, 3.0f, -4.6f, 5.1f, 4.3f, 5.3f, c(30, 34, 50));
                m.pair();
                m.b(4.9f, 3.0f, 3.8f, 5.2f, 4.1f, 5.4f, c(255, 80, 200)).lit();
                m.pair();
            }
            case "head_star" -> {
                m.part(HEAD);
                String[] star = {
                    "....#....", "...###...", "...###...", "#########", ".#######.", "..#####..", "..#####..", ".###.###.", ".##...##." };
                m.bitmap(star, 0, fy + 0.6f, 0, 1.15f, 1.5f, c(255, 222, 60)).lit();
            }
            case "winter_hat" -> {
                m.part(HEAD);
                m.b(-4.9f, 6.8f, -4.9f, 4.9f, 8.6f, 4.9f, c(238, 238, 244)).nz(0.14f);
                m.b(-4.65f, 8.6f, -4.65f, 4.65f, 10.8f, 4.65f, c(196, 38, 52)).nz(0.12f);
                m.b(-4.72f, 9.4f, -4.72f, 4.72f, 10.0f, 4.72f, c(238, 238, 244)).nz(0.1f);
                m.b(-3.4f, 10.8f, -3.4f, 3.4f, 12.2f, 3.4f, c(196, 38, 52)).nz(0.12f);
                m.b(-1.6f, 12.2f, -1.6f, 1.6f, 15.2f, 1.6f, c(245, 245, 250)).nz(0.22f);
            }
            case "aviator_glasses" -> {
                m.part(HEAD);
                m.b(-4.0f, 2.1f, 4.6f, -0.5f, 4.7f, 4.95f, c(72, 88, 84)).dec(0.4f, 0.3f, 1.2f, 1.0f, c(130, 150, 146)).dec(2.0f, 1.6f, 2.8f, 2.0f, c(110, 126, 122));
                m.pair();
                m.b(-4.2f, 4.7f, 4.6f, -0.3f, 5.0f, 5.0f, GOLD_D); m.pair();
                m.b(-4.2f, 1.9f, 4.6f, -0.3f, 2.1f, 5.0f, GOLD_D); m.pair();
                m.b(-4.2f, 2.0f, 4.6f, -3.95f, 4.8f, 5.0f, GOLD_D); m.pair();
                m.b(-0.55f, 2.0f, 4.6f, -0.3f, 4.8f, 5.0f, GOLD_D); m.pair();
                m.b(-0.35f, 3.9f, 4.6f, 0.35f, 4.5f, 5.0f, GOLD_D);
                m.b(4.2f, 3.5f, -4.6f, 4.65f, 4.4f, 5.0f, GOLD_D);
                m.pair();
            }
            case "headband" -> {
                m.part(HEAD);
                m.b(-4.7f, 6.0f, -4.7f, 4.7f, 7.2f, 4.7f, c(200, 40, 40)).nz(0.08f).dec(3.6f, 0.2f, 6.0f, 0.4f, c(250, 245, 245));
                m.b(-1.1f, 5.8f, -5.8f, 1.1f, 7.4f, -4.6f, c(170, 28, 28));
                m.b(-1.0f, 2.8f, -5.5f, -0.2f, 5.9f, -4.8f, c(200, 40, 40)).tilt(0.2f, 0, 0);
                m.b(0.2f, 3.4f, -5.5f, 1.0f, 5.9f, -4.8f, c(200, 40, 40)).tilt(-0.25f, 0, 0);
            }
            case "cowboy_hat" -> {
                m.part(HEAD);
                int tan = c(190, 140, 80);
                m.b(-6.6f, 8, -6.2f, 6.6f, 8.8f, 6.2f, tan).nz(0.1f);
                m.b(5.4f, 8.8f, -5.0f, 8.0f, 9.8f, 5.0f, tan).nz(0.1f);
                m.b(-8.0f, 8.8f, -5.0f, -5.4f, 9.8f, 5.0f, tan).nz(0.1f);
                m.b(-4.4f, 8.8f, -4.4f, 4.4f, 13.2f, 4.4f, tan).nz(0.1f);
                m.b(-3.4f, 13.2f, -4.4f, 3.4f, 13.9f, 4.4f, tan).nz(0.1f);
                m.b(-4.55f, 8.8f, -4.55f, 4.55f, 10.2f, 4.55f, c(86, 52, 32));
                m.b(-1.0f, 9.0f, 4.55f, 1.0f, 10.0f, 4.75f, GOLD);
                m.b(-0.1f, 12.8f, -4.45f, 0.1f, 13.2f, 4.45f, c(160, 112, 62)); // crease on top
            }
            case "flower_crown" -> {
                m.part(HEAD);
                int leaf = c(70, 150, 70);
                m.b(-4.8f, 7.9f, 4.3f, 4.8f, 9.0f, 4.8f, leaf).nz(0.14f);
                m.b(-4.8f, 7.9f, -4.8f, 4.8f, 9.0f, -4.3f, leaf).nz(0.14f);
                m.b(4.3f, 7.9f, -4.8f, 4.8f, 9.0f, 4.8f, leaf).nz(0.14f);
                m.b(-4.8f, 7.9f, -4.8f, -4.3f, 9.0f, 4.8f, leaf).nz(0.14f);
                int[] col = {c(245, 130, 170), c(250, 250, 250), c(250, 215, 60), c(165, 110, 225)};
                float[] fx = {-3.4f, -1.1f, 1.1f, 3.4f};
                for (int i = 0; i < 4; i++) {
                    flower(m, fx[i], 8.3f, 4.8f, col[i], 0, 1);
                    flower(m, fx[3 - i], 8.3f, -4.8f, col[i], 0, -1);
                }
                float[] fz = {-2.4f, 0f, 2.4f};
                for (int i = 0; i < 3; i++) {
                    flower(m, 4.8f, 8.3f, fz[i], col[(i + 1) % 4], 1, 0);
                    flower(m, -4.8f, 8.3f, fz[i], col[(i + 3) % 4], -1, 0);
                }
            }
            case "mini_planet" -> {
                m.part(HEAD);
                float cy = fy + 4.8f, r = 3.6f;
                for (int iy = -4; iy <= 4; iy++) for (int iz = -4; iz <= 4; iz++) {
                    int run = -1, start = 0;
                    for (int ix = -4; ix <= 5; ix++) {
                        int col = (ix <= 4 && ix * ix + iy * iy + iz * iz <= r * r) ? planetColor(ix, iy, iz) : -1;
                        if (col != run) {
                            if (run >= 0) m.b(start - 0.5f, cy + iy - 0.5f, iz - 0.5f, ix - 0.5f, cy + iy + 0.5f, iz + 0.5f, run).nz(0.05f);
                            run = col; start = ix;
                        }
                    }
                }
                m.grp(0.45f, 0.25f, 0, 0, cy, 0).ringH(0, cy - 0.4f, 0, 6.6f, 18, 0.7f, 1.3f, c(240, 200, 120), 0).end();
                m.grp(0.45f, 0.25f, 0, 0, cy, 0).ringH(0, cy - 0.4f, 0, 7.8f, 20, 0.7f, 0.8f, c(205, 160, 100), 0).end();
            }
            case "floating_crystal" -> {
                m.part(HEAD);
                float cy = fy + 4.4f;
                float[][] layer = {{0.8f, -3.8f, -2.5f}, {1.8f, -2.5f, -1.0f}, {2.6f, -1.0f, 1.0f}, {1.8f, 1.0f, 2.5f}, {0.8f, 2.5f, 3.8f}};
                int[] col = {c(120, 230, 255), c(100, 195, 255), c(140, 150, 255), c(170, 120, 255), c(215, 150, 255)};
                for (int i = 0; i < 5; i++) m.b(-layer[i][0], cy + layer[i][1], -layer[i][0], layer[i][0], cy + layer[i][2], layer[i][0], col[i]).lit();
                m.b(-1.9f, cy - 0.7f, 2.6f, -0.9f, cy + 0.7f, 2.9f, c(255, 255, 255)).lit();
                m.b(4.0f, cy + 1.2f, -0.6f, 5.2f, cy + 2.4f, 0.6f, c(120, 230, 255)).lit();
                m.b(-5.0f, cy - 2.4f, -0.5f, -4.0f, cy - 1.4f, 0.5f, c(215, 150, 255)).lit();
            }
            case "knight_helmet" -> {
                m.part(HEAD);
                m.b(-4.9f, 0.2f, -4.9f, 4.9f, 9.4f, 4.9f, STEEL).nz(0.08f).dec(1.2f, 4.7f, 8.6f, 5.7f, c(18, 18, 24)).dec(0.6f, 4.4f, 1.2f, 6.0f, STEEL_D).dec(8.6f, 4.4f, 9.2f, 6.0f, STEEL_D)
                    .dec(6.2f, 6.9f, 6.8f, 7.4f, c(30, 30, 36)).dec(7.2f, 6.9f, 7.8f, 7.4f, c(30, 30, 36)).dec(8.2f, 6.9f, 8.8f, 7.4f, c(30, 30, 36));
                m.b(-0.7f, 9.4f, -4.5f, 0.7f, 11.4f, 4.5f, STEEL_D);
                m.b(-0.6f, 2.0f, 4.9f, 0.6f, 6.0f, 5.3f, STEEL_D);
                m.b(-5.0f, 3.6f, -5.0f, 5.0f, 4.0f, 5.0f, GOLD_D).nz(0.04f);
                m.b(-0.9f, 11.4f, -3.4f, 0.9f, 13.4f, 0.6f, c(200, 30, 36)).nz(0.14f);
                m.b(-0.9f, 11.0f, -4.6f, 0.9f, 12.6f, -3.0f, c(176, 24, 30)).nz(0.14f);
            }
            case "headset" -> {
                m.part(HEAD);
                m.b(4.4f, 5.4f, -0.7f, 5.2f, 9.0f, 0.7f, c(236, 236, 246));
                m.pair();
                m.b(-5.2f, 9.0f, -0.7f, 5.2f, 9.8f, 0.7f, c(236, 236, 246));
                m.b(4.5f, 2.6f, -1.9f, 6.0f, 6.0f, 1.9f, c(250, 160, 205)).nz(0.08f);
                m.pair();
                m.b(5.0f, 6.0f, -1.0f, 6.2f, 7.4f, 0.0f, c(255, 190, 222)).nz(0.08f); // little ears on the cups
                m.pair();
                m.b(4.5f, 3.0f, -1.5f, 4.9f, 5.6f, 1.5f, c(110, 96, 140));
                m.pair();
                m.b(5.9f, 1.4f, 0.5f, 6.5f, 2.0f, 5.2f, c(236, 236, 246));
                m.b(3.0f, 1.4f, 4.7f, 6.5f, 2.0f, 5.2f, c(236, 236, 246));
                m.b(2.2f, 1.0f, 4.6f, 3.4f, 2.4f, 5.6f, c(40, 42, 52));
                m.b(2.3f, 1.5f, 5.6f, 2.8f, 1.9f, 5.8f, c(255, 80, 120)).lit();
            }
            case "backpack" -> {
                m.part(BODY);
                float z = -zb;
                m.b(-3.5f, 1, -6.4f + z, 3.5f, 10.4f, -2.1f + z, LEATHER).nz(0.12f);
                m.b(-3.7f, 8.0f, -6.6f + z, 3.7f, 11.0f, -2.0f + z, LEATHER_D).nz(0.1f);
                m.b(-2.6f, 1.6f, -7.3f + z, 2.6f, 5.2f, -6.4f + z, c(150, 104, 58)).nz(0.1f).dec(2.2f, 0.3f, 3.0f, 1.0f, GOLD);
                m.b(-0.5f, 7.6f, -6.8f + z, 0.5f, 8.8f, -6.5f + z, GOLD);
                m.b(-4.1f, 11.0f, -6.2f + z, 4.1f, 13.0f, -3.4f + z, c(104, 138, 92)).nz(0.14f); // bedroll
                m.b(-3.0f, 2.0f, 2.0f, -1.8f, 11.0f, 2.6f, LEATHER_D);                          // shoulder straps in front
                m.b(1.8f, 2.0f, 2.0f, 3.0f, 11.0f, 2.6f, LEATHER_D);
                m.b(-3.0f, 11.0f, -2.6f, -1.8f, 12.0f, 2.6f, LEATHER_D);
                m.b(1.8f, 11.0f, -2.6f, 3.0f, 12.0f, 2.6f, LEATHER_D);
            }
            case "scarf" -> {
                m.part(BODY);
                int red = c(196, 36, 50), cream = c(240, 232, 214);
                m.b(-4.6f, 10.2f, -2.6f, 4.6f, 12.4f, 2.6f, red).nz(0.14f);
                m.b(-4.65f, 11.2f, -2.65f, 4.65f, 11.8f, 2.65f, cream).nz(0.12f);
                m.b(0.4f, 9.4f, 2.5f, 4.0f, 11.6f, 3.4f, c(170, 28, 42)).nz(0.14f);
                for (int i = 0; i < 5; i++) m.b(1.0f, 2.4f + i * 1.4f, 2.55f, 3.4f, 3.8f + i * 1.4f, 3.2f, i % 2 == 0 ? cream : red).nz(0.12f);
                m.b(1.0f, 1.4f, 2.55f, 3.4f, 2.4f, 3.2f, red).nz(0.14f);
            }
            case "royal_cape" -> {
                m.part(BODY);
                int vel = c(160, 24, 42), fur = c(246, 244, 240);
                m.b(-5.2f, -10, -3.4f, 5.2f, 12.2f, -2.4f, vel).nz(0.07f);
                m.b(-5.2f, -10, -3.5f, 5.2f, -8.6f, -2.3f, GOLD).nz(0.05f);
                m.b(-5.3f, -10, -3.5f, -4.7f, 12.2f, -2.3f, GOLD).nz(0.05f);
                m.b(4.7f, -10, -3.5f, 5.3f, 12.2f, -2.3f, GOLD).nz(0.05f);
                m.b(-5.6f, 11.6f, -3.6f, 5.6f, 12.9f, 3.0f, fur).nz(0.2f);        // fur mantle over the shoulders
                m.dec(0.4f, 0.3f, 1.2f, 0.6f, c(40, 40, 44)).dec(2.2f, 0.7f, 3.0f, 1.0f, c(40, 40, 44)).dec(4.4f, 0.2f, 5.2f, 0.5f, c(40, 40, 44)).dec(7.0f, 0.6f, 7.8f, 0.9f, c(40, 40, 44)).dec(9.4f, 0.3f, 10.2f, 0.6f, c(40, 40, 44));
                m.b(-1.0f, 10.0f, 2.1f, 1.0f, 11.6f, 2.8f, GOLD);              // clasp
                m.b(-0.4f, 10.4f, 2.8f, 0.4f, 11.2f, 3.0f, c(220, 30, 50)).lit();
            }
            case "parrot" -> {
                m.part(BODY);
                m.b(-6.5f, 12, -0.4f, -5.6f, 12.5f, 0.6f, c(70, 70, 76));
                m.b(-7.0f, 12.4f, -1.0f, -5.0f, 16.2f, 1.2f, c(215, 35, 40)).nz(0.1f);
                m.b(-7.5f, 12.8f, -0.8f, -7.0f, 16.0f, 1.0f, c(40, 90, 205));
                m.b(-7.5f, 12.8f, -0.8f, -7.0f, 13.9f, 1.0f, c(250, 200, 40));
                m.b(-5.0f, 12.8f, -0.8f, -4.5f, 16.0f, 1.0f, c(40, 90, 205));
                m.b(-6.8f, 10.6f, -2.2f, -5.2f, 14.0f, -0.8f, c(215, 35, 40)).nz(0.1f);
                m.b(-6.5f, 9.4f, -2.7f, -5.5f, 11.4f, -1.4f, c(50, 90, 205));
                m.b(-6.9f, 16.2f, -0.7f, -5.1f, 18.2f, 1.3f, c(215, 35, 40)).nz(0.1f).dec(0.2f, 0.8f, 0.8f, 1.5f, c(245, 245, 245)).dec(1.0f, 0.8f, 1.6f, 1.5f, c(245, 245, 245));
                m.b(-6.4f, 16.9f, 1.3f, -5.6f, 17.9f, 2.5f, c(250, 210, 70));
                m.b(-6.3f, 16.5f, 1.3f, -5.7f, 16.9f, 2.1f, c(60, 60, 64));
                m.b(-6.95f, 17.3f, 0.3f, -6.85f, 17.8f, 0.8f, c(15, 15, 18));
                m.b(-5.15f, 17.3f, 0.3f, -5.05f, 17.8f, 0.8f, c(15, 15, 18));
            }
            case "baby_dragon" -> {
                m.part(BODY);
                int g = c(80, 175, 95), gd = c(40, 120, 62), cream = c(240, 225, 170);
                m.b(5.0f, 12.2f, -1.2f, 7.0f, 15.6f, 1.4f, g).nz(0.1f).dec(0.3f, 0.5f, 1.7f, 3.2f, cream);
                m.b(4.8f, 15.6f, -0.4f, 7.2f, 18.4f, 2.6f, c(94, 190, 108)).nz(0.08f).dec(0.1f, 0.5f, 0.7f, 1.1f, c(255, 222, 40)).dec(1.7f, 0.5f, 2.3f, 1.1f, c(255, 222, 40));
                m.b(5.3f, 16.0f, 2.6f, 6.7f, 17.4f, 3.6f, c(94, 190, 108)).nz(0.08f).dec(0.2f, 0.3f, 0.5f, 0.6f, c(40, 60, 40)).dec(0.9f, 0.3f, 1.2f, 0.6f, c(40, 60, 40));
                m.b(5.0f, 18.4f, 0.0f, 5.5f, 19.9f, 0.7f, c(240, 200, 120)).tilt(0.2f, 0, 0);
                m.b(6.5f, 18.4f, 0.0f, 7.0f, 19.9f, 0.7f, c(240, 200, 120)).tilt(-0.2f, 0, 0);
                for (float sy : new float[]{13.0f, 14.4f, 16.6f}) m.b(5.7f, sy, -1.9f, 6.3f, sy + 0.9f, -1.0f, gd);
                // wings, spread a little to both sides
                m.grp(-0.45f, 0, 0, 7.0f, 13.0f, -1.0f);
                m.b(7.0f, 13.0f, -2.8f, 7.4f, 17.6f, 0.2f, c(70, 150, 86)).nz(0.06f);
                m.b(7.0f, 16.9f, -2.8f, 7.5f, 17.7f, 0.4f, gd);
                m.b(7.0f, 13.0f, -0.4f, 7.5f, 17.4f, 0.4f, gd);
                m.end();
                m.grp(0.45f, 0, 0, 5.0f, 13.0f, -1.0f);
                m.b(4.6f, 13.0f, -2.8f, 5.0f, 17.6f, 0.2f, c(70, 150, 86)).nz(0.06f);
                m.b(4.5f, 16.9f, -2.8f, 5.0f, 17.7f, 0.4f, gd);
                m.b(4.5f, 13.0f, -0.4f, 5.0f, 17.4f, 0.4f, gd);
                m.end();
                m.b(5.6f, 12.0f, -2.4f, 6.4f, 13.4f, -1.2f, g);
                m.b(5.7f, 10.8f, -3.2f, 6.3f, 12.2f, -2.2f, g);
                m.b(5.5f, 9.8f, -3.6f, 6.5f, 11.0f, -2.6f, gd);
            }
            case "quiver" -> {
                m.part(BODY);
                float z = -zb;
                m.grp(0.5f, 0, 0, 0, 6, -3.8f + z);
                m.b(-1.7f, 0.5f, -5.6f + z, 1.7f, 9.5f, -2.1f + z, LEATHER).nz(0.12f);
                m.b(-1.95f, 9.5f, -5.9f + z, 1.95f, 10.2f, -1.8f + z, LEATHER_D);
                m.b(-1.8f, 0.0f, -5.7f + z, 1.8f, 0.6f, -2.0f + z, LEATHER_D);
                m.b(-1.9f, 3.4f, -5.8f + z, 1.9f, 3.9f, -1.9f + z, GOLD);
                m.b(-1.9f, 7.0f, -5.8f + z, 1.9f, 7.5f, -1.9f + z, GOLD);
                float[] ax = {-0.9f, 0.1f, 1.0f}, ah = {13.8f, 15.0f, 13.2f};
                int[] fc = {c(215, 50, 50), c(240, 240, 240), c(60, 130, 215)};
                for (int i = 0; i < 3; i++) {
                    m.b(ax[i] - 0.22f, 10.2f, -4.1f + z, ax[i] + 0.22f, ah[i], -3.7f + z, c(176, 132, 80));
                    m.b(ax[i] - 0.6f, ah[i] - 1.8f, -4.4f + z, ax[i] + 0.6f, ah[i], -3.4f + z, fc[i]).nz(0.12f);
                }
                m.end();
                m.grp(-0.59f, 0, 0, 0, 6, -2.2f);
                m.b(-0.7f, -1.5f, -2.5f, 0.7f, 13.5f, -2.0f, LEATHER_D);
                m.b(-0.5f, 5.5f, -2.7f, 0.5f, 6.6f, -2.4f, GOLD);
                m.end();
            }
            case "back_sword" -> {
                m.part(BODY);
                float z = -zb;
                m.grp(-0.62f, 0, 0, 0, 6, -3.2f + z);
                m.b(-1.2f, -3.0f, -3.9f + z, 1.2f, 14.0f, -2.3f + z, c(66, 44, 36)).nz(0.1f);
                m.b(-1.35f, -3.4f, -4.0f + z, 1.35f, -1.8f, -2.2f + z, GOLD);
                m.b(-1.35f, 11.8f, -4.0f + z, 1.35f, 12.8f, -2.2f + z, GOLD);
                m.b(-3.2f, 14.0f, -4.2f + z, 3.2f, 15.2f, -2.5f + z, GOLD).nz(0.05f);
                m.b(-0.7f, 15.2f, -3.9f + z, 0.7f, 18.6f, -2.9f + z, c(150, 40, 40)).nz(0.1f);
                m.b(-0.85f, 16.2f, -4.0f + z, 0.85f, 16.6f, -2.8f + z, c(60, 20, 20));
                m.b(-0.85f, 17.4f, -4.0f + z, 0.85f, 17.8f, -2.8f + z, c(60, 20, 20));
                m.b(-1.1f, 18.6f, -4.1f + z, 1.1f, 19.8f, -2.7f + z, GOLD).nz(0.05f);
                m.b(-0.4f, 18.9f, -4.3f + z, 0.4f, 19.5f, -4.1f + z, c(60, 110, 230)).lit();
                m.end();
            }
            case "shoulder_armor" -> {
                m.part(RARM);
                m.b(-2.9f, 0.1f, -3.0f, 2.5f, 1.5f, 3.0f, STEEL).nz(0.08f);
                m.b(-3.0f, 1.5f, -3.1f, 2.6f, 1.9f, 3.1f, GOLD).nz(0.04f);
                m.b(-2.6f, -3.0f, -2.8f, 2.6f, 0.1f, 2.8f, STEEL).nz(0.08f).dec(0.6f, 0.4f, 1.1f, 0.9f, GOLD).dec(4.1f, 0.4f, 4.6f, 0.9f, GOLD).dec(2.3f, 1.8f, 2.9f, 2.4f, GOLD);
                m.b(-2.9f, -5.4f, -2.9f, 2.9f, -2.8f, 2.9f, STEEL_D).nz(0.08f);
                m.b(-3.0f, -5.6f, -3.0f, 3.0f, -5.2f, 3.0f, GOLD).nz(0.04f);
                m.b(-0.6f, 1.9f, -0.6f, 0.6f, 3.6f, 0.6f, STEEL);
                m.b(-0.4f, 3.6f, -0.4f, 0.4f, 4.2f, 0.4f, GOLD);
            }
            case "earring" -> {
                m.part(HEAD);
                m.b(4.6f, 3.6f, -0.8f, 5.2f, 4.1f, 0.8f, GOLD);
                m.b(4.6f, 1.6f, -0.8f, 5.2f, 2.1f, 0.8f, GOLD);
                m.b(4.6f, 1.6f, 0.8f, 5.2f, 4.1f, 1.3f, GOLD);
                m.b(4.6f, 1.6f, -1.3f, 5.2f, 4.1f, -0.8f, GOLD);
                m.b(4.7f, 0.0f, -0.5f, 5.1f, 1.6f, 0.5f, c(220, 40, 60)).lit();
                m.pair();
                m.b(-5.1f, 0.0f, -0.5f, -4.7f, 1.6f, 0.5f, c(50, 110, 235)).lit();
            }
            case "samurai_mask" -> {
                m.part(HEAD);
                int red = c(168, 28, 30);
                m.b(-4.55f, 0.1f, 4.55f, 4.55f, 5.0f, 5.5f, red).nz(0.06f).dec(1.4f, 2.4f, 7.7f, 3.8f, c(24, 12, 14)).dec(1.7f, 2.6f, 7.4f, 3.1f, c(245, 240, 230)).dec(1.7f, 3.2f, 7.4f, 3.7f, c(245, 240, 230))
                    .dec(3.9f, 0.4f, 5.2f, 1.6f, c(120, 20, 22)).dec(0.3f, 4.1f, 1.0f, 4.7f, GOLD).dec(8.1f, 4.1f, 8.8f, 4.7f, GOLD);
                m.b(-4.6f, 4.9f, 4.55f, 4.6f, 5.7f, 5.4f, c(22, 18, 20));                  // brow
                m.b(-4.6f, 0.1f, -4.55f, -4.0f, 5.0f, 5.0f, red);                          // cheek guards
                m.pair();
                m.b(-3.4f, 0.6f, 5.5f, -0.4f, 1.5f, 5.9f, c(26, 20, 22)).tilt(0.18f, 0, 0); // moustache
                m.pair();
                for (int i = 0; i < 4; i++) m.b(-3.5f, -3.0f + i * 0.75f, 3.0f - i * 0.1f, 3.5f, -2.3f + i * 0.75f, 4.8f, i % 2 == 0 ? red : c(60, 22, 24)); // neck guard plates
                m.b(-3.5f, -3.0f, 3.0f, 3.5f, -2.9f, 4.8f, GOLD);
            }
            case "robot_mask" -> {
                m.part(HEAD);
                int metal = c(150, 160, 172);
                m.b(-4.9f, 0.2f, 4.55f, 4.9f, 8.2f, 5.6f, metal).nz(0.08f)
                    .dec(1.0f, 3.6f, 3.8f, 5.2f, c(20, 24, 34)).dec(6.0f, 3.6f, 8.8f, 5.2f, c(20, 24, 34))
                    .dec(1.0f, 6.0f, 8.8f, 6.3f, c(96, 104, 116)).dec(1.0f, 6.7f, 8.8f, 7.0f, c(96, 104, 116)).dec(1.0f, 7.4f, 8.8f, 7.7f, c(96, 104, 116))
                    .dec(0.3f, 0.3f, 0.9f, 0.9f, c(80, 88, 100)).dec(8.9f, 0.3f, 9.5f, 0.9f, c(80, 88, 100));
                m.b(-3.4f, 4.1f, 5.6f, -1.6f, 5.1f, 5.9f, c(60, 240, 255)).lit();
                m.b(1.6f, 4.1f, 5.6f, 3.4f, 5.1f, 5.9f, c(60, 240, 255)).lit();
                m.b(-0.5f, 5.0f, 5.6f, 0.5f, 7.0f, 5.9f, c(96, 104, 116));
                m.b(4.55f, 2.0f, 1.0f, 5.3f, 6.0f, 4.7f, c(112, 120, 134)).nz(0.08f);
                m.pair();
                m.b(5.3f, 3.2f, 2.4f, 5.5f, 4.8f, 3.6f, c(60, 240, 255)).lit();
                m.pair();
            }
            case "neck_collar" -> {
                m.part(BODY);
                m.b(-5.0f, 11.6f, -2.6f, 5.0f, 12.6f, 2.6f, GOLD).nz(0.05f);
                m.b(-4.5f, 10.4f, 2.0f, 4.5f, 12.2f, 2.7f, GOLD).nz(0.05f);
                m.b(-3.9f, 9.0f, 2.0f, 3.9f, 10.4f, 2.8f, c(30, 70, 170));
                m.b(-3.2f, 7.8f, 2.0f, 3.2f, 9.0f, 2.9f, c(40, 190, 180));
                m.b(-2.5f, 6.8f, 2.0f, 2.5f, 7.8f, 3.0f, c(190, 40, 40));
                for (int i = -2; i <= 2; i++) m.b(i * 1.0f - 0.4f, 5.2f - (i == 0 ? 0.6f : Math.abs(i) == 1 ? 0.2f : 0f), 2.0f, i * 1.0f + 0.4f, 6.8f, 3.0f, GOLD);
                m.b(-4.0f, 9.6f, -2.7f, 4.0f, 11.6f, -2.0f, c(30, 70, 170));
                m.b(-4.0f, 9.0f, -2.7f, 4.0f, 9.6f, -2.0f, GOLD);
            }
            case "shoulder_strap" -> {
                m.part(BODY);
                m.grp(-0.59f, 0, 0, 0, 6, 2.4f);
                m.b(-0.9f, -1.2f, 2.0f, 0.9f, 13.2f, 2.65f, LEATHER).nz(0.1f);
                m.b(-0.35f, -1.2f, 2.65f, 0.35f, 13.2f, 2.75f, GOLD_D);
                for (int i = 0; i < 6; i++) m.b(-0.45f, 0.4f + i * 2.4f, 2.7f, 0.45f, 1.1f + i * 2.4f, 3.0f, GOLD);
                m.b(-1.3f, 5.2f, 2.6f, 1.3f, 7.0f, 3.1f, GOLD).nz(0.04f);
                m.b(-0.6f, 5.7f, 3.1f, 0.6f, 6.5f, 3.3f, c(40, 90, 220)).lit();
                m.end();
            }
            case "geo_halo" -> {
                m.part(HEAD);
                float cy = 5.4f, z = -5.6f;
                int teal = c(40, 200, 190);
                m.ringV(0, cy, z, 7.4f, 8, 1.3f, 0.9f, GOLD, (float) (Math.PI / 8)).lit();
                m.ringV(0, cy, z + 0.05f, 5.0f, 8, 1.0f, 0.9f, teal, 0).lit();
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    float px = (float) (6.2f * Math.cos(a)), py = cy + (float) (6.2f * Math.sin(a));
                    m.b(px - 0.55f, py - 0.55f, z - 0.45f, px + 0.55f, py + 0.55f, z + 0.45f, c(255, 240, 160)).tilt((float) (Math.PI / 4), 0, 0).lit();
                }
                m.b(-1.0f, cy - 1.0f, z - 0.4f, 1.0f, cy + 1.0f, z + 0.4f, GOLD_L).tilt((float) (Math.PI / 4), 0, 0).lit();
            }
            default -> { }
        }
    }

    private static int BLACK_FUR() { return c(38, 38, 46); }

    private static void flower(M m, float cx, float y, float cz, int rgb, int nx, int nz) {
        m.b(cx - 0.85f, y, cz - 0.85f, cx + 0.85f, y + 1.7f, cz + 0.85f, rgb).nz(0.1f);
        float ox = nx * 0.85f, oz = nz * 0.85f;
        m.b(cx + ox - 0.35f, y + 0.5f, cz + oz - 0.35f, cx + ox + 0.35f, y + 1.2f, cz + oz + 0.35f, c(250, 190, 40)).lit();
    }

    private static int planetColor(int ix, int iy, int iz) {
        double v = Math.sin(ix * 1.7 + iy * 2.3 + iz * 1.1) + Math.sin(ix * 0.9 - iz * 2.1);
        if (iy >= 2) return c(235, 245, 250);              // polar cap
        return v > 0.9 ? c(92, 184, 92) : c(58, 128, 214);  // land / ocean
    }

    // ---- small matrix helpers (same convention as PreviewRenderer) -------------------------------------------------
    private static double[][] rotX(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{1,0,0},{0,c,-s},{0,s,c}}; }
    private static double[][] rotY(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{c,0,s},{0,1,0},{-s,0,c}}; }
    private static double[][] rotZ(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{c,-s,0},{s,c,0},{0,0,1}}; }
    private static double[][] transpose(double[][] m) { double[][] r = new double[3][3]; for (int i=0;i<3;i++) for (int j=0;j<3;j++) r[i][j]=m[j][i]; return r; }
    private static double[][] mul(double[][] a, double[][] b) { double[][] r = new double[3][3]; for (int i=0;i<3;i++) for (int j=0;j<3;j++) for (int k=0;k<3;k++) r[i][j]+=a[i][k]*b[k][j]; return r; }
}
