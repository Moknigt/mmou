package com.skinswitch.render;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Small close-up pictures (SIZE x SIZE) of animals and accessories for the Cosmetics menu: your own skin wearing just that
 * one piece, camera centred on the piece. Pure Java. Pictures are made on first use (a few per frame, see
 * {@link #beginFrame()}) and kept until the skin changes.
 */
public final class CosmeticThumbs {
    public static final int SIZE = 40, SS = 2; // SS = supersampling (rendered 2x, averaged down = smooth edges)
    private static final int PER_FRAME = 3;

    private final Map<String, int[]> cache = new HashMap<>();
    private String skinKey = "";
    private int left = PER_FRAME;

    /** Call once per frame: allows a few new pictures to be made. */
    public void beginFrame() { left = PER_FRAME; }

    /** Forget everything when the skin changes. */
    public void setSkin(String key) {
        if (!key.equals(skinKey)) { skinKey = key; cache.clear(); }
    }

    /** The picture of an accessory (null while it is still waiting for its turn). */
    public int[] item(SkinImage skin, boolean slim, String id) {
        return get("a:" + id, () -> makeItem(skin, slim, id));
    }

    /** The picture of an animal sitting on the head (null while waiting). */
    public int[] animal(SkinImage skin, boolean slim, String id) {
        return get("p:" + id, () -> makeAnimal(skin, slim, id));
    }

    private int[] get(String key, java.util.function.Supplier<int[]> make) {
        int[] v = cache.get(key);
        if (v != null || left <= 0) return v;
        left--;
        v = make.get();
        cache.put(key, v);
        return v;
    }

    // ---- rendering ---------------------------------------------------------------------------------------------------
    /** One accessory on a default-proportion character (used directly by tests and the preview image generator). */
    public static int[] makeItem(SkinImage skin, boolean slim, String id) { return makeItem(skin, slim, id, SIZE, SS); }

    /** Same at another picture size (the menu uses SIZE; bigger ones are for previews / screenshots). */
    public static int[] makeItem(SkinImage skin, boolean slim, String id, int size, int ss) {
        float[][] sc = PreviewRenderer.defaultScales();
        Accessories.ABox[] bx = Accessories.build(List.of(id), sc, slim, 0f);
        float x0 = 99, x1 = -99, y0 = 99, y1 = -99;
        for (Accessories.ABox b : bx) {
            x0 = Math.min(x0, Math.min(b.x0, b.x1)); x1 = Math.max(x1, Math.max(b.x0, b.x1));
            y0 = Math.min(y0, b.y0); y1 = Math.max(y1, b.y1);
        }
        if (bx.length == 0) { x0 = -4; x1 = 4; y0 = 24; y1 = 32; }
        double ext = Math.max(x1 - x0, y1 - y0) + 5.5;              // piece + a little of the body around it
        double cy = (y0 + y1) / 2;
        String cat = Accessories.category(id);
        boolean back = cat.equals("back") || id.equals("royal_cape");
        float yaw = back ? 158f : 20f;
        return shoot(skin, slim, yaw, null, List.of(id), cy, ext, size, ss);
    }

    public static int[] makeAnimal(SkinImage skin, boolean slim, String id) { return makeAnimal(skin, slim, id, SIZE, SS); }

    public static int[] makeAnimal(SkinImage skin, boolean slim, String id, int size, int ss) {
        float h = PetModels.height(id), half = PetModels.halfWidth(id);
        double cy = 32.4 + h / 2, ext = Math.max(h, 2 * half) + 7;
        return shoot(skin, slim, 20f, id, null, cy, ext, size, ss);
    }

    private static int[] shoot(SkinImage skin, boolean slim, float yaw, String pet, List<String> acc, double cy, double ext, int size, int ss) {
        int n = size * ss;
        double pxPerUnit = Math.min(7.0, n / ext);
        int[] big = PreviewRenderer.render(skin, null, slim, yaw, 0f, n, n, null, 0, pet, false, acc, new double[]{cy, pxPerUnit});
        return downsample(big, n, ss);
    }

    /** Box filter, alpha-weighted so the edges of a piece stay clean. */
    static int[] downsample(int[] src, int n, int f) {
        int m = n / f;
        int[] out = new int[m * m];
        for (int y = 0; y < m; y++) for (int x = 0; x < m; x++) {
            long a = 0, r = 0, g = 0, b = 0;
            for (int j = 0; j < f; j++) for (int i = 0; i < f; i++) {
                int c = src[(y * f + j) * n + x * f + i];
                int al = c >>> 24;
                a += al; r += ((c >> 16) & 255) * al; g += ((c >> 8) & 255) * al; b += (c & 255) * al;
            }
            if (a == 0) continue;
            int cnt = f * f, alpha = (int) (a / cnt);
            if (alpha < 64) continue;                                 // faint fringe -> transparent
            out[y * m + x] = 0xFF000000 | (int) (r / a) << 16 | (int) (g / a) << 8 | (int) (b / a);
        }
        return out;
    }
}
