package com.skinswitch.render;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;

/**
 * A cape texture: 64x32 (or the old 22x17 layout), optionally scaled up.
 * Animated capes are a vertical strip of frames (64 x 32*n), played at {@link #FPS}.
 */
public final class CapeImage {
    public static final float FPS = 8f;
    private final BufferedImage img;
    private final float scale;
    private final int frames;
    private final int frameHeight;
    private final boolean wide;

    public CapeImage(BufferedImage img) {
        this.img = img;
        this.wide = img.getWidth() % 64 == 0;
        this.scale = wide ? img.getWidth() / 64f : img.getWidth() / 22f;
        this.frameHeight = wide ? Math.round(32 * scale) : img.getHeight();
        this.frames = wide ? Math.max(1, img.getHeight() / frameHeight) : 1;
    }

    public static CapeImage load(Path file) throws IOException {
        BufferedImage in = ImageIO.read(file.toFile());
        if (in == null) throw new IOException("Not an image: " + file);
        return new CapeImage(in);
    }

    public int frames() { return frames; }
    /** true = old 22x17 layout (only the top-left 22x17 area of a 64x32 texture is used). */
    public boolean legacy() { return !wide; }
    public boolean animated() { return frames > 1; }

    /** All frames as a plain 64 x 32n ARGB strip (HD sampled down, old 22x17 capes placed at the top-left) - editor start point. */
    public BufferedImage toClassic() {
        BufferedImage o = new BufferedImage(64, 32 * frames, BufferedImage.TYPE_INT_ARGB);
        for (int f = 0; f < frames; f++) {
            float t = (f + 0.01f) / FPS;
            for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) {
                if (!wide && (x >= 22 || y >= 17)) continue;
                o.setRGB(x, f * 32 + y, argb(x + .5f, y + .5f, t));
            }
        }
        return o;
    }

    /** ARGB at (u,v) in 64x32 space at time t (seconds). */
    public int argb(float u, float v, float t) {
        int frame = frames > 1 ? (int) (t * FPS) % frames : 0;
        int x = Math.max(0, Math.min(img.getWidth() - 1, (int) Math.floor(u * scale)));
        int y = Math.max(0, Math.min(frameHeight - 1, (int) Math.floor(v * scale))) + frame * frameHeight;
        return img.getRGB(x, Math.min(y, img.getHeight() - 1));
    }

    /** Outer face of the cape as a 10x16 ARGB array (for thumbnails). */
    public int[] thumbnail(float t) {
        int[] o = new int[160];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 10; x++) o[y * 10 + x] = argb(1 + x + .5f, 1 + y + .5f, t) | 0xFF000000;
        return o;
    }
}
