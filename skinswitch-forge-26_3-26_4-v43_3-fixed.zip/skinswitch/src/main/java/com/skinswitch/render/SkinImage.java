package com.skinswitch.render;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;

/** A skin PNG in memory. Coordinates are always given in the classic 64x64 space; HD skins are scaled automatically. */
public final class SkinImage {
    private final BufferedImage img;
    private final int scale;

    private SkinImage(BufferedImage img, int scale) { this.img = img; this.scale = scale; }

    public static SkinImage load(Path file) throws IOException {
        BufferedImage in = ImageIO.read(file.toFile());
        if (in == null) throw new IOException("Not an image: " + file);
        return from(in);
    }

    public static SkinImage from(BufferedImage in) throws IOException {
        int w = in.getWidth(), h = in.getHeight();
        if (w < 64 || w % 64 != 0 || (h != w && h != w / 2)) throw new IOException("Bad skin size " + w + "x" + h);
        int s = w / 64;
        BufferedImage out = new BufferedImage(w, w, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) out.setRGB(x, y, in.getRGB(x, y));
        if (h == w / 2) { // legacy 64x32: build the left leg/arm as mirrored copies of the right ones
            mirrorLimb(out, s, 0, 16, 16, 48);
            mirrorLimb(out, s, 40, 16, 32, 48);
        }
        return new SkinImage(out, s);
    }

    private static void mirrorLimb(BufferedImage im, int s, int sx, int sy, int dx, int dy) {
        // faces (in classic px): top(4,0) bottom(8,0) right(0,4) front(4,4) left(8,4) back(12,4); mirrored: left<->right swap
        int[][] map = { {4,0,4,0,4,4}, {8,0,8,0,4,4}, {0,4,8,4,4,12}, {4,4,4,4,4,12}, {8,4,0,4,4,12}, {12,4,12,4,4,12} };
        for (int[] m : map) {
            for (int y = 0; y < m[5] * s; y++) for (int x = 0; x < m[4] * s; x++) {
                int srcX = (sx + m[0]) * s + x, srcY = (sy + m[1]) * s + y;
                int dstX = (dx + m[2]) * s + (m[4] * s - 1 - x), dstY = (dy + m[3]) * s + y;
                im.setRGB(dstX, dstY, im.getRGB(srcX, srcY));
            }
        }
    }

    /** The skin as a plain 64x64 ARGB image (HD skins are sampled down) - used as the starting point of the editor. */
    public BufferedImage toClassic64() {
        BufferedImage o = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) o.setRGB(x, y, img.getRGB(x * scale + scale / 2, y * scale + scale / 2));
        return o;
    }

    /** ARGB at (u,v) in 64-space (may be fractional). */
    public int argb(float u, float v) {
        int x = Math.max(0, Math.min(img.getWidth() - 1, (int) Math.floor(u * scale)));
        int y = Math.max(0, Math.min(img.getHeight() - 1, (int) Math.floor(v * scale)));
        return img.getRGB(x, y);
    }

    /** 8x8 head icon: face with hat layer composited on top. */
    public int[] headIcon() {
        int[] out = new int[64];
        for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) {
            int base = argb(8 + x + .5f, 8 + y + .5f), hat = argb(40 + x + .5f, 8 + y + .5f);
            out[y * 8 + x] = (hat >>> 24) > 127 ? (hat | 0xFF000000) : (base | 0xFF000000);
        }
        return out;
    }
}
