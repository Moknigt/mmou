package com.skinswitch.render;

/**
 * Tiny software renderer for the character preview. Orthographic ray casting against the player's boxes, so it needs
 * no OpenGL / Minecraft classes. Output is an ARGB int[] (0 = transparent).
 * Animations: 0 = standing idle (breathing arms, head bob, cape sway), 1 = walking, 2 = running.
 */
public final class PreviewRenderer {
    private record Box(float x0, float y0, float z0, float x1, float y1, float z1,
                       int tu, int tv, int w, int h, int d,
                       float px, float py, float pz, int part, boolean cape, boolean wing, boolean mirror) {}

    // part ids for animation
    private static final int HEAD = 0, BODY = 1, RARM = 2, LARM = 3, RLEG = 4, LLEG = 5, CAPE = 6;
    // elytra wings (preview of the cape editor's Elytra tab): ids after the pet slots
    private static final int LWING = PetModels.ARRAY_SIZE, RWING = PetModels.ARRAY_SIZE + 1;

    /** sc[part][axis] with part 0=head 1=torso 2=arms 3=legs and axis 0=width 1=height 2=depth (1 = normal). */
    public static float[][] defaultScales() {
        float[][] s = new float[4][3];
        for (float[] r : s) java.util.Arrays.fill(r, 1f);
        return s;
    }

    /** Vertical extent of the scaled character (32 when everything is 1). */
    private static float totalHeight(float[][] sc) { return 12 * sc[3][1] + 12 * sc[1][1] + 8 * sc[0][1]; }

    /** Half of the widest point (arm tip) of the scaled character (8 when everything is 1). */
    private static float halfWidth(boolean slim, float[][] sc) {
        float arm = 4 * sc[1][0] + (slim ? 3 : 4) * sc[2][0];
        return Math.max(Math.max(arm, 4 * sc[3][0]), 5 * sc[1][0]);
    }

    private static Box[] model(boolean slim, float[][] sc, boolean elytra) {
        float hw = sc[0][0], hh = sc[0][1], hd = sc[0][2];
        float tw = sc[1][0], th = sc[1][1], td = sc[1][2];
        float aws = sc[2][0], ah = sc[2][1], ad = sc[2][2];
        float lw = sc[3][0], lh = sc[3][1], ld = sc[3][2];
        int aw0 = slim ? 3 : 4;
        float legH = 12 * lh, torsoH = 12 * th, neck = legH + torsoH;      // feet at y=0, neck = top of the torso
        float armW = aw0 * aws, armH = 12 * ah, armY = neck - armH, armPivotY = neck - 2 * ah;
        float tx = 4 * tw, tz = 2 * td, az = 2 * ad, lz = 2 * ld;
        float armR = -tx - armW, armL = tx;                                // arm x starts
        java.util.List<Box> list = new java.util.ArrayList<>(java.util.Arrays.asList(new Box[] {
            box(-4 * hw, neck, -4 * hd, 4 * hw, neck + 8 * hh, 4 * hd, 0, 0, 8, 8, 8, 0, neck, 0, HEAD, 0f),
            box(-tx, legH, -tz, tx, neck, tz, 16, 16, 8, 12, 4, 0, neck, 0, BODY, 0f),
            box(armR, armY, -az, armR + armW, neck, az, 40, 16, aw0, 12, 4, armR + armW / 2f, armPivotY, 0, RARM, 0f),
            box(armL, armY, -az, armL + armW, neck, az, 32, 48, aw0, 12, 4, armL + armW / 2f, armPivotY, 0, LARM, 0f),
            box(-4 * lw, 0, -lz, 0, legH, lz, 0, 16, 4, 12, 4, -2 * lw, legH, 0, RLEG, 0f),
            box(0, 0, -lz, 4 * lw, legH, lz, 16, 48, 4, 12, 4, 2 * lw, legH, 0, LLEG, 0f),
            // second layer (hat, jacket, sleeves, pants)
            box(-4 * hw, neck, -4 * hd, 4 * hw, neck + 8 * hh, 4 * hd, 32, 0, 8, 8, 8, 0, neck, 0, HEAD, 0.5f),
            box(-tx, legH, -tz, tx, neck, tz, 16, 32, 8, 12, 4, 0, neck, 0, BODY, 0.25f),
            box(armR, armY, -az, armR + armW, neck, az, 40, 32, aw0, 12, 4, armR + armW / 2f, armPivotY, 0, RARM, 0.25f),
            box(armL, armY, -az, armL + armW, neck, az, 48, 48, aw0, 12, 4, armL + armW / 2f, armPivotY, 0, LARM, 0.25f),
            box(-4 * lw, 0, -lz, 0, legH, lz, 0, 32, 4, 12, 4, -2 * lw, legH, 0, RLEG, 0.25f),
            box(0, 0, -lz, 4 * lw, legH, lz, 0, 48, 4, 12, 4, 2 * lw, legH, 0, LLEG, 0.25f),
        }));
        if (elytra) {
            // vanilla elytra: two 10x20x2 wings hanging from the shoulders against the back (box inflated by 1, texture at 22,0;
            // the right wing uses the mirrored texture), tilted back 15 degrees and out 15 degrees
            float sx = 5 * tw, y1 = neck, y0 = neck - 20 * th, z1 = -tz, z0 = -tz - 2 * td;
            list.add(new Box(-sx - 1, y0 - 1, z0 - 1, sx + 1, y1 + 1, z1 + 1, 22, 0, 10, 20, 2, sx, neck, -tz, LWING, false, true, false));
            list.add(new Box(-sx - 1, y0 - 1, z0 - 1, sx + 1, y1 + 1, z1 + 1, 22, 0, 10, 20, 2, -sx, neck, -tz, RWING, false, true, true));
        } else {
            list.add(new Box(-5 * tw, neck - 16 * th, -tz - 1, 5 * tw, neck, -tz, 0, 0, 10, 16, 1, 0, neck, -tz, CAPE, true, false, false));
        }
        return list.toArray(new Box[0]);
    }

    private static Box box(float x0, float y0, float z0, float x1, float y1, float z1, int tu, int tv, int w, int h, int d,
                           float px, float py, float pz, int part, float inflate) {
        return new Box(x0 - inflate, y0 - inflate, z0 - inflate, x1 + inflate, y1 + inflate, z1 + inflate,
                       tu, tv, w, h, d, px, py, pz, part, false, false, false);
    }

    /** Renders the character. yawDeg 0 = facing the viewer, 180 = back to the viewer. */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H) {
        return render(skin, cape, slim, yawDeg, t, W, H, null);
    }

    /** Same, with per-part proportions (see {@link #defaultScales()}); null = normal proportions. */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc) {
        return render(skin, cape, slim, yawDeg, t, W, H, sc, 0);
    }

    /** Same, with an animation mode: 0 = idle, 1 = walk, 2 = run. */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc, int mode) {
        return render(skin, cape, slim, yawDeg, t, W, H, sc, mode, null);
    }

    /** Same, with a pet sitting on the head (id from {@link PetModels#IDS}; null / unknown = no pet). */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc, int mode, String pet) {
        return render(skin, cape, slim, yawDeg, t, W, H, sc, mode, pet, false);
    }

    /** Same, optionally wearing elytra wings (cape texture at 22,0) INSTEAD of the cape - the cape editor's Elytra tab. */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc, int mode, String pet, boolean elytra) {
        return render(skin, cape, slim, yawDeg, t, W, H, sc, mode, pet, elytra, null);
    }

    /** Same, also wearing cosmetic accessories (ids from {@link Accessories#IDS}; null / empty = none). */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc, int mode, String pet, boolean elytra, java.util.List<String> acc) {
        return render(skin, cape, slim, yawDeg, t, W, H, sc, mode, pet, elytra, acc, null);
    }

    /**
     * Same, with a fixed camera: view = {model y of the picture centre, pixels per model unit}. Used for the close-up
     * thumbnails of the Cosmetics menu (null = the normal auto-fit of the whole character).
     */
    public static int[] render(SkinImage skin, CapeImage cape, boolean slim, float yawDeg, float t, int W, int H, float[][] sc, int mode, String pet, boolean elytra, java.util.List<String> acc, double[] view) {
        if (sc == null) sc = defaultScales();
        int[] out = new int[W * H];
        float[] zbuf = new float[W * H];
        java.util.Arrays.fill(zbuf, Float.NEGATIVE_INFINITY);

        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(-6);
        double[][] ry = rotY(yaw), rp = rotX(pitch);
        double[][] minv = mul(transpose(ry), transpose(rp)); // view -> world (about C)
        double[][] mfwd = mul(rp, ry);

        double[] rx = new double[PetModels.ARRAY_SIZE + 2], rz = new double[PetModels.ARRAY_SIZE + 2], pdy = new double[PetModels.ARRAY_SIZE];
        double bob;
        if (mode == 1 || mode == 2) {
            // walk / run: opposite arm and leg swing, body dips when the legs are apart, cape lifts
            boolean run = mode == 2;
            double ph = t * (run ? 11.0 : 7.5), swing = Math.sin(ph);
            double legAmp = run ? 0.95 : 0.5, armAmp = run ? 0.9 : 0.45;
            rx[RLEG] = swing * legAmp; rx[LLEG] = -swing * legAmp;
            rx[RARM] = -swing * armAmp; rx[LARM] = swing * armAmp;
            rz[RARM] = 0.02; rz[LARM] = -0.02;
            rx[HEAD] = Math.sin(ph * 2) * 0.02;
            rx[CAPE] = Math.toRadians(run ? 30 : 14) + Math.sin(ph * 2) * (run ? 0.12 : 0.05);
            bob = (Math.abs(Math.cos(ph)) - 1) * (run ? 0.5 : 0.3);
        } else {
            // idle animation (vanilla-like constants)
            double breathe = Math.cos(t * 1.9) * 0.05 + 0.05, sway = Math.sin(t * 1.35) * 0.05;
            rz[RARM] = 1 * breathe + 0.02; rx[RARM] = sway;
            rz[LARM] = -1 * breathe - 0.02; rx[LARM] = -sway;
            rx[HEAD] = Math.sin(t * 1.1) * 0.03;
            rx[CAPE] = Math.toRadians(6) + Math.sin(t * 1.6) * 0.05;
            bob = Math.sin(t * 1.9) * 0.15;
        }

        if (elytra) { // wings: folded pose (15 deg back, 15 deg out), a little flutter while moving
            double flap = mode == 0 ? Math.sin(t * 1.6) * 0.03 : Math.toRadians(mode == 2 ? 22 : 8) + Math.sin(t * 7.5) * 0.04;
            rx[LWING] = rx[RWING] = Math.toRadians(15) + flap;
            rz[LWING] = Math.toRadians(15); rz[RWING] = -Math.toRadians(15);
        }
        Box[] boxes = model(slim, sc, elytra);
        // pet: sits on top of the head (a hair above it, so it also clears the hat layer) and bobs with it
        boolean hasPet = PetModels.exists(pet);
        float hat = Accessories.hatLift(acc) * sc[0][1];            // a hat / crown lifts the pet that sits on it
        PetModels.PBox[] pets = hasPet ? PetModels.build(pet, totalHeight(sc) + 0.4f + hat) : new PetModels.PBox[0];
        if (hasPet) PetModels.animate(pet, t, mode, rx, rz, pdy);
        Accessories.ABox[] abx = Accessories.build(acc, sc, slim, hasPet ? PetModels.height(pet) : 0f);
        // auto-fit: when parts are enlarged the whole character is zoomed out so it always stays in the picture
        double total = totalHeight(sc) + (hasPet ? PetModels.height(pet) + 0.4 + hat : 0), half = halfWidth(slim, sc), cy;
        if (hasPet) half = Math.max(half, PetModels.halfWidth(pet));
        for (Accessories.ABox a : abx) { total = Math.max(total, a.y1); half = Math.max(half, Math.max(Math.abs(a.x0), Math.abs(a.x1))); }
        cy = total / 2;
        double fit = Math.min(1.0, Math.min(35.0 / (total + 3), 10.5 / (half + 2.5)));
        double s = H / 38.0 * fit;
        double xLim = Math.max(10.5, half + 2.5), yLim = total / 2 + 1.5;
        if (view != null) { cy = view[0]; s = view[1]; xLim = yLim = 1e9; }
        double[] dw = mulV(minv, new double[]{0, 0, -1});
        int nb = boxes.length;
        double[][][] rts = new double[nb][][], rps = new double[nb][][];
        double[][] ldArr = new double[nb][], pivot = new double[nb][];
        for (int bi = 0; bi < nb; bi++) {
            Box b = boxes[bi];
            rps[bi] = mul(rotZ(rz[b.part]), rotX(rx[b.part]));
            rts[bi] = transpose(rps[bi]);
            ldArr[bi] = mulV(rts[bi], dw);
            boolean bobbed = b.part == HEAD || b.part == BODY || b.part == LWING || b.part == RWING || (mode != 0 && (b.part == RARM || b.part == LARM || b.part == CAPE));
            pivot[bi] = new double[]{b.px, b.py + (bobbed ? bob : 0), b.pz};
        }
        int np = pets.length;
        double[][][] prts = new double[np][][], prps = new double[np][][];
        double[][] pld = new double[np][], ppivot = new double[np][];
        for (int pi = 0; pi < np; pi++) {
            PetModels.PBox b = pets[pi];
            prps[pi] = mul(rotZ(rz[b.part]), rotX(rx[b.part]));
            prts[pi] = transpose(prps[pi]);
            pld[pi] = mulV(prts[pi], dw);
            ppivot[pi] = new double[]{b.px, b.py + pdy[b.part] * b.cell + bob, b.pz};
        }
        int na = abx.length;
        double[][][] arts = new double[na][][], arps = new double[na][][];
        double[][] ald = new double[na][], apivot = new double[na][];
        for (int ai = 0; ai < na; ai++) {
            Accessories.ABox b = abx[ai];
            arps[ai] = mul(rotZ(rz[b.part]), rotX(rx[b.part]));
            arts[ai] = transpose(arps[ai]);
            ald[ai] = mulV(arts[ai], dw);
            boolean bobbed = b.part == HEAD || b.part == BODY || (mode != 0 && (b.part == RARM || b.part == LARM));
            apivot[ai] = new double[]{b.px, b.py + (bobbed ? bob : 0), b.pz};
        }
        int[] axisOut = new int[2];
        double[] po = new double[3], lo = new double[3];
        for (int py2 = 0; py2 < H; py2++) for (int px2 = 0; px2 < W; px2++) {
            double vx = (px2 + .5 - W / 2.0) / s, vy = cy + (H / 2.0 - py2 - .5) / s;
            if (Math.abs(vx) > xLim || Math.abs(vy - cy) > yLim) continue; // outside the silhouette
            double[] o = addC(mulV(minv, new double[]{vx, vy - cy, 60}), cy);
            float bestT = Float.POSITIVE_INFINITY; int bestCol = 0;
            for (int bi = 0; bi < nb; bi++) {
                Box b = boxes[bi];
                if ((b.cape || b.wing) && cape == null) continue;
                double[][] rt = rts[bi];
                po[0] = o[0] - pivot[bi][0]; po[1] = o[1] - pivot[bi][1]; po[2] = o[2] - pivot[bi][2];
                lo[0] = rt[0][0]*po[0] + rt[0][1]*po[1] + rt[0][2]*po[2] + b.px;
                lo[1] = rt[1][0]*po[0] + rt[1][1]*po[1] + rt[1][2]*po[2] + b.py;
                lo[2] = rt[2][0]*po[0] + rt[2][1]*po[1] + rt[2][2]*po[2] + b.pz;
                double[] ld = ldArr[bi];
                float tt = intersect(b, lo, ld, axisOut);
                if (tt >= bestT || tt < 0) continue;
                double hx = lo[0] + ld[0] * tt, hy = lo[1] + ld[1] * tt, hz = lo[2] + ld[2] * tt;
                int argb = texel(b, axisOut[0], axisOut[1], hx, hy, hz, skin, cape, t);
                if ((argb >>> 24) < 128) continue;
                double[] n = new double[3]; n[axisOut[0]] = axisOut[1];
                double[] nv = mulV(mfwd, mulV(rps[bi], n));
                double light = 0.62 + 0.38 * Math.max(0, nv[1] * 0.45 + nv[2] * 0.75 - nv[0] * 0.15);
                bestT = (float) tt;
                bestCol = shade(argb, light);
            }
            for (int pi = 0; pi < np; pi++) {
                PetModels.PBox b = pets[pi];
                double[][] rt = prts[pi];
                po[0] = o[0] - ppivot[pi][0]; po[1] = o[1] - ppivot[pi][1]; po[2] = o[2] - ppivot[pi][2];
                lo[0] = rt[0][0]*po[0] + rt[0][1]*po[1] + rt[0][2]*po[2] + b.px;
                lo[1] = rt[1][0]*po[0] + rt[1][1]*po[1] + rt[1][2]*po[2] + b.py;
                lo[2] = rt[2][0]*po[0] + rt[2][1]*po[1] + rt[2][2]*po[2] + b.pz;
                double[] ld = pld[pi];
                float tt = slab(b.x0, b.y0, b.z0, b.x1, b.y1, b.z1, lo, ld, axisOut);
                if (tt >= bestT || tt < 0) continue;
                double hx = lo[0] + ld[0] * tt, hy = lo[1] + ld[1] * tt, hz = lo[2] + ld[2] * tt;
                int argb = b.color(axisOut[0], axisOut[1], hx, hy, hz, t);
                double[] n = new double[3]; n[axisOut[0]] = axisOut[1];
                double[] nv = mulV(mfwd, mulV(prps[pi], n));
                double light = 0.62 + 0.38 * Math.max(0, nv[1] * 0.45 + nv[2] * 0.75 - nv[0] * 0.15);
                bestT = (float) tt;
                bestCol = shade(argb, light);
            }
            for (int ai = 0; ai < na; ai++) {
                Accessories.ABox b = abx[ai];
                double[][] rt = arts[ai];
                po[0] = o[0] - apivot[ai][0]; po[1] = o[1] - apivot[ai][1]; po[2] = o[2] - apivot[ai][2];
                double l0 = rt[0][0]*po[0] + rt[0][1]*po[1] + rt[0][2]*po[2] + b.px;
                double l1 = rt[1][0]*po[0] + rt[1][1]*po[1] + rt[1][2]*po[2] + b.py;
                double l2 = rt[2][0]*po[0] + rt[2][1]*po[1] + rt[2][2]*po[2] + b.pz;
                double[] ld = ald[ai];
                if (b.tiltT != null) { // static tilt of the piece about its own pivot
                    double[][] tt2 = b.tiltT;
                    double d0 = l0 - b.tcx, d1 = l1 - b.tcy, d2 = l2 - b.tcz;
                    l0 = tt2[0][0]*d0 + tt2[0][1]*d1 + tt2[0][2]*d2 + b.tcx;
                    l1 = tt2[1][0]*d0 + tt2[1][1]*d1 + tt2[1][2]*d2 + b.tcy;
                    l2 = tt2[2][0]*d0 + tt2[2][1]*d1 + tt2[2][2]*d2 + b.tcz;
                    ld = new double[]{tt2[0][0]*ld[0] + tt2[0][1]*ld[1] + tt2[0][2]*ld[2], tt2[1][0]*ld[0] + tt2[1][1]*ld[1] + tt2[1][2]*ld[2], tt2[2][0]*ld[0] + tt2[2][1]*ld[1] + tt2[2][2]*ld[2]};
                }
                lo[0] = l0; lo[1] = l1; lo[2] = l2;
                float tt = slab(b.x0, b.y0, b.z0, b.x1, b.y1, b.z1, lo, ld, axisOut);
                if (tt >= bestT || tt < 0) continue;
                double hx = lo[0] + ld[0] * tt, hy = lo[1] + ld[1] * tt, hz = lo[2] + ld[2] * tt;
                int argb = b.color(axisOut[0], axisOut[1], hx, hy, hz);
                double[] n = new double[3]; n[axisOut[0]] = axisOut[1];
                if (b.tiltF != null) n = mulV(b.tiltF, n);
                double[] nv = mulV(mfwd, mulV(arps[ai], n));
                double light = 0.62 + 0.38 * Math.max(0, nv[1] * 0.45 + nv[2] * 0.75 - nv[0] * 0.15);
                if (b.lit) light = 0.9 + 0.1 * (light - 0.62) / 0.38;
                bestT = (float) tt;
                bestCol = shade(argb, light);
            }
            if (bestCol != 0) out[py2 * W + px2] = bestCol;
        }
        return out;
    }

    private static double[] addC(double[] v, double cy) { return new double[]{v[0], v[1] + cy, v[2]}; }

    /** Slab test. axisOut = {axis(0..2), sign of the face normal}. Returns -1 on a miss. */
    private static float intersect(Box b, double[] o, double[] d, int[] axisOut) {
        return slab(b.x0, b.y0, b.z0, b.x1, b.y1, b.z1, o, d, axisOut);
    }

    private static float slab(float x0, float y0, float z0, float x1, float y1, float z1, double[] o, double[] d, int[] axisOut) {
        double[] mn = {x0, y0, z0}, mx = {x1, y1, z1};
        double tmin = Double.NEGATIVE_INFINITY, tmax = Double.POSITIVE_INFINITY; int ax = 0, sg = 1;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-9) { if (o[i] < mn[i] || o[i] > mx[i]) return -1; continue; }
            double t1 = (mn[i] - o[i]) / d[i], t2 = (mx[i] - o[i]) / d[i];
            int sign = -1;
            if (t1 > t2) { double tmp = t1; t1 = t2; t2 = tmp; sign = 1; }
            if (t1 > tmin) { tmin = t1; ax = i; sg = sign; }
            tmax = Math.min(tmax, t2);
        }
        if (tmin > tmax || tmax < 0) return -1;
        axisOut[0] = ax; axisOut[1] = sg;
        return (float) tmin;
    }

    private static int texel(Box b, int axis, int sign, double hx, double hy, double hz, SkinImage skin, CapeImage cape, float t) {
        float fx = (float) ((hx - b.x0) / (b.x1 - b.x0)), fy = (float) ((hy - b.y0) / (b.y1 - b.y0)), fz = (float) ((hz - b.z0) / (b.z1 - b.z0));
        if (b.mirror) { fx = 1 - fx; if (axis == 0) sign = -sign; } // mirrored box (right elytra wing): texture flipped, side faces swapped
        fx = clamp(fx); fy = clamp(fy); fz = clamp(fz);
        float u, v;
        int tu = b.tu, tv = b.tv, w = b.w, h = b.h, d = b.d;
        if (axis == 2 && sign > 0) { // front (+z)
            u = tu + d + (b.cape ? w + d : 0) + fx * w; v = tv + d + (1 - fy) * h;
        } else if (axis == 2) { // back (-z)
            u = tu + (b.cape ? d + (1 - fx) * w : 2 * d + w + (1 - fx) * w); v = tv + d + (1 - fy) * h;
        } else if (axis == 0 && sign < 0) { // character's right side
            u = tu + fz * d; v = tv + d + (1 - fy) * h;
        } else if (axis == 0) { // left side
            u = tu + d + w + (1 - fz) * d; v = tv + d + (1 - fy) * h;
        } else if (sign > 0) { // top
            u = tu + d + fx * w; v = tv + fz * d;
        } else { // bottom
            u = tu + d + w + fx * w; v = tv + (1 - fz) * d;
        }
        return (b.cape || b.wing) ? cape.argb(u, v, t) : skin.argb(u, v);
    }

    private static float clamp(float f) { return Math.max(0f, Math.min(0.9999f, f)); }
    private static int shade(int argb, double l) {
        int r = (int) Math.min(255, ((argb >> 16) & 255) * l), g = (int) Math.min(255, ((argb >> 8) & 255) * l), bl = (int) Math.min(255, (argb & 255) * l);
        return 0xFF000000 | r << 16 | g << 8 | bl;
    }

    private static double[][] rotX(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{1,0,0},{0,c,-s},{0,s,c}}; }
    private static double[][] rotY(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{c,0,s},{0,1,0},{-s,0,c}}; }
    private static double[][] rotZ(double a) { double c = Math.cos(a), s = Math.sin(a); return new double[][]{{c,-s,0},{s,c,0},{0,0,1}}; }
    private static double[][] transpose(double[][] m) { double[][] r = new double[3][3]; for (int i=0;i<3;i++) for (int j=0;j<3;j++) r[i][j]=m[j][i]; return r; }
    private static double[][] mul(double[][] a, double[][] b) { double[][] r = new double[3][3]; for (int i=0;i<3;i++) for (int j=0;j<3;j++) for (int k=0;k<3;k++) r[i][j]+=a[i][k]*b[k][j]; return r; }
    private static double[] mulV(double[][] m, double[] v) { return new double[]{ m[0][0]*v[0]+m[0][1]*v[1]+m[0][2]*v[2], m[1][0]*v[0]+m[1][1]*v[1]+m[1][2]*v[2], m[2][0]*v[0]+m[2][1]*v[1]+m[2][2]*v[2]}; }
}
