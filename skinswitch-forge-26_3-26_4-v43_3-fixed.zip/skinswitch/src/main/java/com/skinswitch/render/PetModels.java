package com.skinswitch.render;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mini Minecraft-style creatures that sit on top of the character's head (each scaled so it is about one block big).
 * Pure Java (no Minecraft classes): every creature is a handful of coloured boxes with a few "decals" (eyes, nose, ...)
 * painted on the front face, and a small animation function. Used by {@link PreviewRenderer}.
 * Model units are Minecraft model pixels: y up from the ground, z+ = front, origin = centre of the feet.
 */
public final class PetModels {
    private PetModels() {}

    /** Animation part ids used by pets are PART0 .. PART0+SLOTS-1 (body parts of the player use 0..6). */
    public static final int PART0 = 7, SLOTS = 9, STATIC = PART0 + SLOTS - 1;
    public static final int ARRAY_SIZE = PART0 + SLOTS;
    /** A pet is scaled so its biggest dimension is this many model pixels (16 = one block). */
    public static final float TARGET = 16f;

    public static final String[] IDS = {
        "cat_orange", "cat_black", "cat_white", "zombie", "skeleton", "creeper", "pig", "chicken",
        "cow", "sheep", "wolf", "spider", "enderman", "slime", "villager",
        "rabbit", "panda", "fox", "bee", "blaze", "iron_golem", "axolotl", "snow_golem",
        "horse", "donkey", "llama", "camel", "goat", "ocelot", "parrot", "bat", "squid", "glow_squid", "dolphin", "turtle", "polar_bear", "mooshroom", "frog", "cod", "salmon", "pufferfish", "tropical_fish", "strider", "sniffer", "armadillo"
    };

    public record Decal(float u0, float v0, float u1, float v1, int rgb, boolean eye) {}

    /** One scaled box of a pet (final coordinates, already placed on the head). */
    public static final class PBox {
        public final float x0, y0, z0, x1, y1, z1, px, py, pz, noise, cell, lw, lh;
        public final int part, rgb;
        private final Decal[] decals;

        PBox(Raw r, float s, float baseY) {
            x0 = r.x0 * s; y0 = r.y0 * s + baseY; z0 = r.z0 * s;
            x1 = r.x1 * s; y1 = r.y1 * s + baseY; z1 = r.z1 * s;
            px = r.px * s; py = r.py * s + baseY; pz = r.pz * s;
            part = r.part; rgb = r.rgb; noise = r.noise; cell = s;
            lw = r.x1 - r.x0; lh = r.y1 - r.y0;
            decals = r.decals.isEmpty() ? null : r.decals.toArray(new Decal[0]);
        }

        /** Colour of the face hit at (hx,hy,hz) in the box's own (un-rotated) frame; axis 0..2, sign = face normal sign. */
        public int color(int axis, int sign, double hx, double hy, double hz, float t) {
            int c = rgb;
            boolean hit = false;
            if (decals != null && axis == 2 && sign > 0) {
                float u = (float) ((hx - x0) / (x1 - x0)) * lw, v = (1f - (float) ((hy - y0) / (y1 - y0))) * lh;
                boolean blink = (t % 3.6f) < 0.16f;
                for (Decal d : decals)
                    if (u >= d.u0 && u < d.u1 && v >= d.v0 && v < d.v1 && !(d.eye && blink)) { c = d.rgb; hit = true; }
            }
            if (!hit && noise > 0f) {
                int n = hash((int) Math.floor(hx / cell), (int) Math.floor(hy / cell), (int) Math.floor(hz / cell), axis * 2 + (sign > 0 ? 1 : 0)) & 255;
                double k = 1 + (n / 255.0 - 0.5) * noise;
                int r = (int) Math.min(255, ((c >> 16) & 255) * k), g = (int) Math.min(255, ((c >> 8) & 255) * k), b = (int) Math.min(255, (c & 255) * k);
                c = r << 16 | g << 8 | b;
            }
            return 0xFF000000 | c;
        }

        private static int hash(int a, int b, int c, int d) {
            int h = a * 374761393 ^ b * 668265263 ^ c * 1274126177 ^ d * 40503;
            h = (h ^ (h >>> 13)) * 1274126177;
            return h ^ (h >>> 16);
        }
    }

    // ---- model building -------------------------------------------------------------------------------------------
    private static final class Raw {
        float x0, y0, z0, x1, y1, z1, px, py, pz, noise = 0.07f;
        int part, rgb;
        final List<Decal> decals = new ArrayList<>();
    }

    private static final class B {
        final List<Raw> raws = new ArrayList<>();
        Raw last;
        /** Box centred on (cx, cz), standing on y0, size w x h x d. */
        B box(int slot, float cx, float y0, float cz, float w, float h, float d, int rgb) {
            Raw r = new Raw();
            r.x0 = cx - w / 2; r.x1 = cx + w / 2; r.y0 = y0; r.y1 = y0 + h; r.z0 = cz - d / 2; r.z1 = cz + d / 2;
            r.px = cx; r.py = y0 + h / 2; r.pz = cz; r.part = PART0 + slot; r.rgb = rgb;
            raws.add(r); last = r; return this;
        }
        B pv(float py) { last.py = py; return this; }
        B pv3(float px, float py, float pz) { last.px = px; last.py = py; last.pz = pz; return this; }
        B nz(float n) { last.noise = n; return this; }
        B dec(float u0, float v0, float u1, float v1, int rgb) { last.decals.add(new Decal(u0, v0, u1, v1, rgb, false)); return this; }
        B eye(float u0, float v0, float u1, float v1, int rgb) { last.decals.add(new Decal(u0, v0, u1, v1, rgb, true)); return this; }
    }

    private record Model(List<Raw> raws, float scale, float height, float half) {}

    private static final Map<String, Model> MODELS = new HashMap<>();

    private static Model model(String id) {
        return MODELS.computeIfAbsent(id, PetModels::make);
    }

    public static boolean exists(String id) { return id != null && java.util.Arrays.asList(IDS).contains(id); }
    public static float height(String id) { Model m = model(id); return m.height * m.scale; }
    public static float halfWidth(String id) { Model m = model(id); return m.half * m.scale; }

    /** The boxes of a pet, scaled to about one block, standing on y = baseY (x/z centred on 0). */
    public static PBox[] build(String id, float baseY) {
        Model m = model(id);
        PBox[] out = new PBox[m.raws.size()];
        for (int i = 0; i < out.length; i++) out[i] = new PBox(m.raws.get(i), m.scale, baseY);
        return out;
    }

    private static int c(int r, int g, int b) { return r << 16 | g << 8 | b; }

    private static Model make(String id) {
        B b = new B();
        final int S = SLOTS - 1; // static (never animated) slot
        switch (id) {
            case "cat_orange", "cat_black", "cat_white" -> {
                int base, dark, belly = c(248, 236, 216), pink = c(232, 150, 160), eyeC, nose = pink;
                boolean tabby = id.equals("cat_orange");
                if (tabby) { base = c(232, 142, 62); dark = c(190, 100, 36); eyeC = c(120, 205, 80); }
                else if (id.equals("cat_black")) { base = c(40, 40, 46); dark = c(22, 22, 26); eyeC = c(225, 225, 70); }
                else { base = c(240, 240, 240); dark = c(214, 214, 222); eyeC = c(95, 165, 235); }
                // slots: 0 tail, 1 ear L, 2 ear R, 3 head, 4 body
                b.box(4, 0, 2, -1, 5, 7, 4, base).dec(1, 2, 4, 6.5f, tabby ? belly : base == c(240, 240, 240) ? base : dark);
                b.box(S, -3.1f, 0, -2, 2, 4, 5, dark);
                b.box(S, 3.1f, 0, -2, 2, 4, 5, dark);
                b.box(S, -1.4f, 0, 1.8f, 1.8f, 6, 1.8f, base).dec(0, 4.6f, 1.8f, 6, belly);
                b.box(S, 1.4f, 0, 1.8f, 1.8f, 6, 1.8f, base).dec(0, 4.6f, 1.8f, 6, belly);
                b.box(3, 0, 8.5f, 1, 6, 5, 5, base);
                if (tabby) { b.dec(2.6f, 0, 3.4f, 1.1f, dark).dec(1.2f, 0, 1.8f, 0.8f, dark).dec(4.2f, 0, 4.8f, 0.8f, dark); }
                b.dec(2, 3.1f, 4, 4.4f, belly).eye(0.9f, 1.5f, 2.5f, 3.0f, eyeC).eye(3.5f, 1.5f, 5.1f, 3.0f, eyeC)
                 .eye(1.5f, 1.6f, 1.9f, 2.9f, c(15, 15, 15)).eye(4.1f, 1.6f, 4.5f, 2.9f, c(15, 15, 15)).dec(2.6f, 3.1f, 3.4f, 3.7f, nose);
                b.box(1, -2, 13.3f, 0.2f, 1.8f, 1.8f, 1, base).pv(13.3f).dec(0.4f, 0.3f, 1.4f, 1.5f, pink);
                b.box(2, 2, 13.3f, 0.2f, 1.8f, 1.8f, 1, base).pv(13.3f).dec(0.4f, 0.3f, 1.4f, 1.5f, pink);
                b.box(0, 0, 1, -3.9f, 1.5f, 7, 1.5f, base).pv(1);
                b.box(0, 0, 6.5f, -3.9f, 1.5f, 2, 1.5f, dark).pv3(0, 1, -3.9f);
            }
            case "zombie" -> {
                int skin = c(95, 150, 75), shirt = c(50, 150, 160), pants = c(62, 52, 140);
                // slots: 0 arm L, 1 arm R, 2 leg L, 3 leg R
                b.box(2, 2, 0, 0, 4, 12, 4, pants).pv(12);
                b.box(3, -2, 0, 0, 4, 12, 4, pants).pv(12);
                b.box(S, 0, 12, 0, 8, 12, 4, shirt);
                b.box(S, 0, 24, 0, 8, 8, 8, skin).eye(1, 3, 3, 4.2f, c(25, 30, 70)).eye(5, 3, 7, 4.2f, c(25, 30, 70))
                 .dec(3.4f, 4.4f, 4.6f, 5.4f, c(70, 115, 55)).dec(2, 5.8f, 6, 6.8f, c(55, 90, 45));
                b.box(0, 6, 12, 0, 4, 12, 4, skin).pv(24);
                b.box(1, -6, 12, 0, 4, 12, 4, skin).pv(24);
            }
            case "skeleton" -> {
                int bone = c(214, 214, 204), shade = c(70, 70, 66);
                // slots: 0 arm L, 1 arm R, 2 leg L, 3 leg R
                b.box(2, 2, 0, 0, 2, 12, 2, bone).pv(12);
                b.box(3, -2, 0, 0, 2, 12, 2, bone).pv(12);
                b.box(S, 0, 12, 0, 8, 12, 4, c(190, 190, 180)).dec(0.5f, 1, 7.5f, 1.8f, shade).dec(0.5f, 3, 7.5f, 3.8f, shade)
                 .dec(0.5f, 5, 7.5f, 5.8f, shade).dec(0.5f, 7, 7.5f, 7.8f, shade).dec(3.4f, 0, 4.6f, 12, c(150, 150, 140));
                b.box(S, 0, 24, 0, 8, 8, 8, bone).eye(1, 3, 3, 5, c(30, 30, 30)).eye(5, 3, 7, 5, c(30, 30, 30))
                 .dec(3.5f, 5.2f, 4.5f, 6, c(120, 120, 112)).dec(2, 6.6f, 6, 7.2f, c(60, 60, 56));
                b.box(0, 5, 12, 0, 2, 12, 2, bone).pv(24);
                b.box(1, -5, 12, 0, 2, 12, 2, bone).pv(24);
            }
            case "creeper" -> {
                int g = c(84, 180, 72), dk = c(14, 40, 14);
                // slots: 0 leg FL, 1 leg FR, 2 leg BL, 3 leg BR
                b.box(S, 0, 6, 0, 8, 12, 4, g).nz(0.22f);
                b.box(S, 0, 18, 0, 8, 8, 8, g).nz(0.22f).dec(1, 2, 3, 4, dk).dec(5, 2, 7, 4, dk).dec(3, 4, 5, 5, dk).dec(2, 5, 6, 7, dk).dec(3, 6, 5, 8, g).dec(2, 7, 3, 8, dk).dec(5, 7, 6, 8, dk);
                b.box(0, 2, 0, 4, 4, 6, 4, g).nz(0.22f).pv(6);
                b.box(1, -2, 0, 4, 4, 6, 4, g).nz(0.22f).pv(6);
                b.box(2, 2, 0, -4, 4, 6, 4, g).nz(0.22f).pv(6);
                b.box(3, -2, 0, -4, 4, 6, 4, g).nz(0.22f).pv(6);
            }
            case "pig" -> {
                int p = c(240, 160, 172), sn = c(250, 192, 198), dk = c(50, 30, 35);
                // slots: 0..3 legs FL FR BL BR, 4 head
                b.box(S, 0, 6, 0, 10, 8, 16, p);
                b.box(4, 0, 8, 11, 8, 8, 8, p).pv3(0, 10, 7).eye(1, 2.5f, 2.2f, 3.8f, dk).eye(5.8f, 2.5f, 7, 3.8f, dk);
                b.box(4, 0, 9, 15.6f, 4, 3, 1.4f, sn).pv3(0, 10, 7).dec(0.8f, 0.9f, 1.5f, 2.1f, dk).dec(2.5f, 0.9f, 3.2f, 2.1f, dk);
                b.box(4, -3.2f, 16, 9, 2, 2, 1, p).pv3(0, 10, 7);
                b.box(4, 3.2f, 16, 9, 2, 2, 1, p).pv3(0, 10, 7);
                b.box(0, 3, 0, 5, 4, 6, 4, p).pv(6);
                b.box(1, -3, 0, 5, 4, 6, 4, p).pv(6);
                b.box(2, 3, 0, -5, 4, 6, 4, p).pv(6);
                b.box(3, -3, 0, -5, 4, 6, 4, p).pv(6);
            }
            case "chicken" -> {
                int w = c(246, 246, 246), or = c(240, 160, 40), rd = c(215, 40, 40), dk = c(30, 30, 30);
                // slots: 0 wing L, 1 wing R, 2 head
                b.box(S, 0, 5, 0, 6, 6, 8, w);
                b.box(S, 0, 7.5f, -5, 3, 4, 2, w);
                b.box(S, -1.5f, 0, 0, 1, 5, 1, or);
                b.box(S, 1.5f, 0, 0, 1, 5, 1, or);
                b.box(2, 0, 9, 4.5f, 4, 6, 3, w).pv3(0, 9, 4).eye(0.6f, 1.6f, 1.4f, 2.6f, dk).eye(2.6f, 1.6f, 3.4f, 2.6f, dk);
                b.box(2, 0, 11.3f, 6.8f, 4, 2, 2, or).pv3(0, 9, 4);
                b.box(2, 0, 9.8f, 6.3f, 2, 2, 1, rd).pv3(0, 9, 4);
                b.box(2, 0, 14.6f, 4.5f, 1, 2, 3, rd).pv3(0, 9, 4);
                b.box(0, 3.6f, 6, 0, 1, 4, 6, w).pv(10);
                b.box(1, -3.6f, 6, 0, 1, 4, 6, w).pv(10);
            }
            case "cow" -> {
                int br = c(92, 60, 38), wh = c(240, 240, 240), dk = c(30, 25, 25), mz = c(215, 185, 165), hn = c(230, 225, 205);
                // slots: 0 head, 1..4 legs FL FR BL BR
                b.box(S, 0, 12, 0, 12, 10, 18, br);
                b.box(S, 6.1f, 14, 3, 0.3f, 5, 6, wh).nz(0.03f);
                b.box(S, -6.1f, 17, -4, 0.3f, 4, 5, wh).nz(0.03f);
                b.box(S, 1, 22.1f, -3, 5, 0.3f, 6, wh).nz(0.03f);
                b.box(0, 0, 15, 12, 8, 8, 6, br).pv3(0, 20, 9).eye(1, 2.5f, 2.2f, 3.8f, dk).eye(5.8f, 2.5f, 7, 3.8f, dk);
                b.box(0, 0, 15, 15.4f, 6, 4, 1.6f, mz).pv3(0, 20, 9).dec(0.8f, 1, 1.6f, 2.2f, dk).dec(4.4f, 1, 5.2f, 2.2f, dk);
                b.box(0, -4, 23, 12, 1, 3, 1, hn).pv3(0, 20, 9);
                b.box(0, 4, 23, 12, 1, 3, 1, hn).pv3(0, 20, 9);
                b.box(1, 4, 0, 6, 4, 12, 4, br).pv(12);
                b.box(2, -4, 0, 6, 4, 12, 4, br).pv(12);
                b.box(3, 4, 0, -6, 4, 12, 4, br).pv(12);
                b.box(4, -4, 0, -6, 4, 12, 4, br).pv(12);
            }
            case "sheep" -> {
                int wool = c(236, 232, 222), sk = c(214, 188, 168), dk = c(40, 35, 35);
                // slots: 0 head, 1..4 legs
                b.box(S, 0, 12, 0, 12, 10, 16, wool).nz(0.16f);
                b.box(0, 0, 15, 10.5f, 6, 6, 8, sk).pv3(0, 20, 7).eye(1, 2.2f, 2, 3.4f, dk).eye(4, 2.2f, 5, 3.4f, dk);
                b.box(0, 0, 20.4f, 10, 8, 3, 7, wool).nz(0.16f).pv3(0, 20, 7);
                b.box(1, 3, 0, 5, 4, 12, 4, sk).pv(12);
                b.box(2, -3, 0, 5, 4, 12, 4, sk).pv(12);
                b.box(3, 3, 0, -5, 4, 12, 4, sk).pv(12);
                b.box(4, -3, 0, -5, 4, 12, 4, sk).pv(12);
            }
            case "wolf" -> {
                int gr = c(200, 200, 200), dk = c(40, 40, 40), lt = c(228, 228, 228);
                // slots: 0 tail, 1 head, 2..5 legs FL FR BL BR
                b.box(S, 0, 8, 0, 6, 6, 10, gr);
                b.box(S, 0, 8.4f, 3.2f, 5, 4, 3.5f, lt);
                b.box(1, 0, 9, 6.5f, 6, 6, 5, gr).pv3(0, 10, 4).eye(1, 2, 2.2f, 3.2f, dk).eye(3.8f, 2, 5, 3.2f, dk);
                b.box(1, 0, 9.6f, 10.6f, 3, 3, 3, lt).pv3(0, 10, 4).dec(0.8f, 0, 2.2f, 0.9f, dk);
                b.box(1, -2, 14.8f, 6.5f, 2, 2, 1, gr).pv3(0, 10, 4);
                b.box(1, 2, 14.8f, 6.5f, 2, 2, 1, gr).pv3(0, 10, 4);
                b.box(0, 0, 8.5f, -6, 2, 7, 2, gr).pv(8.5f);
                b.box(2, 2, 0, 3.5f, 2, 8, 2, gr).pv(8);
                b.box(3, -2, 0, 3.5f, 2, 8, 2, gr).pv(8);
                b.box(4, 2, 0, -3.5f, 2, 8, 2, gr).pv(8);
                b.box(5, -2, 0, -3.5f, 2, 8, 2, gr).pv(8);
            }
            case "spider" -> {
                int bd = c(58, 42, 38), hd = c(72, 54, 46), rd = c(205, 30, 30);
                // slots 0..3 legs left (front..back), 4..7 legs right
                b.box(S, 0, 4, -8, 10, 8, 12, bd);
                b.box(S, 0, 5, -1, 6, 6, 6, bd);
                b.box(S, 0, 4, 6, 8, 8, 8, hd).eye(1, 2.6f, 2.2f, 3.8f, rd).eye(5.8f, 2.6f, 7, 3.8f, rd).eye(2.6f, 1.2f, 3.6f, 2.2f, rd).eye(4.4f, 1.2f, 5.4f, 2.2f, rd);
                float[] zs = {3, 1, -1, -3};
                for (int i = 0; i < 4; i++) {
                    b.box(i, -8.5f, 4.4f, zs[i], 9, 1.2f, 1.2f, hd).pv3(-4, 5, zs[i]);
                    b.box(i, -12.6f, 0, zs[i], 1.2f, 5.4f, 1.2f, hd).pv3(-4, 5, zs[i]);
                    b.box(4 + i, 8.5f, 4.4f, zs[i], 9, 1.2f, 1.2f, hd).pv3(4, 5, zs[i]);
                    b.box(4 + i, 12.6f, 0, zs[i], 1.2f, 5.4f, 1.2f, hd).pv3(4, 5, zs[i]);
                }
            }
            case "enderman" -> {
                int bl = c(24, 24, 28), pu = c(232, 90, 255);
                // slots: 0 arm L, 1 arm R, 2 leg L, 3 leg R
                b.box(2, 1.8f, 0, 0, 2, 30, 2, bl).pv(30).nz(0.04f);
                b.box(3, -1.8f, 0, 0, 2, 30, 2, bl).pv(30).nz(0.04f);
                b.box(S, 0, 30, 0, 8, 12, 4, bl).nz(0.04f);
                b.box(S, 0, 42, 0, 8, 8, 8, bl).nz(0.04f).eye(1, 3, 3.2f, 4.2f, pu).eye(4.8f, 3, 7, 4.2f, pu);
                b.box(0, 5.2f, 12, 0, 2, 30, 2, bl).pv(42).nz(0.04f);
                b.box(1, -5.2f, 12, 0, 2, 30, 2, bl).pv(42).nz(0.04f);
            }
            case "slime" -> {
                int g = c(112, 200, 92), dk = c(34, 88, 34);
                // slots: 0 body (bounces)
                b.box(0, 0, 0, 0, 12, 10, 12, g).nz(0.1f).dec(0.8f, 0.8f, 3.2f, 1.8f, c(175, 238, 155)).dec(2.4f, 3.4f, 4.6f, 5.6f, dk).dec(7.4f, 3.4f, 9.6f, 5.6f, dk).dec(5, 7, 7, 8.2f, dk);
            }
            case "villager" -> {
                int robe = c(122, 90, 60), sk = c(200, 150, 120), dkn = c(184, 134, 104);
                // slots: 0 head
                b.box(S, 0, 0, 0, 8, 12, 6, robe).nz(0.1f);
                b.box(S, 0, 12, 0, 8, 12, 6, robe).nz(0.1f);
                b.box(S, 0, 14.5f, 3.4f, 9, 4, 3, c(100, 72, 48));
                b.box(0, 0, 24, 0, 8, 10, 8, sk).pv(24).dec(1, 3.4f, 7, 4.2f, c(70, 50, 40))
                 .eye(1.2f, 4.4f, 3.4f, 5.8f, c(245, 245, 245)).eye(4.6f, 4.4f, 6.8f, 5.8f, c(245, 245, 245))
                 .eye(2, 4.6f, 2.8f, 5.6f, c(70, 135, 75)).eye(5.2f, 4.6f, 6, 5.6f, c(70, 135, 75));
                b.box(0, 0, 25.5f, 5.2f, 2, 4, 2, dkn).pv(24);
            }
            case "rabbit" -> {
                int fur = c(168, 124, 84), lt = c(238, 228, 212), dk = c(30, 25, 25), pk = c(235, 150, 160);
                // slots: 0 ear L, 1 ear R, 2 head
                b.box(S, 0, 2, -1, 6, 6, 8, fur);
                b.box(S, -3, 0, -3, 2, 4, 5, fur);
                b.box(S, 3, 0, -3, 2, 4, 5, fur);
                b.box(S, -1.5f, 0, 3, 1.5f, 3, 1.5f, lt);
                b.box(S, 1.5f, 0, 3, 1.5f, 3, 1.5f, lt);
                b.box(S, 0, 3, -5.5f, 3, 3, 2, lt);
                b.box(2, 0, 6, 3, 5, 5, 5, fur).pv(7).eye(0.8f, 1.6f, 1.6f, 2.8f, dk).eye(3.4f, 1.6f, 4.2f, 2.8f, dk)
                 .dec(1.6f, 3, 3.4f, 4.4f, lt).dec(2.2f, 2.9f, 2.8f, 3.4f, pk);
                b.box(0, -1.2f, 11, 3, 1.4f, 5, 1, fur).pv(11).dec(0.3f, 0.3f, 1.1f, 4.2f, pk);
                b.box(1, 1.2f, 11, 3, 1.4f, 5, 1, fur).pv(11).dec(0.3f, 0.3f, 1.1f, 4.2f, pk);
            }
            case "panda" -> {
                int wh = c(240, 240, 240), bk = c(35, 35, 38);
                // slots: 0 head, 1..4 legs FL FR BL BR
                b.box(1, 3.5f, 0, 4.5f, 4, 6, 4, bk).pv(6);
                b.box(2, -3.5f, 0, 4.5f, 4, 6, 4, bk).pv(6);
                b.box(3, 3.5f, 0, -4.5f, 4, 6, 4, bk).pv(6);
                b.box(4, -3.5f, 0, -4.5f, 4, 6, 4, bk).pv(6);
                b.box(S, 0, 6, 0, 10, 8, 14, wh);
                b.box(S, 0, 5.95f, 3.5f, 10.3f, 8.1f, 4, bk);
                b.box(0, 0, 8, 8.5f, 8, 7, 6, wh).pv3(0, 10, 7).dec(1, 2, 3, 4, bk).dec(5, 2, 7, 4, bk)
                 .eye(1.6f, 2.6f, 2.4f, 3.4f, wh).eye(5.6f, 2.6f, 6.4f, 3.4f, wh).dec(3.2f, 4.6f, 4.8f, 5.6f, bk);
                b.box(0, -3.5f, 14.5f, 8.5f, 2, 2, 1.5f, bk).pv3(0, 10, 7);
                b.box(0, 3.5f, 14.5f, 8.5f, 2, 2, 1.5f, bk).pv3(0, 10, 7);
            }
            case "fox" -> {
                int og = c(224, 120, 40), wh = c(245, 240, 232), dk = c(40, 30, 30);
                // slots: 0 tail, 1 head, 2..5 legs FL FR BL BR
                b.box(S, 0, 6, 0, 6, 6, 10, og);
                b.box(1, 0, 8, 6.5f, 6, 5, 5, og).pv3(0, 10, 4).eye(1, 1.8f, 2, 2.8f, dk).eye(4, 1.8f, 5, 2.8f, dk).dec(0, 3.2f, 6, 5, wh);
                b.box(1, 0, 8.4f, 9.7f, 3, 2.4f, 3, wh).pv3(0, 10, 4).dec(0.9f, 0, 2.1f, 0.8f, dk);
                b.box(1, -2, 13, 6.5f, 1.8f, 2.4f, 1, og).pv3(0, 10, 4).dec(0, 0, 1.8f, 0.8f, dk);
                b.box(1, 2, 13, 6.5f, 1.8f, 2.4f, 1, og).pv3(0, 10, 4).dec(0, 0, 1.8f, 0.8f, dk);
                b.box(2, 2, 0, 3.5f, 2, 6, 2, dk).pv(6);
                b.box(3, -2, 0, 3.5f, 2, 6, 2, dk).pv(6);
                b.box(4, 2, 0, -3.5f, 2, 6, 2, dk).pv(6);
                b.box(5, -2, 0, -3.5f, 2, 6, 2, dk).pv(6);
                b.box(0, 0, 6, -8, 3, 3, 7, og).pv3(0, 7, -5);
                b.box(0, 0, 6, -12.4f, 3, 3, 2, wh).pv3(0, 7, -5);
            }
            case "bee" -> {
                int ye = c(250, 200, 40), bk = c(40, 35, 30), wg = c(222, 236, 246);
                // slots: 0 wing L, 1 wing R, 2 body (all three bob together)
                b.box(2, 0, 2, 0, 7, 7, 10, ye).eye(1, 2, 2.4f, 3.4f, bk).eye(4.6f, 2, 6, 3.4f, bk);
                b.box(2, 0, 2, -1, 7.2f, 7.2f, 2, bk);
                b.box(2, 0, 2, -4, 7.2f, 7.2f, 1.6f, bk);
                b.box(2, 0, 3.5f, -5.8f, 1, 1, 1.6f, bk);
                b.box(2, -1.5f, 7.5f, 4, 0.8f, 2.2f, 0.8f, bk);
                b.box(2, 1.5f, 7.5f, 4, 0.8f, 2.2f, 0.8f, bk);
                b.box(0, -2.5f, 9, -0.5f, 3, 0.6f, 6, wg).nz(0.02f).pv3(-1, 9, -0.5f);
                b.box(1, 2.5f, 9, -0.5f, 3, 0.6f, 6, wg).nz(0.02f).pv3(1, 9, -0.5f);
            }
            case "blaze" -> {
                int ye = c(250, 190, 40), or = c(235, 120, 20), dk = c(40, 30, 20);
                // slots: 0 head, 1 upper rods, 2 lower rods
                b.box(S, 0, 4, 0, 4, 8, 4, or);
                for (int i = 0; i < 4; i++) {
                    float rx0 = i == 0 ? 5 : i == 1 ? -5 : 0, rz0 = i == 2 ? 5 : i == 3 ? -5 : 0;
                    b.box(1, rx0, 4, rz0, 2, 8, 2, ye);
                    b.box(2, (i & 1) == 0 ? 3.5f : -3.5f, 0, i < 2 ? 3.5f : -3.5f, 2, 8, 2, or);
                }
                b.box(0, 0, 12, 0, 8, 8, 8, ye).nz(0.1f).eye(1.2f, 3, 3, 4.4f, dk).eye(5, 3, 6.8f, 4.4f, dk).dec(2.5f, 5.6f, 5.5f, 6.6f, or);
            }
            case "iron_golem" -> {
                int gr = c(204, 204, 198), dg = c(150, 150, 144), vn = c(80, 130, 60), nose = c(172, 122, 100), red = c(200, 40, 30);
                // slots: 0 arm L, 1 arm R, 2 leg L, 3 leg R
                b.box(2, 2.5f, 0, 0, 4, 9, 5, dg).pv(9);
                b.box(3, -2.5f, 0, 0, 4, 9, 5, dg).pv(9);
                b.box(S, 0, 8, 0, 9, 5, 6, dg);
                b.box(S, 0, 13, 0, 18, 12, 10, gr).nz(0.1f).dec(10, 5, 14, 12, vn).dec(3, 7, 6, 11, vn);
                b.box(S, 0, 25, 1, 8, 10, 8, gr).eye(1.5f, 4, 3.2f, 5.2f, red).eye(4.8f, 4, 6.5f, 5.2f, red).dec(0.8f, 3.2f, 7.2f, 3.9f, dg);
                b.box(S, 0, 27, 5.6f, 2, 4, 2, nose);
                b.box(0, 11, 3, 0, 4, 22, 5, gr).pv(24);
                b.box(1, -11, 3, 0, 4, 22, 5, gr).pv(24);
            }
            case "axolotl" -> {
                int pk = c(250, 172, 192), dp = c(220, 120, 150), dk = c(30, 25, 30);
                // slots: 0 tail, 1 head, 2 gills L, 3 gills R, 4..7 legs FL FR BL BR
                b.box(S, 0, 1, 0, 6, 4, 10, pk);
                b.box(1, 0, 1, 6.5f, 7, 5, 5, pk).pv3(0, 3, 4).eye(1, 2, 2, 3, dk).eye(5, 2, 6, 3, dk).dec(2.3f, 3.6f, 4.7f, 4, dp);
                for (int i = 0; i < 3; i++) {
                    float y = 2.2f + i * 1.3f;
                    b.box(2, -4.6f, y, 6.5f, 2.2f, 1, 0.8f, dp).pv3(-3.5f, y + 0.5f, 6.5f);
                    b.box(3, 4.6f, y, 6.5f, 2.2f, 1, 0.8f, dp).pv3(3.5f, y + 0.5f, 6.5f);
                }
                b.box(4, 3.5f, 0, 3, 1.6f, 1.5f, 2, pk).pv(1.5f);
                b.box(5, -3.5f, 0, 3, 1.6f, 1.5f, 2, pk).pv(1.5f);
                b.box(6, 3.5f, 0, -3, 1.6f, 1.5f, 2, pk).pv(1.5f);
                b.box(7, -3.5f, 0, -3, 1.6f, 1.5f, 2, pk).pv(1.5f);
                b.box(0, 0, 1, -8, 1.4f, 4, 6, pk).pv3(0, 3, -5);
            }
            case "snow_golem" -> {
                int wh = c(245, 250, 252), pm = c(222, 132, 30), dk = c(30, 25, 20), tw = c(110, 80, 50);
                // slots: 0 arm L, 1 arm R
                b.box(S, 0, 0, 0, 10, 8, 10, wh).nz(0.05f);
                b.box(S, 0, 8, 0, 8, 8, 8, wh).nz(0.05f);
                b.box(S, 0, 16, 0, 8, 8, 8, pm).eye(1.5f, 2.5f, 3, 4, dk).eye(5, 2.5f, 6.5f, 4, dk).dec(1.6f, 5.2f, 6.4f, 6.2f, dk);
                b.box(0, 6.5f, 11.5f, 0, 5, 1, 1, tw).pv3(4, 12, 0);
                b.box(1, -6.5f, 11.5f, 0, 5, 1, 1, tw).pv3(-4, 12, 0);
            }
            case "horse", "donkey" -> {
                boolean dn = id.equals("donkey");
                int fur = dn ? c(135, 120, 105) : c(150, 95, 55), mane = dn ? c(80, 68, 60) : c(55, 38, 28), wh = c(240, 235, 225), dk = c(25, 20, 20);
                float ear = dn ? 5f : 2f;
                // slots: 0 head+neck, 1..4 legs FL FR BL BR, 5 tail
                b.box(S, 0, 10, 0, 8, 9, 16, fur);
                b.box(1, 2.5f, 0, 6, 3, 10, 3, fur).pv(10);
                b.box(2, -2.5f, 0, 6, 3, 10, 3, fur).pv(10);
                b.box(3, 2.5f, 0, -6, 3, 10, 3, fur).pv(10);
                b.box(4, -2.5f, 0, -6, 3, 10, 3, fur).pv(10);
                b.box(0, 0, 17, 8.5f, 4, 8, 4, fur).pv3(0, 17, 8);
                b.box(0, 0, 20.5f, 12, 4, 5, 8, fur).pv3(0, 17, 8).eye(0.2f, 1, 1, 2, dk).eye(3, 1, 3.8f, 2, dk)
                 .dec(1.4f, 0, 2.6f, 5, dn ? fur : wh).dec(0.7f, 3.8f, 1.4f, 4.5f, dk).dec(2.6f, 3.8f, 3.3f, 4.5f, dk);
                b.box(0, -1.3f, 25.5f, 9.5f, 1, ear, 1, fur).pv3(0, 17, 8);
                b.box(0, 1.3f, 25.5f, 9.5f, 1, ear, 1, fur).pv3(0, 17, 8);
                b.box(0, 0, 17, 6.2f, 1.2f, 9, 1.2f, mane).pv3(0, 17, 8);
                b.box(5, 0, 12, -9, 2, 8, 2, mane).pv3(0, 18, -8);
            }
            case "llama" -> {
                int fur = c(222, 206, 176), dk = c(30, 25, 25), pk = c(210, 150, 150);
                // slots: 0 head+neck, 1..4 legs
                b.box(S, 0, 12, 0, 8, 10, 12, fur).nz(0.1f);
                b.box(1, 2.5f, 0, 4, 3, 12, 3, fur).pv(12);
                b.box(2, -2.5f, 0, 4, 3, 12, 3, fur).pv(12);
                b.box(3, 2.5f, 0, -4, 3, 12, 3, fur).pv(12);
                b.box(4, -2.5f, 0, -4, 3, 12, 3, fur).pv(12);
                b.box(0, 0, 20, 6, 4, 14, 4, fur).nz(0.1f).pv3(0, 22, 6);
                b.box(0, 0, 31, 8.5f, 5, 5, 6, fur).pv3(0, 22, 6).eye(0.8f, 1.5f, 1.6f, 2.5f, dk).eye(3.4f, 1.5f, 4.2f, 2.5f, dk).dec(1.8f, 3.2f, 3.2f, 4, pk);
                b.box(0, -1.5f, 36, 7, 1, 2.5f, 1, fur).pv3(0, 22, 6);
                b.box(0, 1.5f, 36, 7, 1, 2.5f, 1, fur).pv3(0, 22, 6);
                b.box(S, 0, 19, -6.8f, 2, 3, 1.4f, fur);
            }
            case "camel" -> {
                int fur = c(206, 166, 102), dk = c(30, 25, 22), pk = c(190, 140, 120);
                // slots: 0 head+neck, 1..4 legs
                b.box(S, 0, 14, 0, 8, 10, 16, fur).nz(0.1f);
                b.box(S, 0, 24, -1, 6, 5, 6, fur).nz(0.1f);
                b.box(1, 2.5f, 0, 5.5f, 3, 14, 3, fur).pv(14);
                b.box(2, -2.5f, 0, 5.5f, 3, 14, 3, fur).pv(14);
                b.box(3, 2.5f, 0, -5.5f, 3, 14, 3, fur).pv(14);
                b.box(4, -2.5f, 0, -5.5f, 3, 14, 3, fur).pv(14);
                b.box(0, 0, 22, 8, 4, 9, 4, fur).pv3(0, 23, 8);
                b.box(0, 0, 28, 11.5f, 5, 5, 8, fur).pv3(0, 23, 8).eye(0.6f, 1.3f, 1.4f, 2.3f, dk).eye(3.6f, 1.3f, 4.4f, 2.3f, dk).dec(1.6f, 3.6f, 3.4f, 4.4f, pk);
                b.box(0, -1.5f, 33, 9, 1, 1.6f, 1, fur).pv3(0, 23, 8);
                b.box(0, 1.5f, 33, 9, 1, 1.6f, 1, fur).pv3(0, 23, 8);
                b.box(S, 0, 17, -8.8f, 1.6f, 7, 1.6f, fur);
            }
            case "goat" -> {
                int fur = c(228, 224, 216), horn = c(196, 186, 162), dk = c(30, 25, 25), bd = c(205, 200, 190);
                // slots: 0 head, 1..4 legs
                b.box(S, 0, 6, 0, 6, 7, 10, fur);
                b.box(1, 2, 0, 3.5f, 2, 6, 2, fur).pv(6);
                b.box(2, -2, 0, 3.5f, 2, 6, 2, fur).pv(6);
                b.box(3, 2, 0, -3.5f, 2, 6, 2, fur).pv(6);
                b.box(4, -2, 0, -3.5f, 2, 6, 2, fur).pv(6);
                b.box(0, 0, 10, 6.5f, 5, 5, 5, fur).pv3(0, 12, 5).eye(0.8f, 1.8f, 1.6f, 2.8f, dk).eye(3.4f, 1.8f, 4.2f, 2.8f, dk).dec(1.6f, 3.4f, 3.4f, 4.4f, bd);
                b.box(0, -1.5f, 15, 6, 1, 3, 1, horn).pv3(0, 12, 5);
                b.box(0, 1.5f, 15, 6, 1, 3, 1, horn).pv3(0, 12, 5);
                b.box(0, 0, 8.2f, 9.2f, 1.5f, 3, 1, bd).pv3(0, 12, 5);
            }
            case "ocelot" -> {
                int col = c(236, 202, 100), dk = c(70, 50, 30), gr = c(110, 190, 90), pk = c(225, 150, 150);
                // slots: 0 tail, 1 head, 2..5 legs FL FR BL BR
                b.box(S, 0, 4, 0, 5, 5, 12, col);
                b.box(1, 0, 5.5f, 7, 5, 4, 5, col).pv3(0, 7, 5).eye(0.8f, 1.2f, 1.8f, 2.2f, gr).eye(3.2f, 1.2f, 4.2f, 2.2f, gr)
                 .dec(2.2f, 0, 2.8f, 0.8f, dk).dec(1.0f, 0, 1.5f, 0.6f, dk).dec(3.5f, 0, 4, 0.6f, dk).dec(2.2f, 2.5f, 2.8f, 3.1f, pk);
                b.box(1, -2, 9.5f, 7, 1.4f, 1.4f, 1, col).pv3(0, 7, 5);
                b.box(1, 2, 9.5f, 7, 1.4f, 1.4f, 1, col).pv3(0, 7, 5);
                b.box(2, 1.5f, 0, 4.5f, 2, 5, 2, col).pv(5);
                b.box(3, -1.5f, 0, 4.5f, 2, 5, 2, col).pv(5);
                b.box(4, 1.5f, 0, -4.5f, 2, 5, 2, col).pv(5);
                b.box(5, -1.5f, 0, -4.5f, 2, 5, 2, col).pv(5);
                b.box(0, 0, 6, -10, 1.5f, 1.5f, 8, col).pv3(0, 7, -6);
            }
            case "parrot" -> {
                int rd = c(205, 35, 35), bl = c(45, 95, 220), dk = c(25, 25, 25), bk = c(70, 70, 70), or = c(235, 160, 50);
                // slots: 0 wing L, 1 wing R, 2 head, 3 tail
                b.box(S, 0, 3, 0, 3, 5, 3, rd);
                b.box(S, -0.7f, 0, 0, 0.5f, 3, 0.5f, or);
                b.box(S, 0.7f, 0, 0, 0.5f, 3, 0.5f, or);
                b.box(2, 0, 8, 0.4f, 3, 3, 3, rd).pv(8).eye(0.5f, 1, 1.2f, 1.8f, dk).eye(1.8f, 1, 2.5f, 1.8f, dk);
                b.box(2, 0, 8.4f, 2.4f, 1, 1.6f, 1.4f, bk).pv(8);
                b.box(0, 2.1f, 3, 0, 0.8f, 4, 3, bl).pv3(1.5f, 7.5f, 0);
                b.box(1, -2.1f, 3, 0, 0.8f, 4, 3, bl).pv3(-1.5f, 7.5f, 0);
                b.box(3, 0, 0, -2.4f, 1.6f, 5, 0.8f, bl).pv3(0, 4, -1.5f);
            }
            case "bat" -> {
                int fur = c(80, 58, 44), wg = c(60, 44, 34), dk = c(20, 15, 15), pk = c(150, 90, 90);
                // slots: 0 wing L, 1 wing R, 2 head, 3 body (all bob together)
                b.box(3, 0, 2, 0, 4, 6, 3, fur);
                b.box(2, 0, 7.5f, 0, 5, 5, 5, fur).pv(8).eye(0.8f, 1.8f, 1.6f, 2.8f, dk).eye(3.4f, 1.8f, 4.2f, 2.8f, dk).dec(1.8f, 3.4f, 3.2f, 4.2f, pk);
                b.box(2, -1.7f, 12.2f, 0, 1.4f, 2, 1, fur).pv(8);
                b.box(2, 1.7f, 12.2f, 0, 1.4f, 2, 1, fur).pv(8);
                b.box(0, 5.5f, 2, 0, 7, 6, 0.8f, wg).pv3(2, 6, 0);
                b.box(1, -5.5f, 2, 0, 7, 6, 0.8f, wg).pv3(-2, 6, 0);
            }
            case "squid", "glow_squid" -> {
                boolean gl = id.equals("glow_squid");
                int body = gl ? c(40, 150, 160) : c(46, 70, 105), tent = gl ? c(70, 200, 195) : c(70, 100, 140), wh = gl ? c(190, 255, 245) : c(225, 230, 235), dk = c(15, 20, 30);
                // slots: 0..7 tentacles
                b.box(S, 0, 14, 0, 12, 16, 12, body).nz(0.1f).dec(0.8f, 10, 4.2f, 14.2f, wh).dec(7.8f, 10, 11.2f, 14.2f, wh)
                 .eye(2.4f, 11.5f, 4.2f, 13.8f, dk).eye(7.8f, 11.5f, 9.6f, 13.8f, dk);
                float[] tx = {4, -4, 0, 0, 3, -3, 3, -3}, tz = {0, 0, 4, -4, 3, 3, -3, -3};
                for (int i = 0; i < 8; i++) b.box(i, tx[i], 0, tz[i], 2, 14, 2, tent).pv(14);
            }
            case "dolphin" -> {
                int gr = c(112, 128, 146), lt = c(190, 200, 210), dk = c(20, 20, 25);
                // slots: 0 tail, 1 flipper L, 2 flipper R
                b.box(S, 0, 3, 0, 5, 6, 12, gr);
                b.box(S, 0, 3, 6.5f, 5, 5, 4, gr).eye(0.6f, 1.5f, 1.3f, 2.3f, dk).eye(3.7f, 1.5f, 4.4f, 2.3f, dk);
                b.box(S, 0, 3.2f, 9.6f, 2.4f, 2, 2.6f, lt);
                b.box(S, 0, 9, -1, 1, 4, 4, gr);
                b.box(0, 0, 3.5f, -8, 3.5f, 3, 5, gr).pv3(0, 4.5f, -6);
                b.box(0, 0, 4, -11.5f, 9, 1, 3, gr).pv3(0, 4.5f, -6);
                b.box(1, -3.5f, 2, 1.5f, 2, 1, 4, gr).pv3(-2.5f, 3.5f, 2);
                b.box(2, 3.5f, 2, 1.5f, 2, 1, 4, gr).pv3(2.5f, 3.5f, 2);
            }
            case "turtle" -> {
                int sh = c(78, 132, 62), dsh = c(48, 92, 42), sk = c(150, 170, 90), bl = c(215, 205, 150), dk = c(25, 25, 20);
                // slots: 0 head, 1..4 flippers FL FR BL BR
                b.box(S, 0, 2.5f, 0, 9, 1, 11, bl);
                b.box(S, 0, 3, 0, 10, 4, 12, sh).nz(0.14f).dec(2, 0.4f, 8, 1.6f, dsh);
                b.box(0, 0, 3.4f, 7.5f, 4, 3, 4, sk).pv3(0, 5, 5).eye(0.7f, 0.8f, 1.4f, 1.6f, dk).eye(2.6f, 0.8f, 3.3f, 1.6f, dk);
                b.box(1, 5.5f, 0.5f, 4, 3, 2, 4, sk).pv(2.5f);
                b.box(2, -5.5f, 0.5f, 4, 3, 2, 4, sk).pv(2.5f);
                b.box(3, 4.5f, 0.5f, -5.5f, 3, 2, 3, sk).pv(2.5f);
                b.box(4, -4.5f, 0.5f, -5.5f, 3, 2, 3, sk).pv(2.5f);
            }
            case "polar_bear" -> {
                int wh = c(246, 246, 242), sh = c(224, 224, 220), dk = c(25, 25, 28);
                // slots: 0 head, 1..4 legs
                b.box(1, 3.5f, 0, 6.5f, 4, 8, 4, wh).pv(8);
                b.box(2, -3.5f, 0, 6.5f, 4, 8, 4, wh).pv(8);
                b.box(3, 3.5f, 0, -6.5f, 4, 8, 4, wh).pv(8);
                b.box(4, -3.5f, 0, -6.5f, 4, 8, 4, wh).pv(8);
                b.box(S, 0, 8, 0, 10, 9, 18, wh).nz(0.05f);
                b.box(0, 0, 9, 11.5f, 7, 7, 7, wh).pv3(0, 12, 9).eye(1, 2.4f, 2, 3.4f, dk).eye(5, 2.4f, 6, 3.4f, dk);
                b.box(0, 0, 9.4f, 15.6f, 3, 2.6f, 2, sh).pv3(0, 12, 9).dec(0.8f, 0, 2.2f, 1, dk);
                b.box(0, -2.8f, 15.2f, 10, 2, 2, 1, wh).pv3(0, 12, 9);
                b.box(0, 2.8f, 15.2f, 10, 2, 2, 1, wh).pv3(0, 12, 9);
            }
            case "mooshroom" -> {
                int rd = c(172, 34, 34), wh = c(240, 240, 240), dk = c(30, 25, 25), mz = c(215, 185, 165), hn = c(230, 225, 205), cap = c(205, 40, 40);
                // slots: 0 head, 1..4 legs FL FR BL BR
                b.box(S, 0, 12, 0, 12, 10, 18, rd);
                b.box(S, 6.1f, 14, 3, 0.3f, 5, 6, wh).nz(0.03f);
                b.box(S, -6.1f, 17, -4, 0.3f, 4, 5, wh).nz(0.03f);
                b.box(S, -3, 22, -2, 1, 2, 1, wh);
                b.box(S, -3, 24, -2, 4, 1.5f, 4, cap).dec(0.6f, 0.4f, 1.6f, 1.2f, wh);
                b.box(S, 3, 22, 3, 1, 2, 1, wh);
                b.box(S, 3, 24, 3, 4, 1.5f, 4, cap).dec(2, 0.4f, 3, 1.2f, wh);
                b.box(0, 0, 15, 12, 8, 8, 6, rd).pv3(0, 20, 9).eye(1, 2.5f, 2.2f, 3.8f, dk).eye(5.8f, 2.5f, 7, 3.8f, dk);
                b.box(0, 0, 15, 15.4f, 6, 4, 1.6f, mz).pv3(0, 20, 9).dec(0.8f, 1, 1.6f, 2.2f, dk).dec(4.4f, 1, 5.2f, 2.2f, dk);
                b.box(0, -4, 23, 12, 1, 3, 1, hn).pv3(0, 20, 9);
                b.box(0, 4, 23, 12, 1, 3, 1, hn).pv3(0, 20, 9);
                b.box(1, 4, 0, 6, 4, 12, 4, rd).pv(12);
                b.box(2, -4, 0, 6, 4, 12, 4, rd).pv(12);
                b.box(3, 4, 0, -6, 4, 12, 4, rd).pv(12);
                b.box(4, -4, 0, -6, 4, 12, 4, rd).pv(12);
            }
            case "frog" -> {
                int gr = c(100, 156, 62), lt = c(220, 215, 150), gd = c(232, 190, 60), dk = c(25, 25, 20);
                // slots: 0 head, 1 leg BL, 2 leg BR
                b.box(S, 0, 2, 0, 7, 4, 7, gr);
                b.box(S, -2.5f, 0, 2.5f, 1.6f, 3, 1.6f, gr);
                b.box(S, 2.5f, 0, 2.5f, 1.6f, 3, 1.6f, gr);
                b.box(0, 0, 2.5f, 4.5f, 7, 3, 4, gr).pv3(0, 3, 3).dec(1.5f, 2.2f, 5.5f, 2.8f, lt);
                b.box(0, -2.2f, 5.5f, 4.2f, 2.5f, 2, 2.5f, gr).pv3(0, 3, 3).eye(0.4f, 0.4f, 2.1f, 1.7f, gd).eye(1, 0.7f, 1.6f, 1.5f, dk);
                b.box(0, 2.2f, 5.5f, 4.2f, 2.5f, 2, 2.5f, gr).pv3(0, 3, 3).eye(0.4f, 0.4f, 2.1f, 1.7f, gd).eye(1, 0.7f, 1.6f, 1.5f, dk);
                b.box(1, -3.2f, 0, -3.2f, 2, 4, 4.5f, gr).pv(4);
                b.box(2, 3.2f, 0, -3.2f, 2, 4, 4.5f, gr).pv(4);
            }
            case "cod", "salmon", "tropical_fish" -> {
                boolean sal = id.equals("salmon"), tr = id.equals("tropical_fish");
                int col = sal ? c(168, 62, 60) : tr ? c(255, 140, 30) : c(190, 152, 104), fin = sal ? c(120, 40, 45) : tr ? c(255, 250, 240) : c(150, 112, 74), dk = c(20, 20, 20);
                float len = sal ? 10 : tr ? 6 : 8;
                // slots: 0 tail, 1 body (floats up and down together)
                b.box(1, 0, 0, 0, 2, 4, len, col);
                b.box(1, 0, 0.4f, len / 2 + 0.8f, 2, 3.2f, 1.6f, col).eye(0.2f, 0.7f, 0.8f, 1.3f, dk).eye(1.2f, 0.7f, 1.8f, 1.3f, dk);
                b.box(1, 0, 4, 0, 0.6f, 2, len / 2, fin);
                if (tr) b.box(1, 0, 0, -0.5f, 2.1f, 4.1f, 1.2f, fin);
                b.box(0, 0, 0, -len / 2 - 1.8f, 0.8f, 4.4f, 3.6f, fin).pv3(0, 2, -len / 2);
            }
            case "pufferfish" -> {
                int ye = c(242, 204, 64), lt = c(250, 240, 190), or = c(220, 150, 50), dk = c(25, 25, 20);
                // slots: 0 fin tail, 1 body (floats)
                b.box(1, 0, 0, 0, 5, 5, 5, ye).dec(0, 3.5f, 5, 5, lt).eye(0.8f, 1.5f, 1.8f, 2.6f, dk).eye(3.2f, 1.5f, 4.2f, 2.6f, dk).dec(2.2f, 3, 2.8f, 3.5f, or);
                b.box(1, 0, 2, 3.2f, 1, 1, 1.4f, or);
                b.box(1, 0, 5, 0, 1, 1.4f, 1, or);
                b.box(1, -3.2f, 2, 0, 1.4f, 1, 1, or);
                b.box(1, 3.2f, 2, 0, 1.4f, 1, 1, or);
                b.box(0, 0, 1.5f, -3.4f, 1, 3, 2, or).pv3(0, 2.5f, -2.5f);
            }
            case "strider" -> {
                int rd = c(160, 56, 46), dr = c(120, 36, 30), bs = c(190, 80, 60), dk = c(30, 22, 20);
                // slots: 0 leg L, 1 leg R, 2 bristles L, 3 bristles R
                b.box(0, 3, 0, 0, 4, 10, 4, dr).pv(10);
                b.box(1, -3, 0, 0, 4, 10, 4, dr).pv(10);
                b.box(S, 0, 10, 0, 10, 8, 10, rd).nz(0.14f).eye(1.5f, 3, 3.5f, 4.2f, dk).eye(6.5f, 3, 8.5f, 4.2f, dk).dec(3, 5.4f, 7, 6.2f, dr);
                b.box(2, -5.8f, 11, 0, 1.5f, 5, 4, bs).pv3(-5, 17, 0);
                b.box(3, 5.8f, 11, 0, 1.5f, 5, 4, bs).pv3(5, 17, 0);
                b.box(S, -3, 18, 0, 1.5f, 4, 1.5f, bs);
                b.box(S, 0, 18, 2, 1.5f, 5, 1.5f, bs);
                b.box(S, 3, 18, -1, 1.5f, 4, 1.5f, bs);
            }
            case "sniffer" -> {
                int col = c(150, 52, 46), dc = c(110, 36, 34), mo = c(84, 134, 52), sk = c(204, 150, 130), dk = c(25, 20, 20);
                // slots: 0 head, 1..4 legs FL FR BL BR
                b.box(S, 0, 8, 0, 14, 10, 18, col).nz(0.1f);
                b.box(S, 0, 18, 0, 12, 1.5f, 14, mo).nz(0.2f);
                b.box(1, 5, 0, 6, 4, 8, 4, dc).pv(8);
                b.box(2, -5, 0, 6, 4, 8, 4, dc).pv(8);
                b.box(3, 5, 0, -6, 4, 8, 4, dc).pv(8);
                b.box(4, -5, 0, -6, 4, 8, 4, dc).pv(8);
                b.box(0, 0, 9, 11, 10, 8, 8, col).pv3(0, 14, 9).eye(1.2f, 2.4f, 2.6f, 3.8f, dk).eye(7.4f, 2.4f, 8.8f, 3.8f, dk);
                b.box(0, 0, 9.5f, 16.6f, 8, 4, 3, sk).pv3(0, 14, 9).dec(1.5f, 1, 2.5f, 2.2f, dk).dec(5.5f, 1, 6.5f, 2.2f, dk);
                b.box(0, -6.5f, 13, 10, 3, 5, 0.8f, mo).pv3(0, 14, 9);
                b.box(0, 6.5f, 13, 10, 3, 5, 0.8f, mo).pv3(0, 14, 9);
            }
            case "armadillo" -> {
                int sh = c(152, 102, 96), sk = c(198, 142, 132), dk = c(30, 22, 22);
                // slots: 0 head, 1..4 legs FL FR BL BR
                b.box(S, 0, 3, 0, 7, 6, 10, sh).nz(0.18f);
                b.box(S, 0, 3, -6.5f, 1.5f, 1.5f, 3, sk);
                b.box(1, 2.2f, 0, 3, 2, 3, 2, sk).pv(3);
                b.box(2, -2.2f, 0, 3, 2, 3, 2, sk).pv(3);
                b.box(3, 2.2f, 0, -3, 2, 3, 2, sk).pv(3);
                b.box(4, -2.2f, 0, -3, 2, 3, 2, sk).pv(3);
                b.box(0, 0, 4, 6.5f, 4, 5, 4, sk).pv3(0, 6, 5).eye(0.7f, 1.8f, 1.4f, 2.8f, dk).eye(2.6f, 1.8f, 3.3f, 2.8f, dk);
                b.box(0, -1.7f, 8.8f, 5.5f, 1, 2, 1, sk).pv3(0, 6, 5);
                b.box(0, 1.7f, 8.8f, 5.5f, 1, 2, 1, sk).pv3(0, 6, 5);
            }
            default -> throw new IllegalArgumentException("Unknown pet " + id);
        }
        float maxY = 0, maxX = 0, maxZ = 0;
        for (Raw r : b.raws) {
            maxY = Math.max(maxY, r.y1);
            maxX = Math.max(maxX, Math.max(Math.abs(r.x0), Math.abs(r.x1)));
            maxZ = Math.max(maxZ, Math.max(Math.abs(r.z0), Math.abs(r.z1)));
        }
        float ext = Math.max(maxY, Math.max(maxX, maxZ) * 2);
        float scale = TARGET / ext;
        return new Model(b.raws, scale, maxY, Math.max(maxX, maxZ));
    }

    // ---- animation ------------------------------------------------------------------------------------------------
    /** Sets the rotations (rx/rz around the pivot of each box, radians) and vertical offsets of this pet's parts. */
    public static void animate(String id, double t, int mode, double[] rx, double[] rz, double[] dy) {
        boolean moving = mode > 0;
        double ph = t * (mode == 2 ? 11.0 : 7.5);
        double sw = moving ? Math.sin(ph) * (mode == 2 ? 0.8 : 0.5) : 0;
        switch (id) {
            case "cat_orange", "cat_black", "cat_white" -> {
                rz[PART0] = Math.sin(t * 2.4) * 0.38;
                double tw = Math.exp(-Math.pow(((t % 4.3) - 1.0) / 0.09, 2));
                rz[PART0 + 1] = 0.45 * tw; rz[PART0 + 2] = -0.45 * Math.exp(-Math.pow(((t % 5.1) - 2.0) / 0.09, 2));
                double br = Math.sin(t * 1.7) * 0.1;
                dy[PART0 + 3] = br; dy[PART0 + 4] = br * 0.5;
            }
            case "zombie" -> {
                double a = -1.5 + Math.sin(t * 2.0) * 0.05;
                rx[PART0] = a; rx[PART0 + 1] = a;
                rx[PART0 + 2] = sw; rx[PART0 + 3] = -sw;
            }
            case "skeleton" -> {
                double idle = Math.sin(t * 1.3) * 0.05;
                rx[PART0] = idle - sw; rx[PART0 + 1] = -idle + sw;
                rx[PART0 + 2] = sw; rx[PART0 + 3] = -sw;
            }
            case "creeper" -> {
                rx[PART0] = sw; rx[PART0 + 1] = -sw; rx[PART0 + 2] = -sw; rx[PART0 + 3] = sw;
            }
            case "pig" -> {
                rx[PART0] = sw; rx[PART0 + 1] = -sw; rx[PART0 + 2] = -sw; rx[PART0 + 3] = sw;
                rx[PART0 + 4] = Math.sin(t * 1.5) * 0.09;
            }
            case "chicken" -> {
                double flap = Math.sin(t * (moving ? 12 : 5)) * (moving ? 0.5 : 0.12);
                rz[PART0] = -(0.12 + Math.abs(flap)); rz[PART0 + 1] = 0.12 + Math.abs(flap);
                rx[PART0 + 2] = 0.4 * Math.pow(Math.max(0, Math.sin(t * 1.7)), 8);
            }
            case "cow", "sheep", "llama", "camel", "goat", "polar_bear", "mooshroom", "sniffer", "armadillo", "turtle" -> {
                rx[PART0] = Math.sin(t * 0.8) * 0.06 + Math.pow(Math.max(0, Math.sin(t * 0.55)), 10) * 0.2;
                rx[PART0 + 1] = sw; rx[PART0 + 2] = -sw; rx[PART0 + 3] = -sw; rx[PART0 + 4] = sw;
            }
            case "wolf" -> {
                rz[PART0] = Math.sin(t * 6.0) * 0.4;
                rx[PART0 + 1] = Math.sin(t * 1.1) * 0.05;
                rx[PART0 + 2] = sw; rx[PART0 + 3] = -sw; rx[PART0 + 4] = -sw; rx[PART0 + 5] = sw;
            }
            case "spider" -> {
                for (int i = 0; i < 4; i++) {
                    double w = Math.sin(t * (moving ? 12 : 4) + i * 1.7) * (moving ? 0.25 : 0.1);
                    rz[PART0 + i] = w; rz[PART0 + 4 + i] = w;
                }
            }
            case "enderman" -> {
                double s2 = Math.sin(t * 1.3) * 0.1;
                rx[PART0] = s2 - sw * 0.5; rx[PART0 + 1] = -s2 + sw * 0.5;
                rx[PART0 + 2] = sw * 0.6; rx[PART0 + 3] = -sw * 0.6;
            }
            case "slime" -> dy[PART0] = Math.abs(Math.sin(t * 2.6)) * 1.5;
            case "villager" -> rx[PART0] = Math.sin(t * 0.9) * 0.06;
            case "rabbit" -> {
                rz[PART0] = 0.08 + Math.sin(t * 2.1) * 0.06 + (moving ? 0.25 : 0);
                rz[PART0 + 1] = -0.08 - Math.sin(t * 2.1 + 1) * 0.06 - (moving ? 0.25 : 0);
                rx[PART0 + 2] = Math.pow(Math.max(0, Math.sin(t * 1.4)), 10) * 0.3;
            }
            case "panda" -> {
                rx[PART0] = Math.sin(t * 0.8) * 0.06 + Math.pow(Math.max(0, Math.sin(t * 0.5)), 10) * 0.25;
                rx[PART0 + 1] = sw; rx[PART0 + 2] = -sw; rx[PART0 + 3] = -sw; rx[PART0 + 4] = sw;
            }
            case "fox", "ocelot" -> {
                rz[PART0] = Math.sin(t * 3.2) * 0.3;
                rx[PART0 + 1] = Math.sin(t * 1.2) * 0.05;
                rx[PART0 + 2] = sw; rx[PART0 + 3] = -sw; rx[PART0 + 4] = -sw; rx[PART0 + 5] = sw;
            }
            case "bee" -> {
                double flap = Math.abs(Math.sin(t * 28)) * 0.7;
                rz[PART0] = 0.15 + flap; rz[PART0 + 1] = -(0.15 + flap);
                double bob = Math.sin(t * 2.4) * 0.9;
                dy[PART0] = bob; dy[PART0 + 1] = bob; dy[PART0 + 2] = bob;
            }
            case "blaze" -> {
                dy[PART0] = Math.sin(t * 2.0) * 0.8;
                dy[PART0 + 1] = Math.sin(t * 2.6) * 0.6;
                dy[PART0 + 2] = Math.sin(t * 2.6 + 3) * 0.6;
            }
            case "iron_golem" -> {
                double idle = Math.sin(t * 1.1) * 0.04;
                rx[PART0] = idle - sw * 0.7; rx[PART0 + 1] = -idle + sw * 0.7;
                rx[PART0 + 2] = sw * 0.8; rx[PART0 + 3] = -sw * 0.8;
            }
            case "axolotl" -> {
                rz[PART0] = Math.sin(t * 2.2) * 0.25;
                rx[PART0 + 1] = Math.sin(t * 1.3) * 0.05;
                double g = Math.sin(t * 5.0) * 0.25;
                rz[PART0 + 2] = g; rz[PART0 + 3] = -g;
                rx[PART0 + 4] = sw; rx[PART0 + 5] = -sw; rx[PART0 + 6] = -sw; rx[PART0 + 7] = sw;
            }
            case "snow_golem" -> {
                double wv = Math.sin(t * 1.6) * 0.12;
                rz[PART0] = -(0.2 + wv + (moving ? Math.abs(sw) * 0.4 : 0));
                rz[PART0 + 1] = 0.2 - wv + (moving ? Math.abs(sw) * 0.4 : 0);
            }
            case "horse", "donkey" -> {
                rx[PART0] = Math.sin(t * 0.9) * 0.05 + Math.pow(Math.max(0, Math.sin(t * 0.6)), 10) * 0.25;
                rx[PART0 + 1] = sw; rx[PART0 + 2] = -sw; rx[PART0 + 3] = -sw; rx[PART0 + 4] = sw;
                rx[PART0 + 5] = Math.sin(t * 2.0) * 0.15;
                rz[PART0 + 5] = Math.sin(t * 3.0) * 0.25;
            }
            case "parrot" -> {
                double flap = Math.sin(t * (moving ? 22 : 4)) * (moving ? 0.8 : 0.1);
                rz[PART0] = -(0.12 + Math.abs(flap)); rz[PART0 + 1] = 0.12 + Math.abs(flap);
                rx[PART0 + 2] = Math.sin(t * 3.0) * 0.12;
                rx[PART0 + 3] = 0.15 + Math.sin(t * 2.0) * 0.06;
            }
            case "bat" -> {
                double flap = Math.sin(t * 14) * 0.7;
                rz[PART0] = -(0.3 + flap); rz[PART0 + 1] = 0.3 + flap;
                double bob = Math.sin(t * 2.2) * 0.8;
                dy[PART0] = bob; dy[PART0 + 1] = bob; dy[PART0 + 2] = bob; dy[PART0 + 3] = bob;
            }
            case "squid", "glow_squid" -> {
                for (int i = 0; i < 8; i++) {
                    rx[PART0 + i] = Math.sin(t * 3.0 + i * 0.8) * 0.28;
                    rz[PART0 + i] = Math.cos(t * 2.6 + i * 1.1) * 0.22;
                }
            }
            case "dolphin" -> {
                rx[PART0] = Math.sin(t * (moving ? 9 : 4)) * 0.4;
                rz[PART0 + 1] = Math.sin(t * 3.0) * 0.3; rz[PART0 + 2] = -Math.sin(t * 3.0) * 0.3;
            }
            case "frog" -> {
                rx[PART0] = Math.sin(t * 1.2) * 0.05;
                double hop = moving ? sw : 0;
                rx[PART0 + 1] = hop; rx[PART0 + 2] = hop;
                dy[PART0] = Math.pow(Math.max(0, Math.sin(t * 1.5)), 12) * 0.5;
            }
            case "cod", "salmon", "tropical_fish", "pufferfish" -> {
                double bob = Math.sin(t * 2.2) * 0.4;
                dy[PART0] = bob; dy[PART0 + 1] = bob;
                rx[PART0] = Math.sin(t * (moving ? 12 : 6)) * 0.4;
            }
            case "strider" -> {
                rx[PART0] = sw; rx[PART0 + 1] = -sw;
                double sway = Math.sin(t * 2.0) * 0.12;
                rz[PART0 + 2] = sway; rz[PART0 + 3] = -sway;
            }
            default -> { }
        }
    }
}
