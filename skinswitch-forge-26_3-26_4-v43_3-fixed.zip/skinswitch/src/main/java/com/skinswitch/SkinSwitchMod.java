package com.skinswitch;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/** Client-only mod entry point. Because it is client-only it can join vanilla/LAN/online servers. */
@Mod(SkinSwitchMod.MODID)
public final class SkinSwitchMod {
    public static final String MODID = "skinswitch";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SkinSwitchMod(FMLJavaModLoadingContext context) {
        LOGGER.info("Skin Switch loaded");
        com.skinswitch.client.ClientEvents.register();
        com.skinswitch.client.KeyBindings.register();
        com.skinswitch.client.sync.ChatSync.register();
    }
}
