package com.skinswitch.data;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Pure-Java local skin library (no Minecraft classes, so it is easy to test).
 * Skins live in  <game dir>/skinswitch/skins/*.png ; a tiny index.properties stores slim flags + selected skin.
 */
public final class SkinLibrary {
    private final Path skinDir;
    private final Path indexFile;
    private final Properties index = new Properties();
    private final List<SkinEntry> skins = new ArrayList<>();

    public SkinLibrary(Path root) {
        this.skinDir = root.resolve("skins");
        this.indexFile = root.resolve("index.properties");
    }

    public void load() throws IOException {
        Files.createDirectories(skinDir);
        index.clear();
        if (Files.exists(indexFile)) try (var in = Files.newInputStream(indexFile)) { index.load(in); }
        skins.clear();
        try (Stream<Path> s = Files.list(skinDir)) {
            s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
             .sorted().forEach(p -> {
                 String name = p.getFileName().toString();
                 String id = name.substring(0, name.length() - 4);
                 skins.add(new SkinEntry(id, id, p, Boolean.parseBoolean(index.getProperty("slim." + id, "false"))));
             });
        }
    }

    public List<SkinEntry> skins() { return Collections.unmodifiableList(skins); }

    /** Copies an external PNG into the library and returns the new entry. */
    public SkinEntry importFile(Path source) throws IOException {
        Files.createDirectories(skinDir);
        String base = source.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
        Path candidate = skinDir.resolve(base);
        int n = 1;
        while (Files.exists(candidate)) candidate = skinDir.resolve((n++) + "_" + base);
        final Path target = candidate;
        Files.copy(source, target);
        load();
        return skins.stream().filter(e -> e.file().equals(target)).findFirst().orElseThrow();
    }

    /** Saves a skin made in the editor as a new PNG in the library (name is cleaned up; never overwrites). */
    public SkinEntry saveNew(String name, java.awt.image.BufferedImage image, boolean slim) throws IOException {
        Files.createDirectories(skinDir);
        String base = name == null ? "" : name.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        if (base.toLowerCase(Locale.ROOT).endsWith(".png")) base = base.substring(0, base.length() - 4);
        if (base.replace("_", "").replace(".", "").isBlank()) base = "my_skin";
        Path candidate = skinDir.resolve(base + ".png");
        int n = 1;
        while (Files.exists(candidate)) candidate = skinDir.resolve(base + "_" + (n++) + ".png");
        if (!javax.imageio.ImageIO.write(image, "png", candidate.toFile())) throw new IOException("Cannot write PNG");
        final Path target = candidate;
        String id = target.getFileName().toString();
        id = id.substring(0, id.length() - 4);
        index.setProperty("slim." + id, Boolean.toString(slim));
        save();
        load();
        return skins.stream().filter(e -> e.file().equals(target)).findFirst().orElseThrow();
    }

    public void delete(SkinEntry e) throws IOException {
        Files.deleteIfExists(e.file());
        index.remove("slim." + e.id()); index.remove("fav." + e.id());
        if (e.id().equals(selectedId())) index.remove("selected");
        save(); load();
    }

    public void setSlim(SkinEntry e, boolean slim) throws IOException {
        index.setProperty("slim." + e.id(), Boolean.toString(slim));
        save(); load();
    }

    public boolean isFavorite(SkinEntry e) { return e != null && Boolean.parseBoolean(index.getProperty("fav." + e.id(), "false")); }

    public void toggleFavorite(SkinEntry e) throws IOException {
        if (e == null) return;
        if (isFavorite(e)) index.remove("fav." + e.id()); else index.setProperty("fav." + e.id(), "true");
        save();
    }

    public String selectedId() { return index.getProperty("selected", ""); }

    public void select(SkinEntry e) throws IOException {
        index.setProperty("selected", e.id());
        save();
    }

    private void save() throws IOException {
        Files.createDirectories(indexFile.getParent());
        try (var out = Files.newOutputStream(indexFile)) { index.store(out, "Skin Switch"); }
    }
}
