package com.skinswitch.data;

import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * Pure-Java state of the skin editor (no Minecraft classes -> unit-testable).
 * One 64x64 ARGB canvas holds both layers: the BASE skin and the DETAILS layer (hat / jacket / sleeves / pants = the
 * raised parts over the body). A part is edited as its "net": the unfolded box exactly as it sits in the skin PNG.
 */
public final class SkinEditorModel {
    public static final int HEAD = 0, BODY = 1, RARM = 2, LARM = 3, RLEG = 4, LLEG = 5, PARTS = 6;
    public static final int PENCIL = 0, ERASER = 1, FILL = 2, PICKER = 3;
    /** Colour every base pixel gets on a blank skin (and when a transparent base pixel is saved). */
    public static final int BASE_GRAY = 0xFFB4BAC6;

    private static final int[][] BASE_UV = {{0, 0}, {16, 16}, {40, 16}, {32, 48}, {0, 16}, {16, 48}};
    private static final int[][] LAYER_UV = {{32, 0}, {16, 32}, {40, 32}, {48, 48}, {0, 32}, {0, 48}};
    private static final int[][] DIMS = {{8, 8, 8}, {8, 12, 4}, {4, 12, 4}, {4, 12, 4}, {4, 12, 4}, {4, 12, 4}}; // w, h, d
    private static final int MAX_UNDO = 60;

    public record Rect(int x, int y, int w, int h) {
        public boolean contains(int px, int py) { return px >= x && px < x + w && py >= y && py < y + h; }
    }

    private final int[] px = new int[64 * 64];
    private final ArrayDeque<int[]> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private int[] strokeStart;
    private boolean slim;
    private int version;

    public SkinEditorModel() {
        blank();
        undo.clear(); redo.clear(); strokeStart = null; // the starting grey skin is not an undo step (Undo on a fresh editor wiped the base layer)
    }

    // ---- geometry ------------------------------------------------------------------------------------------------
    public int version() { return version; }
    public boolean slim() { return slim; }
    public void setSlim(boolean s) { if (slim != s) { slim = s; version++; } }

    private static boolean isArm(int part) { return part == RARM || part == LARM; }
    public int partW(int part) { return isArm(part) && slim ? 3 : DIMS[part][0]; }
    public int partH(int part) { return DIMS[part][1]; }
    public int partD(int part) { return DIMS[part][2]; }
    public int netW(int part) { return 2 * partD(part) + 2 * partW(part); }
    public int netH(int part) { return partD(part) + partH(part); }
    public int originX(int part, boolean details) { return (details ? LAYER_UV : BASE_UV)[part][0]; }
    public int originY(int part, boolean details) { return (details ? LAYER_UV : BASE_UV)[part][1]; }

    /** The six faces of a part relative to the net origin. Order: top, bottom, right, front, left, back. */
    public Rect[] faces(int part) { return faces(part, slim); }

    private Rect[] faces(int part, boolean slimArms) {
        int w = isArm(part) && slimArms ? 3 : DIMS[part][0], h = DIMS[part][1], d = DIMS[part][2];
        return new Rect[] { new Rect(d, 0, w, d), new Rect(d + w, 0, w, d), new Rect(0, d, d, h),
                            new Rect(d, d, w, h), new Rect(d + w, d, d, h), new Rect(2 * d + w, d, w, h) };
    }

    /** Index of the face under the net pixel, or -1 for the unused corners. */
    public int faceAt(int part, int nx, int ny) {
        Rect[] f = faces(part);
        for (int i = 0; i < f.length; i++) if (f[i].contains(nx, ny)) return i;
        return -1;
    }

    // ---- pixels --------------------------------------------------------------------------------------------------
    public int pixel(int part, boolean details, int nx, int ny) {
        return px[(originY(part, details) + ny) * 64 + originX(part, details) + nx];
    }

    private int idx(int part, boolean details, int nx, int ny) {
        return (originY(part, details) + ny) * 64 + originX(part, details) + nx;
    }

    private boolean put(int part, boolean details, Rect face, int nx, int ny, int color) {
        if (!face.contains(nx, ny)) return false;
        int i = idx(part, details, nx, ny);
        if (px[i] == color) return false;
        px[i] = color;
        return true;
    }

    /** Pencil / eraser stamp (brush 1..3, optional left-right mirror inside the same face). True if anything changed. */
    public boolean paint(int part, boolean details, int nx, int ny, int tool, int rgb, int brush, boolean symmetry) {
        if (tool == ERASER && !details) return false; // the base layer cannot have holes
        int face = faceAt(part, nx, ny);
        if (face < 0) return false;
        Rect f = faces(part)[face];
        int color = tool == ERASER ? 0 : 0xFF000000 | rgb;
        int lo = -(brush - 1) / 2, hi = brush / 2;
        boolean changed = false;
        for (int dy = lo; dy <= hi; dy++) for (int dx = lo; dx <= hi; dx++) {
            int x = nx + dx, y = ny + dy;
            changed |= put(part, details, f, x, y, color);
            if (symmetry) changed |= put(part, details, f, f.x() + f.w() - 1 - (x - f.x()), y, color);
        }
        if (changed) version++;
        return changed;
    }

    /** Flood fill inside one face. */
    public boolean fill(int part, boolean details, int nx, int ny, int rgb) {
        int face = faceAt(part, nx, ny);
        if (face < 0) return false;
        Rect f = faces(part)[face];
        int color = 0xFF000000 | rgb, target = norm(pixel(part, details, nx, ny));
        if (target == color) return false;
        ArrayDeque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{nx, ny});
        boolean changed = false;
        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            if (!f.contains(p[0], p[1])) continue;
            int i = idx(part, details, p[0], p[1]);
            if (norm(px[i]) != target) continue;
            px[i] = color; changed = true;
            stack.push(new int[]{p[0] + 1, p[1]}); stack.push(new int[]{p[0] - 1, p[1]});
            stack.push(new int[]{p[0], p[1] + 1}); stack.push(new int[]{p[0], p[1] - 1});
        }
        if (changed) version++;
        return changed;
    }

    private static int norm(int c) { return (c >>> 24) == 0 ? 0 : c; }

    /** RGB (0..0xFFFFFF) under the pixel, looking through an empty details pixel to the base; -1 = nothing there. */
    public int pick(int part, boolean details, int nx, int ny) {
        if (faceAt(part, nx, ny) < 0) return -1;
        int c = pixel(part, details, nx, ny);
        if ((c >>> 24) == 0) c = pixel(part, false, nx, ny);
        return (c >>> 24) == 0 ? -1 : c & 0xFFFFFF;
    }

    // ---- undo / redo (one step = one stroke) -----------------------------------------------------------------------
    public void beginStroke() { strokeStart = px.clone(); }

    public void endStroke() {
        if (strokeStart == null) return;
        if (!Arrays.equals(strokeStart, px)) {
            undo.push(strokeStart); redo.clear();
            while (undo.size() > MAX_UNDO) undo.removeLast();
        }
        strokeStart = null;
    }

    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }

    public void undo() {
        if (undo.isEmpty()) return;
        redo.push(px.clone());
        System.arraycopy(undo.pop(), 0, px, 0, px.length);
        version++;
    }

    public void redo() {
        if (redo.isEmpty()) return;
        undo.push(px.clone());
        System.arraycopy(redo.pop(), 0, px, 0, px.length);
        version++;
    }

    // ---- whole-skin operations -----------------------------------------------------------------------------------
    /** Flat grey skin, empty details layer. */
    public void blank() {
        beginStroke();
        Arrays.fill(px, 0);
        for (int p = 0; p < PARTS; p++) for (Rect f : faces(p, false))
            for (int y = 0; y < f.h(); y++) for (int x = 0; x < f.w(); x++) px[idx(p, false, f.x() + x, f.y() + y)] = BASE_GRAY;
        version++;
        endStroke();
    }

    /** Copies a 64x64 (or bigger: top-left 64x64) image into the canvas. */
    public void loadFrom(BufferedImage img) {
        beginStroke();
        Arrays.fill(px, 0);
        int w = Math.min(64, img.getWidth()), h = Math.min(64, img.getHeight());
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * 64 + x] = img.getRGB(x, y);
        version++;
        endStroke();
    }

    /** The finished skin PNG: base layer fully opaque (Minecraft draws holes there), details layer as painted. */
    public BufferedImage toImage() {
        int[] out = px.clone();
        for (int p = 0; p < PARTS; p++) for (Rect f : faces(p, false))
            for (int y = 0; y < f.h(); y++) for (int x = 0; x < f.w(); x++) {
                int i = idx(p, false, f.x() + x, f.y() + y), c = out[i];
                out[i] = (c >>> 24) == 0 ? BASE_GRAY : c | 0xFF000000;
            }
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        img.setRGB(0, 0, 64, 64, out, 0, 64);
        return img;
    }
}
