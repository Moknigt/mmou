package com.skinswitch.data;

import com.skinswitch.render.CapeImage;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Capes = those downloaded at build time (bundled in the jar) + your own PNGs in <root>/capes/.
 * Favourites (star) are listed first. Selection + favourites are stored in capes.properties.
 */
public final class CapeLibrary {
    private final Path capeDir, indexFile;
    private final Properties index = new Properties();
    private final List<CapeEntry> capes = new ArrayList<>();
    private final Map<String, CapeImage> cache = new HashMap<>();

    public CapeLibrary(Path root) { this.capeDir = root.resolve("capes"); this.indexFile = root.resolve("capes.properties"); }

    public void load() throws IOException {
        Files.createDirectories(capeDir);
        index.clear();
        if (Files.exists(indexFile)) try (var in = Files.newInputStream(indexFile)) { index.load(in); }
        capes.clear(); cache.clear();
        loadBundled();
        try (Stream<Path> s = Files.list(capeDir)) {
            s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")).sorted().forEach(p -> {
                String n = p.getFileName().toString();
                capes.add(new CapeEntry("file:" + n, n.substring(0, n.length() - 4), p, null));
            });
        }
        sortFavouritesFirst();
    }

    /** Capes downloaded at build time (see build.gradle downloadCapes). */
    private void loadBundled() {
        try (var in = CapeLibrary.class.getResourceAsStream("/assets/skinswitch/capes/index.txt")) {
            if (in == null) return;
            for (String line : new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).split("\\R")) {
                String[] p = line.split("\\|", 2);
                if (p.length == 2 && !p[0].isBlank()) capes.add(new CapeEntry("pack:" + p[0], p[1], null, "/assets/skinswitch/capes/" + p[0]));
            }
        } catch (IOException ignored) {}
    }

    private void sortFavouritesFirst() {
        List<CapeEntry> favs = new ArrayList<>(), rest = new ArrayList<>();
        for (CapeEntry c : capes) (isFavorite(c) ? favs : rest).add(c);
        capes.clear(); capes.addAll(favs); capes.addAll(rest); // stable: keeps the original order inside each group
    }

    public List<CapeEntry> capes() { return Collections.unmodifiableList(capes); }
    public String selectedId() { return index.getProperty("selected", ""); }
    public CapeEntry selected() { return capes.stream().filter(c -> c.id().equals(selectedId())).findFirst().orElse(null); }

    public boolean isFavorite(CapeEntry e) { return e != null && Boolean.parseBoolean(index.getProperty("fav." + e.id(), "false")); }

    public void toggleFavorite(CapeEntry e) throws IOException {
        if (e == null) return;
        if (isFavorite(e)) index.remove("fav." + e.id()); else index.setProperty("fav." + e.id(), "true");
        save(); sortFavouritesFirst();
    }

    public void select(CapeEntry e) throws IOException {
        index.setProperty("selected", e == null ? "" : e.id());
        save();
    }

    private void save() throws IOException {
        Files.createDirectories(indexFile.getParent());
        try (var out = Files.newOutputStream(indexFile)) { index.store(out, "Skin Switch capes"); }
    }

    /** Saves a cape made in the editor (64 x 32n PNG) into the capes folder; never overwrites. */
    public CapeEntry saveNew(String name, java.awt.image.BufferedImage image) throws IOException {
        Files.createDirectories(capeDir);
        String base = name == null ? "" : name.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        if (base.toLowerCase(Locale.ROOT).endsWith(".png")) base = base.substring(0, base.length() - 4);
        if (base.replace("_", "").replace(".", "").isBlank()) base = "my_cape";
        Path candidate = capeDir.resolve(base + ".png");
        int n = 1;
        while (Files.exists(candidate)) candidate = capeDir.resolve(base + "_" + (n++) + ".png");
        if (!javax.imageio.ImageIO.write(image, "png", candidate.toFile())) throw new IOException("Cannot write PNG");
        load();
        String id = "file:" + candidate.getFileName();
        return capes.stream().filter(c -> c.id().equals(id)).findFirst().orElseThrow();
    }

    public CapeEntry importFile(Path source) throws IOException {
        Files.createDirectories(capeDir);
        String base = source.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
        Path candidate = capeDir.resolve(base);
        int n = 1;
        while (Files.exists(candidate)) candidate = capeDir.resolve((n++) + "_" + base);
        CapeImage.load(source); // validates it is a readable image
        Files.copy(source, candidate);
        load();
        String id = "file:" + candidate.getFileName();
        return capes.stream().filter(c -> c.id().equals(id)).findFirst().orElseThrow();
    }

    public CapeImage image(CapeEntry e) {
        if (e == null) return null;
        return cache.computeIfAbsent(e.id(), k -> {
            try {
                if (e.resource() != null) try (var in = CapeLibrary.class.getResourceAsStream(e.resource())) {
                    return new CapeImage(javax.imageio.ImageIO.read(in));
                }
                return CapeImage.load(e.file());
            } catch (IOException | RuntimeException ex) { return null; }
        });
    }
}
