package com.skinswitch.data;

import java.nio.file.Path;

/** A cape: either downloaded at build time and bundled in the jar (resource), or a PNG from the capes folder (file). */
public record CapeEntry(String id, String name, Path file, String resource) {}
