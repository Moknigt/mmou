package com.skinswitch.data;

import com.skinswitch.render.ElytraArt;

import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Pure-Java state of the cape editor. One frame = a 64x32 ARGB texture holding the CAPE (22x17 at 0,0) and the ELYTRA
 * wing (24x22 at 22,0); an animated cape is several frames stacked vertically in the saved PNG.
 * With "auto elytra" on, the wing is regenerated from the cape every time the cape is edited.
 */
public final class CapeEditorModel {
    public static final int CAPE = 0, ELYTRA = 1;
    public static final int PENCIL = 0, ERASER = 1, FILL = 2, PICKER = 3;
    public static final int BASE_COLOR = 0xFFC0392B;
    public static final int W = 64, H = 32;
    private static final int[][] ORIGIN = {{0, 0}, {22, 0}};
    private static final int[][] DIMS = {{10, 16, 1}, {10, 20, 2}}; // w, h, d
    private static final int MAX_UNDO = 40, MAX_FRAMES = 64;

    public record Rect(int x, int y, int w, int h) {
        public boolean contains(int px, int py) { return px >= x && px < x + w && py >= y && py < y + h; }
    }

    private List<int[]> frames = new ArrayList<>();
    private int cur;
    private boolean autoElytra = true;
    private int version;
    private final ArrayDeque<State> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private State strokeStart;

    private record State(List<int[]> frames, int cur, boolean auto) {}

    public CapeEditorModel() {
        blank();
        undo.clear(); redo.clear(); strokeStart = null; // the starting blank cape is not an undo step (undoing it would leave no frame at all)
    }

    // ---- geometry ------------------------------------------------------------------------------------------------
    public int version() { return version; }
    public int partW(int p) { return DIMS[p][0]; }
    public int partH(int p) { return DIMS[p][1]; }
    public int partD(int p) { return DIMS[p][2]; }
    public int netW(int p) { return 2 * DIMS[p][2] + 2 * DIMS[p][0]; }
    public int netH(int p) { return DIMS[p][2] + DIMS[p][1]; }

    /** Faces relative to the net origin. Order: top, bottom, right side, front, left side, back.
     *  Cape: front = OUTER face (what people see), back = inner face. */
    public Rect[] faces(int p) {
        int w = DIMS[p][0], h = DIMS[p][1], d = DIMS[p][2];
        return new Rect[] { new Rect(d, 0, w, d), new Rect(d + w, 0, w, d), new Rect(0, d, d, h),
                            new Rect(d, d, w, h), new Rect(d + w, d, d, h), new Rect(2 * d + w, d, w, h) };
    }

    public int faceAt(int p, int nx, int ny) {
        Rect[] f = faces(p);
        for (int i = 0; i < f.length; i++) if (f[i].contains(nx, ny)) return i;
        return -1;
    }

    private int idx(int p, int nx, int ny) { return (ORIGIN[p][1] + ny) * W + ORIGIN[p][0] + nx; }
    public int pixel(int p, int nx, int ny) { return frames.get(cur)[idx(p, nx, ny)]; }

    // ---- frames --------------------------------------------------------------------------------------------------
    public int frameCount() { return frames.size(); }
    public int currentFrame() { return cur; }
    public void setCurrentFrame(int i) { if (i >= 0 && i < frames.size() && i != cur) { cur = i; version++; } }

    public void duplicateFrame() {
        if (frames.size() >= MAX_FRAMES) return;
        beginStroke();
        frames.add(cur + 1, frames.get(cur).clone());
        cur++; version++;
        endStroke();
    }

    public void deleteFrame() {
        if (frames.size() <= 1) return;
        beginStroke();
        frames.remove(cur);
        cur = Math.min(cur, frames.size() - 1); version++;
        endStroke();
    }

    public void moveFrame(int dir) {
        int to = cur + dir;
        if (to < 0 || to >= frames.size()) return;
        beginStroke();
        int[] f = frames.remove(cur);
        frames.add(to, f);
        cur = to; version++;
        endStroke();
    }

    // ---- elytra --------------------------------------------------------------------------------------------------
    public boolean autoElytra() { return autoElytra; }

    public void setAutoElytra(boolean on) {
        if (on == autoElytra) return;
        beginStroke();
        autoElytra = on;
        if (on) for (int[] f : frames) regenElytra(f);
        version++;
        endStroke();
    }

    /** Rebuilds the wing of one frame from the cape's outer face (wing-shaped, outlined, with feather ribs - see {@link ElytraArt}). */
    public static void regenElytra(int[] f) { ElytraArt.generate(f); }

    // ---- painting ------------------------------------------------------------------------------------------------
    private boolean put(int p, Rect face, int nx, int ny, int color) {
        if (!face.contains(nx, ny)) return false;
        int[] f = frames.get(cur);
        int i = idx(p, nx, ny);
        if (f[i] == color) return false;
        f[i] = color;
        return true;
    }

    private void afterEdit(int p) {
        if (p == ELYTRA && autoElytra) autoElytra = false;      // painting the wing yourself = manual
        else if (p == CAPE && autoElytra) regenElytra(frames.get(cur));
        version++;
    }

    public boolean paint(int p, int nx, int ny, int tool, int rgb, int brush, boolean symmetry) {
        int face = faceAt(p, nx, ny);
        if (face < 0) return false;
        Rect r = faces(p)[face];
        int color = tool == ERASER ? 0 : 0xFF000000 | rgb;
        int lo = -(brush - 1) / 2, hi = brush / 2;
        boolean changed = false;
        for (int dy = lo; dy <= hi; dy++) for (int dx = lo; dx <= hi; dx++) {
            int x = nx + dx, y = ny + dy;
            changed |= put(p, r, x, y, color);
            if (symmetry) changed |= put(p, r, r.x() + r.w() - 1 - (x - r.x()), y, color);
        }
        if (changed) afterEdit(p);
        return changed;
    }

    private static int norm(int c) { return (c >>> 24) == 0 ? 0 : c; }

    public boolean fill(int p, int nx, int ny, int rgb) {
        int face = faceAt(p, nx, ny);
        if (face < 0) return false;
        Rect r = faces(p)[face];
        int[] f = frames.get(cur);
        int color = 0xFF000000 | rgb, target = norm(pixel(p, nx, ny));
        if (target == color) return false;
        ArrayDeque<int[]> st = new ArrayDeque<>();
        st.push(new int[]{nx, ny});
        boolean changed = false;
        while (!st.isEmpty()) {
            int[] q = st.pop();
            if (!r.contains(q[0], q[1])) continue;
            int i = idx(p, q[0], q[1]);
            if (norm(f[i]) != target) continue;
            f[i] = color; changed = true;
            st.push(new int[]{q[0] + 1, q[1]}); st.push(new int[]{q[0] - 1, q[1]});
            st.push(new int[]{q[0], q[1] + 1}); st.push(new int[]{q[0], q[1] - 1});
        }
        if (changed) afterEdit(p);
        return changed;
    }

    /** RGB under the pixel, -1 if empty / unused. */
    public int pick(int p, int nx, int ny) {
        if (faceAt(p, nx, ny) < 0) return -1;
        int c = pixel(p, nx, ny);
        return (c >>> 24) == 0 ? -1 : c & 0xFFFFFF;
    }

    // ---- undo / redo ---------------------------------------------------------------------------------------------
    private State snapshot() {
        List<int[]> copy = new ArrayList<>();
        for (int[] f : frames) copy.add(f.clone());
        return new State(copy, cur, autoElytra);
    }

    private void restore(State s) {
        if (s.frames().isEmpty()) return;
        List<int[]> copy = new ArrayList<>();
        for (int[] f : s.frames()) copy.add(f.clone());
        frames = copy; cur = Math.min(s.cur(), copy.size() - 1); autoElytra = s.auto();
        version++;
    }

    private static boolean same(State a, State b) {
        if (a.cur() != b.cur() || a.auto() != b.auto() || a.frames().size() != b.frames().size()) return false;
        for (int i = 0; i < a.frames().size(); i++) if (!Arrays.equals(a.frames().get(i), b.frames().get(i))) return false;
        return true;
    }

    public void beginStroke() { strokeStart = snapshot(); }

    public void endStroke() {
        if (strokeStart == null) return;
        if (!same(strokeStart, snapshot())) {
            undo.push(strokeStart); redo.clear();
            while (undo.size() > MAX_UNDO) undo.removeLast();
        }
        strokeStart = null;
    }

    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }
    public void undo() { if (!undo.isEmpty()) { redo.push(snapshot()); restore(undo.pop()); } }
    public void redo() { if (!redo.isEmpty()) { undo.push(snapshot()); restore(redo.pop()); } }

    // ---- whole-cape operations -----------------------------------------------------------------------------------
    /** One solid red frame (cape + wing). */
    public void blank() {
        beginStroke();
        int[] f = new int[W * H];
        for (Rect r : faces(CAPE)) for (int y = 0; y < r.h(); y++) for (int x = 0; x < r.w(); x++) f[idx(CAPE, r.x() + x, r.y() + y)] = BASE_COLOR;
        regenElytra(f);
        frames = new ArrayList<>(List.of(f));
        cur = 0; autoElytra = true; version++;
        endStroke();
    }

    /** Loads a 64-wide strip (64 x 32n). Frames beyond MAX_FRAMES are dropped. */
    public void loadFrom(BufferedImage img) {
        beginStroke();
        List<int[]> list = new ArrayList<>();
        int n = Math.max(1, Math.min(MAX_FRAMES, img.getHeight() / H));
        for (int k = 0; k < n; k++) {
            int[] f = new int[W * H];
            for (int y = 0; y < H && k * H + y < img.getHeight(); y++)
                for (int x = 0; x < W && x < img.getWidth(); x++) f[y * W + x] = img.getRGB(x, k * H + y);
            list.add(f);
        }
        frames = list; cur = 0;
        boolean hasWing = ElytraArt.hasArt(list.get(0)); // keep a wing that already exists; otherwise make one from the cape
        autoElytra = !hasWing;
        if (autoElytra) for (int[] f : frames) regenElytra(f);
        version++;
        endStroke();
    }

    /** The finished PNG: 64 x 32*frames (a single frame = a normal static cape). */
    public BufferedImage toImage() {
        BufferedImage img = new BufferedImage(W, H * frames.size(), BufferedImage.TYPE_INT_ARGB);
        for (int k = 0; k < frames.size(); k++) img.setRGB(0, k * H, W, H, frames.get(k), 0, W);
        return img;
    }
}
