package com.skinswitch.data;

import java.nio.file.Path;

/** One skin in the library: a PNG file plus the arm model (classic = Steve, slim = Alex). */
public record SkinEntry(String id, String displayName, Path file, boolean slim) {}
