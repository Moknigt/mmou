package com.skinswitch.data;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Pure-Java state + layout of the skin screen (no Minecraft classes -> unit-testable). */
public final class SkinScreenModel {
    public static final int COLUMNS = 4, SLOT = 44, GAP = 6, PAD = 12;

    public record Rect(int x, int y, int w, int h) {
        public boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final SkinLibrary library;
    private List<SkinEntry> view = new ArrayList<>();
    private int selected = -1;
    private boolean sortByName = true;

    public SkinScreenModel(SkinLibrary library) { this.library = library; refresh(); }

    public void refresh() {
        String keep = selected >= 0 && selected < view.size() ? view.get(selected).id() : library.selectedId();
        view = new ArrayList<>(library.skins());
        Comparator<SkinEntry> order = sortByName ? Comparator.comparing(e -> e.id().toLowerCase())
                                                 : Comparator.comparingLong(e -> e.file().toFile().lastModified());
        view.sort(Comparator.comparing((SkinEntry e) -> !library.isFavorite(e)).thenComparing(order)); // starred first
        selected = -1;
        for (int i = 0; i < view.size(); i++) if (view.get(i).id().equals(keep)) selected = i;
        if (selected < 0 && !view.isEmpty()) selected = 0;
    }

    public List<SkinEntry> entries() { return view; }
    public int count() { return view.size(); }
    public SkinEntry selected() { return selected >= 0 && selected < view.size() ? view.get(selected) : null; }
    /** 1-based index for the "Skins 1/7" label. */
    public int selectedNumber() { return selected + 1; }

    public void select(int i) { if (i >= 0 && i < view.size()) selected = i; }
    public void toggleSort() { sortByName = !sortByName; refresh(); }

    /** Slot rectangle relative to the grid origin (x0,y0). */
    public Rect slot(int i, int x0, int y0) {
        return new Rect(x0 + (i % COLUMNS) * (SLOT + GAP), y0 + (i / COLUMNS) * (SLOT + GAP), SLOT, SLOT);
    }

    /** Index of the slot under the mouse or -1. */
    public int slotAt(double mx, double my, int x0, int y0) {
        for (int i = 0; i < view.size(); i++) if (slot(i, x0, y0).contains(mx, my)) return i;
        return -1;
    }

    public int gridHeight() { return ((Math.max(view.size(), 1) + COLUMNS - 1) / COLUMNS) * (SLOT + GAP); }

    public void deleteSelected() throws java.io.IOException {
        SkinEntry e = selected();
        if (e != null) { library.delete(e); refresh(); }
    }

    public void toggleSlimSelected() throws java.io.IOException {
        SkinEntry e = selected();
        if (e != null) { library.setSlim(e, !e.slim()); refresh(); }
    }

    public boolean isFavorite(SkinEntry e) { return library.isFavorite(e); }

    public void toggleFavoriteSelected() throws java.io.IOException {
        SkinEntry e = selected();
        if (e == null) return;
        String id = e.id();
        library.toggleFavorite(e);
        selected = -1; view = new ArrayList<>(library.skins());
        refreshKeeping(id);
    }

    private void refreshKeeping(String id) {
        // re-sort with the favourite on top and keep the same skin selected
        String keepOld = library.selectedId();
        refresh();
        for (int i = 0; i < view.size(); i++) if (view.get(i).id().equals(id)) selected = i;
        if (selected < 0) for (int i = 0; i < view.size(); i++) if (view.get(i).id().equals(keepOld)) selected = i;
    }

    public void confirm() throws java.io.IOException {
        SkinEntry e = selected();
        if (e != null) library.select(e);
    }
}
