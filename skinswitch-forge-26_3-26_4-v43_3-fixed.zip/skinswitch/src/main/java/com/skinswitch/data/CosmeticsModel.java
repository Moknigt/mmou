package com.skinswitch.data;

import com.skinswitch.render.Accessories;
import com.skinswitch.render.PetModels;

import java.util.ArrayList;
import java.util.List;

/**
 * State of the Cosmetics menu (tabs Animals | Accessories). Pure Java (no Minecraft classes -> unit-testable).
 * Clicking a tile only PREVIEWS it on the character; the choice is saved when you press Equip (or Remove / Remove all).
 */
public final class CosmeticsModel {
    public static final int ANIMALS = 0, ITEMS = 1;

    /** Where the choices are kept (UiPrefs in the game, a fake in tests). */
    public interface Store {
        String pet();
        void setPet(String id);
        List<String> accessories();
        void setAccessories(List<String> ids);
    }

    /** Menu order of the accessory categories (names: skinswitch.acc.cat.*). */
    public static final String[] CATEGORIES = {"head", "face", "float", "ear", "neck", "shoulder", "back", "body"};

    private final Store store;
    private int tab = ITEMS;
    private String selPet;        // previewed animal (null = nothing picked yet)
    private boolean selNone;      // the "None" tile of the animals tab
    private String selAcc;        // previewed accessory

    public CosmeticsModel(Store store) { this.store = store; }

    // ---- tabs --------------------------------------------------------------------------------------------------------
    public int tab() { return tab; }
    public void setTab(int t) { tab = t == ANIMALS ? ANIMALS : ITEMS; }

    // ---- catalogue ---------------------------------------------------------------------------------------------------
    public static List<String> animals() { return List.of(PetModels.IDS); }

    /** Accessory ids of one category, catalogue order. */
    public static List<String> itemsOf(String category) {
        List<String> l = new ArrayList<>();
        for (String id : Accessories.IDS) if (Accessories.category(id).equals(category)) l.add(id);
        return l;
    }

    // ---- selection ---------------------------------------------------------------------------------------------------
    public void selectAnimal(String id) { selNone = false; selPet = PetModels.exists(id) ? id : null; }
    public void selectNone() { selNone = true; selPet = null; }
    public void selectItem(String id) { selAcc = Accessories.exists(id) ? id : null; }
    public String selectedAnimal() { return selPet; }
    public boolean noneSelected() { return selNone; }
    public String selectedItem() { return selAcc; }

    /** Id of the selected tile of the current tab (null = nothing, or the None tile). */
    public String selectedId() { return tab == ANIMALS ? selPet : selAcc; }
    public boolean hasSelection() { return tab == ANIMALS ? (selPet != null || selNone) : selAcc != null; }

    // ---- what is worn ------------------------------------------------------------------------------------------------
    public String wornPet() { return store.pet(); }
    public List<String> wornItems() { return Accessories.normalize(store.accessories()); }
    public boolean isWornPet(String id) { return id != null && id.equals(store.pet()); }
    public boolean isWornItem(String id) { return wornItems().contains(id); }

    /** True when the selected tile is already worn (for the None tile: when no animal is worn). */
    public boolean selectedWorn() {
        if (!hasSelection()) return false;
        if (tab == ANIMALS) return selNone ? store.pet() == null : isWornPet(selPet);
        return isWornItem(selAcc);
    }

    public boolean canEquip() { return hasSelection() && !selectedWorn() && !(tab == ANIMALS && selNone); }
    public boolean canRemove() {
        if (tab == ANIMALS) return store.pet() != null && (!hasSelection() || selNone || isWornPet(selPet));
        return selAcc != null && isWornItem(selAcc);
    }
    public boolean canClear() { return tab == ANIMALS ? store.pet() != null : !wornItems().isEmpty(); }

    // ---- what the character shows right now (worn + the piece being previewed) -----------------------------------------
    public String previewPet() {
        if (tab == ANIMALS && selNone) return null;
        if (tab == ANIMALS && selPet != null) return selPet;
        return store.pet();
    }

    public List<String> previewItems() {
        List<String> worn = wornItems();
        if (tab != ITEMS || selAcc == null || worn.contains(selAcc)) return worn;
        return Accessories.toggle(worn, selAcc); // it goes on, and the pieces it would overlap come off
    }

    /** Accessories that the selected (not yet worn) piece would push off: shown in the hint line. */
    public List<String> replacedBySelection() {
        List<String> out = new ArrayList<>();
        if (tab != ITEMS || selAcc == null) return out;
        for (String w : wornItems()) if (!w.equals(selAcc) && Accessories.conflict(w, selAcc)) out.add(w);
        return out;
    }

    // ---- actions -----------------------------------------------------------------------------------------------------
    /** Puts the selected tile on. Returns false when there was nothing to do. */
    public boolean equip() {
        if (!canEquip()) return false;
        if (tab == ANIMALS) store.setPet(selPet);
        else store.setAccessories(Accessories.toggle(wornItems(), selAcc));
        return true;
    }

    /** Takes the selected piece off (animals: the worn animal). */
    public boolean remove() {
        if (!canRemove()) return false;
        if (tab == ANIMALS) { store.setPet(null); selPet = null; selNone = false; }
        else store.setAccessories(Accessories.toggle(wornItems(), selAcc));
        return true;
    }

    /** Takes off everything of the current tab. */
    public boolean clear() {
        if (!canClear()) return false;
        if (tab == ANIMALS) { store.setPet(null); selPet = null; selNone = false; }
        else store.setAccessories(List.of());
        return true;
    }

    /** Double-click on a tile: equip it, or take it off when it is already worn. */
    public void quickToggle() {
        if (canEquip()) equip(); else if (selectedWorn() || (tab == ANIMALS && selNone)) remove();
    }
}
