package com.skinswitch.client.sync;

import com.skinswitch.render.Accessories;
import com.skinswitch.render.PetModels;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CosmeticsMessageCodecTest {
    @Test
    void parsesPetAndAccessoryCatalogueIndexes() {
        var parsed = CosmeticsMessageCodec.parse("0", "0,5,18");
        assertEquals(PetModels.IDS[0], parsed.pet());
        assertEquals(java.util.List.of(Accessories.IDS[0], Accessories.IDS[5], Accessories.IDS[18]), parsed.accessories());
    }

    @Test
    void acceptsNoPetAndNoAccessories() {
        var parsed = CosmeticsMessageCodec.parse("-1", "");
        assertNull(parsed.pet());
        assertTrue(parsed.accessories().isEmpty());
    }

    @Test
    void normalizesDuplicatesAndConflictingSlots() {
        var parsed = CosmeticsMessageCodec.parse("-1", "0,2,4,0");
        assertEquals(Accessories.normalize(java.util.List.of(
            Accessories.IDS[0], Accessories.IDS[2], Accessories.IDS[4], Accessories.IDS[0])), parsed.accessories());
    }

    @Test
    void rejectsMoreThanTwelveAccessories() {
        assertThrows(IllegalArgumentException.class, () -> CosmeticsMessageCodec.parse("-1",
            "0,1,2,3,4,5,6,7,8,9,10,11,12"));
    }

    @Test
    void rejectsOutOfRangeAndMalformedIndexes() {
        assertThrows(IllegalArgumentException.class, () -> CosmeticsMessageCodec.parse("999", ""));
        assertThrows(IllegalArgumentException.class, () -> CosmeticsMessageCodec.parse("-1", "99"));
        assertThrows(IllegalArgumentException.class, () -> CosmeticsMessageCodec.parse("-1", "1,,2"));
        assertThrows(IllegalArgumentException.class, () -> CosmeticsMessageCodec.parse("-2", ""));
    }
}
