package com.skinswitch.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.skinswitch.client.sync.PlayerLook;
import com.skinswitch.data.UiPrefs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** In-world cosmetic geometry. Meshes are built once and cached; no gameplay effects. */
public final class CosmeticsRenderer {
    private CosmeticsRenderer() {}

    private static final Identifier WHITE = Identifier.fromNamespaceAndPath("skinswitch", "textures/misc/cosmetic_white.png");
    private static final net.minecraft.client.renderer.rendertype.RenderType COSMETIC_RENDER_TYPE = RenderTypes.entityCutout(WHITE);
    private static final net.minecraft.client.renderer.rendertype.RenderType COSMETIC_GLOW_RENDER_TYPE = RenderTypes.entityTranslucent(WHITE);
    private static final float[][] UNIT = {{1,1,1},{1,1,1},{1,1,1},{1,1,1}};
    private static final Map<List<String>, Map<String, MeshSet[]>> ACCESSORY_CACHE = new ConcurrentHashMap<>();
    private static final Map<List<String>, Float> HAT_LIFT_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, PetMesh[]> PET_CACHE = new ConcurrentHashMap<>();
    private static final String NO_PET = "";
    private static final ThreadLocal<double[][]> PET_ANIMATION = ThreadLocal.withInitial(() -> new double[][]{new double[PetModels.ARRAY_SIZE], new double[PetModels.ARRAY_SIZE], new double[PetModels.ARRAY_SIZE]});

    private record V(float x, float y, float z, float nx, float ny, float nz) {}
    private record Quad(V a, V b, V c, V d, int color, boolean lit) {}
    private static final class Mesh {
        final Quad[] quads;
        private GeometryRenderer[] callbacks = new GeometryRenderer[4];
        private int callbackCount;
        Mesh(List<Quad> q) { quads = q.toArray(Quad[]::new); }
        boolean empty() { return quads.length == 0; }
        GeometryRenderer rendererFor(int light, boolean glow) {
            for (int i=0;i<callbackCount;i++)
                if (callbacks[i].light == light && callbacks[i].glow == glow) return callbacks[i];
            if (callbackCount == callbacks.length) callbacks = Arrays.copyOf(callbacks, callbacks.length * 2);
            GeometryRenderer renderer = new GeometryRenderer(this, light, glow);
            callbacks[callbackCount++] = renderer;
            return renderer;
        }
    }
    private static final class GeometryRenderer implements SubmitNodeCollector.CustomGeometryRenderer {
        final Mesh mesh;
        final int light;
        final boolean glow;
        GeometryRenderer(Mesh mesh, int light, boolean glow) { this.mesh=mesh; this.light=light; this.glow=glow; }
        @Override public void render(PoseStack.Pose entry, VertexConsumer buffer) {
            int pulse = glow ? 34 + (int)(10.0 * (0.5 + 0.5 * Math.sin(System.nanoTime() / 420_000_000.0))) : 255;
            for (Quad q : mesh.quads) {
                int packedLight = glow || q.lit ? 0x00F000F0 : light;
                int color = glow ? (pulse << 24) | (q.color & 0x00FFFFFF) : q.color;
                if (glow) {
                    emitGlow(buffer, entry, q.a, color);
                    emitGlow(buffer, entry, q.b, color);
                    emitGlow(buffer, entry, q.c, color);
                    emitGlow(buffer, entry, q.d, color);
                } else {
                    emit(buffer, entry, q.a, color, packedLight);
                    emit(buffer, entry, q.b, color, packedLight);
                    emit(buffer, entry, q.c, color, packedLight);
                    emit(buffer, entry, q.d, color, packedLight);
                }
            }
        }
    }
    private record MeshSet(Mesh head, Mesh body, Mesh arm) {}

    public static void submit(Player player, PlayerModel model, boolean slim, PoseStack pose, SubmitNodeCollector collector, int light, boolean firstPerson) {
        if (player == null || model == null || player.isInvisible() || player.isSpectator()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (player != mc.player && mc.player.distanceToSqr(player) > 48.0 * 48.0) return;

        List<String> accessories;
        String pet;
        if (player == mc.player) {
            UiPrefs prefs = UiPrefs.get();
            accessories = prefs.accessories();
            pet = prefs.pet();
        } else {
            PlayerLook.Cosmetics c = PlayerLook.cosmeticsFor(player.getUUID());
            if (c == null) return;
            accessories = c.accessories();
            pet = c.pet();
        }
        if (accessories.isEmpty() && pet == null) return;

        ItemStack head = player.getItemBySlot(EquipmentSlot.HEAD);
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
        boolean helmet = !head.isEmpty();
        boolean armor = helmet || !chest.isEmpty()
            || !player.getItemBySlot(EquipmentSlot.LEGS).isEmpty()
            || !player.getItemBySlot(EquipmentSlot.FEET).isEmpty();
        boolean elytra = chest.is(Items.ELYTRA);
        float petHeight = pet == null ? 0 : PetModels.height(pet);
        String petKey = pet == null ? NO_PET : pet;
        int variant = (slim ? 1 : 0) | (elytra ? 2 : 0);
        Map<String, MeshSet[]> byPet = ACCESSORY_CACHE.computeIfAbsent(accessories, k -> new ConcurrentHashMap<>());
        MeshSet[] variants = byPet.computeIfAbsent(petKey, k -> new MeshSet[4]);
        MeshSet meshes = variants[variant];
        if (meshes == null) {
            meshes = buildAccessories(accessories, slim, petHeight, elytra);
            variants[variant] = meshes;
        }
        pose.pushPose();
        try {
            if (!meshes.head.empty() && !firstPerson) {
                pose.pushPose();
                model.head.translateAndRotate(pose);
                if (armor) pose.translate(0, -0.035f, 0);
                if (hasFloatingAccessory(accessories)) {
                    float t = (System.nanoTime() % 120_000_000_000L) / 1_000_000_000f;
                    pose.translate(0, 0.008f + (float)Math.sin(t * 2.1f) * 0.012f, 0);
                    pose.rotate(Axis.YP, (float)Math.sin(t * 0.7f) * 0.035f);
                }
                submitAccessoryMesh(meshes.head, pose, collector, light);
                pose.popPose();
            }
            if (!meshes.body.empty()) {
                pose.pushPose();
                model.body.translateAndRotate(pose);
                if (armor) pose.translate(0, 0, 0.012f);
                submitAccessoryMesh(meshes.body, pose, collector, light);
                pose.popPose();
            }
            if (!meshes.arm.empty()) {
                pose.pushPose();
                model.rightArm.translateAndRotate(pose);
                submitAccessoryMesh(meshes.arm, pose, collector, light);
                pose.popPose();
            }
            if (pet != null && !firstPerson) {
                float lift = HAT_LIFT_CACHE.computeIfAbsent(accessories, Accessories::hatLift) + (armor ? 0.6f : 0f);
                int liftKey = Math.max(0, Math.min(90, Math.round(lift * 10)));
                PetMesh[] petVariants = PET_CACHE.computeIfAbsent(pet, k -> new PetMesh[91]);
                PetMesh pm = petVariants[liftKey];
                if (pm == null) petVariants[liftKey] = pm = buildPet(pet, 32f + 0.4f + lift);
                if (!pm.groups.isEmpty()) {
                    pose.pushPose();
                    model.head.translateAndRotate(pose);
                    double[][] anim = PET_ANIMATION.get();
                    Arrays.fill(anim[0], 0); Arrays.fill(anim[1], 0); Arrays.fill(anim[2], 0);
                    float time = (System.nanoTime() % 120_000_000_000L) / 1_000_000_000f;
                    PetModels.animate(pet, time, 0, anim[0], anim[1], anim[2]);
                    for (PetGroup group : pm.groups) {
                        int part = group.part;
                        double px = group.px / 16.0, py = -(group.py - 24f) / 16.0, pz = -group.pz / 16.0;
                        pose.pushPose();
                        pose.translate(px, py, pz);
                        if (anim[1][part] != 0) pose.rotate(Axis.ZP, (float)-anim[1][part]);
                        if (anim[0][part] != 0) pose.rotate(Axis.XP, (float)anim[0][part]);
                        pose.translate(-px, -py, -pz);
                        if (anim[2][part] != 0) pose.translate(0, (float)-anim[2][part] / 16f, 0);
                        submitMesh(group.mesh, pose, collector, light);
                        pose.popPose();
                    }
                    pose.popPose();
                }
            }
        } finally {
            pose.popPose();
        }
    }

    private static MeshSet buildAccessories(List<String> ids, boolean slim, float petHeight, boolean elytra) {
        List<String> buildIds = ids;
        if (elytra && ids.contains("royal_cape")) {
            ArrayList<String> filtered = new ArrayList<>(ids);
            filtered.remove("royal_cape");
            buildIds = List.copyOf(filtered);
        }
        Accessories.ABox[] boxes = Accessories.build(buildIds, UNIT, slim, petHeight);
        List<Quad> h = new ArrayList<>(), b = new ArrayList<>(), a = new ArrayList<>();
        for (Accessories.ABox box : boxes) {
            List<Quad> target = box.part == Accessories.HEAD ? h : box.part == Accessories.BODY ? b : a;
            appendAccessory(box, target, slim);
        }
        return new MeshSet(new Mesh(h), new Mesh(b), new Mesh(a));
    }

    private static void appendAccessory(Accessories.ABox box, List<Quad> out, boolean slim) {
        float[][] corners = {
            {box.x0,box.y0,box.z0},{box.x1,box.y0,box.z0},{box.x1,box.y1,box.z0},{box.x0,box.y1,box.z0},
            {box.x0,box.y0,box.z1},{box.x1,box.y0,box.z1},{box.x1,box.y1,box.z1},{box.x0,box.y1,box.z1}
        };
        int[][] faces = {{0,3,2,1},{5,6,7,4},{4,7,3,0},{1,2,6,5},{3,7,6,2},{4,0,1,5}};
        int[][] normals = {{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,1,0},{0,-1,0}};
        int[] axis = {2,2,0,0,1,1}, sign = {-1,1,-1,1,1,-1};
        for (int f=0; f<6; f++) {
            float[] p0=corners[faces[f][0]], p1=corners[faces[f][1]], p3=corners[faces[f][3]];
            int nu=Math.max(1,(int)Math.ceil(distance(p0,p1))), nv=Math.max(1,(int)Math.ceil(distance(p0,p3)));
            for(int iy=0;iy<nv;iy++) for(int ix=0;ix<nu;ix++) {
                float u0=ix/(float)nu,u1=(ix+1)/(float)nu,v0=iy/(float)nv,v1=(iy+1)/(float)nv;
                float[] pA=bilinear(p0,p1,p3,u0,v0), pB=bilinear(p0,p1,p3,u1,v0);
                float[] pC=bilinear(p0,p1,p3,u1,v1), pD=bilinear(p0,p1,p3,u0,v1);
                float hx=(pA[0]+pB[0]+pC[0]+pD[0])*.25f, hy=(pA[1]+pB[1]+pC[1]+pD[1])*.25f, hz=(pA[2]+pB[2]+pC[2]+pD[2])*.25f;
                int color=box.color(axis[f],sign[f],hx,hy,hz);
                V a=accessoryVertex(box,pA,normals[f],slim), b=accessoryVertex(box,pB,normals[f],slim);
                V c=accessoryVertex(box,pC,normals[f],slim), d=accessoryVertex(box,pD,normals[f],slim);
                out.add(new Quad(a,b,c,d,color,box.lit));
            }
        }
    }

    private static float distance(float[] a,float[] b) {
        float x=a[0]-b[0], y=a[1]-b[1], z=a[2]-b[2];
        return (float)Math.sqrt(x*x+y*y+z*z);
    }
    private static float[] bilinear(float[] p0,float[] p1,float[] p3,float u,float v) {
        return new float[]{p0[0]+(p1[0]-p0[0])*u+(p3[0]-p0[0])*v,
            p0[1]+(p1[1]-p0[1])*u+(p3[1]-p0[1])*v,
            p0[2]+(p1[2]-p0[2])*u+(p3[2]-p0[2])*v};
    }
    private static V accessoryVertex(Accessories.ABox box,float[] p,int[] normal,boolean slim) {
        float[] q=rotate(box,p[0],p[1],p[2]);
        float nx=normal[0],ny=normal[1],nz=normal[2];
        if(box.tiltF!=null){
            double[][] m=box.tiltF;
            float ox=(float)(m[0][0]*nx+m[0][1]*ny+m[0][2]*nz);
            float oy=(float)(m[1][0]*nx+m[1][1]*ny+m[1][2]*nz);
            float oz=(float)(m[2][0]*nx+m[2][1]*ny+m[2][2]*nz);
            nx=ox;ny=oy;nz=oz;
        }
        float localX = box.part == Accessories.RARM ? q[0] + 5f : q[0] - box.px;
        float localY = -(q[1] - box.py) - (box.part == Accessories.RARM && slim ? 0.5f : 0f);
        return new V(localX/16f,localY/16f,-(q[2]-box.pz)/16f,nx,-ny,-nz);
    }

    private static float[] rotate(Accessories.ABox b, float x, float y, float z) {
        if (b.tiltF == null) return new float[]{x,y,z};
        double dx=x-b.tcx, dy=y-b.tcy, dz=z-b.tcz;
        double[][] m=b.tiltF;
        return new float[]{(float)(b.tcx+m[0][0]*dx+m[0][1]*dy+m[0][2]*dz),
            (float)(b.tcy+m[1][0]*dx+m[1][1]*dy+m[1][2]*dz),
            (float)(b.tcz+m[2][0]*dx+m[2][1]*dy+m[2][2]*dz)};
    }

    private record PivotKey(int part, int px, int py, int pz) {}
    private record PetGroup(int part, float px, float py, float pz, Mesh mesh) {}
    private record PetMesh(List<PetGroup> groups) {}

    private static PetMesh buildPet(String id, float baseY) {
        PetModels.PBox[] boxes = PetModels.build(id, baseY);
        Map<PivotKey, List<Quad>> grouped = new HashMap<>();
        Map<PivotKey, float[]> pivots = new HashMap<>();
        int[][] faces={{0,3,2,1},{5,6,7,4},{4,7,3,0},{1,2,6,5},{3,7,6,2},{4,0,1,5}};
        int[][] normals={{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,1,0},{0,-1,0}};
        int[] ax={2,2,0,0,1,1}, sg={-1,1,-1,1,1,-1};
        for (PetModels.PBox box : boxes) {
            PivotKey key=new PivotKey(box.part,Float.floatToIntBits(box.px),Float.floatToIntBits(box.py),Float.floatToIntBits(box.pz));
            List<Quad> out=grouped.computeIfAbsent(key,k->new ArrayList<>());
            pivots.putIfAbsent(key,new float[]{box.px,box.py,box.pz});
            float[][] c={{box.x0,box.y0,box.z0},{box.x1,box.y0,box.z0},{box.x1,box.y1,box.z0},{box.x0,box.y1,box.z0},
                {box.x0,box.y0,box.z1},{box.x1,box.y0,box.z1},{box.x1,box.y1,box.z1},{box.x0,box.y1,box.z1}};
            for(int k=0;k<6;k++){
                float[] p0=c[faces[k][0]],p1=c[faces[k][1]],p3=c[faces[k][3]];
                int nu=Math.max(1,(int)Math.ceil(distance(p0,p1))),nv=Math.max(1,(int)Math.ceil(distance(p0,p3)));
                for(int iy=0;iy<nv;iy++) for(int ix=0;ix<nu;ix++){
                    float u0=ix/(float)nu,u1=(ix+1)/(float)nu,v0=iy/(float)nv,v1=(iy+1)/(float)nv;
                    float[] pa=bilinear(p0,p1,p3,u0,v0),pb=bilinear(p0,p1,p3,u1,v0);
                    float[] pc=bilinear(p0,p1,p3,u1,v1),pd=bilinear(p0,p1,p3,u0,v1);
                    float hx=(pa[0]+pb[0]+pc[0]+pd[0])*.25f,hy=(pa[1]+pb[1]+pc[1]+pd[1])*.25f,hz=(pa[2]+pb[2]+pc[2]+pd[2])*.25f;
                    int col=box.color(ax[k],sg[k],hx,hy,hz,0.5f);
                    V a=petVertex(pa,normals[k]),b=petVertex(pb,normals[k]),cc=petVertex(pc,normals[k]),d=petVertex(pd,normals[k]);
                    out.add(new Quad(a,b,cc,d,col,false));
                }
            }
        }
        List<PetGroup> result=new ArrayList<>();
        for(var e:grouped.entrySet()){
            float[] v=pivots.get(e.getKey());
            result.add(new PetGroup(e.getKey().part,v[0],v[1],v[2],new Mesh(e.getValue())));
        }
        return new PetMesh(List.copyOf(result));
    }

    private static V petVertex(float[] p,int[] n) {
        return new V(p[0]/16f,-(p[1]-24f)/16f,-p[2]/16f,n[0],-n[1],-n[2]);
    }

    private static boolean hasFloatingAccessory(List<String> ids) {
        for (String id : ids) {
            if (id.equals("halo") || id.equals("head_star") || id.equals("mini_planet")
                || id.equals("floating_crystal") || id.equals("geo_halo")) return true;
        }
        return false;
    }

    private static void submitAccessoryMesh(Mesh mesh, PoseStack pose, SubmitNodeCollector collector, int light) {
        submitMesh(mesh, pose, collector, light);
        // A slightly enlarged, full-bright translucent shell creates a soft self-coloured aura.
        pose.pushPose();
        pose.scale(1.025f, 1.025f, 1.025f);
        collector.submitCustomGeometry(pose, COSMETIC_GLOW_RENDER_TYPE, mesh.rendererFor(light, true));
        pose.popPose();
    }

    /** Pet rendering deliberately stays on its original, unchanged path. */
    private static void submitMesh(Mesh mesh, PoseStack pose, SubmitNodeCollector collector, int light) {
        collector.submitCustomGeometry(pose, COSMETIC_RENDER_TYPE, mesh.rendererFor(light, false));
    }

    private static void emitGlow(VertexConsumer out, PoseStack.Pose pose, V v, int color) {
        float expansion = 0.012f;
        out.addVertex(pose, v.x + v.nx * expansion, v.y + v.ny * expansion, v.z + v.nz * expansion)
            .setColor(color).setUv(.5f,.5f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(0x00F000F0)
            .setNormal(pose, v.nx, v.ny, v.nz);
    }

    private static void emit(VertexConsumer out, PoseStack.Pose pose, V v, int color, int light) {
        out.addVertex(pose, v.x, v.y, v.z).setColor(color).setUv(.5f,.5f)
            .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, v.nx, v.ny, v.nz);
    }
}
