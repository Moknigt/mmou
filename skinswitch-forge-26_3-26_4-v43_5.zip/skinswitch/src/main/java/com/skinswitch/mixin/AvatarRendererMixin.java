package com.skinswitch.mixin;

import com.skinswitch.client.ScaledRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import com.skinswitch.client.BodyScale;
import com.skinswitch.client.sync.PlayerLook;
import com.skinswitch.data.UiPrefs;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class AvatarRendererMixin {
    /** Remember who this render state is for, and keep the name tag above the (taller / shorter) head. */
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void skinswitch$onExtract(Avatar avatar, AvatarRenderState state, float partialTick, CallbackInfo ci) {
        ((ScaledRenderState) state).skinswitch$setPlayerUuid(avatar.getUUID());
        float[] s = BodyScale.forPlayer(avatar.getUUID());
        Vec3 tag = state.nameTagAttachment;
        if (s != null && tag != null) {
            float dy = BodyScale.nameTagOffset(s);
            if (dy != 0f) state.nameTagAttachment = tag.add(0, dy, 0);
        }
        // custom display name chosen by that player (only replaces a name tag that vanilla already decided to show)
        String shown = PlayerLook.nameFor(avatar.getUUID());
        if (shown != null && state.nameTag != null) state.nameTag = Component.literal(shown); // API-RISK: EntityRenderState.nameTag in 26.3 / 26.4
    }

    /** First-person arm / held-hand scale. */
    @Inject(method = "renderHand", at = @At("HEAD"))
    private void skinswitch$onRenderHand(PoseStack pose, SubmitNodeCollector collector, int light, Identifier skin,
                                         ModelPart arm, boolean sleeve, CallbackInfo ci) {
        UiPrefs p = UiPrefs.get();
        if (p.scaleHand()) pose.scale(p.scale(UiPrefs.ARMS, 0), p.scale(UiPrefs.ARMS, 1), p.scale(UiPrefs.ARMS, 2));
    }
}
