package com.skinswitch.mixin;

import com.skinswitch.client.ScaledRenderState;
import com.skinswitch.client.BodyScale;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scales head / torso / arms / legs of the real player model and moves the parts so the body stays connected. */
@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V", at = @At("TAIL"))
    private void skinswitch$applyBodyScales(AvatarRenderState state, CallbackInfo ci) {
        float[] s = BodyScale.forPlayer(((ScaledRenderState) state).skinswitch$getPlayerUuid());
        if (s == null) return;
        PlayerModel m = (PlayerModel) (Object) this;
        float hx = s[0], hy = s[1], hz = s[2];
        float ax = s[3], ay = s[4], az = s[5];
        float tx = s[6], ty = s[7], tz = s[8];
        float lx = s[9], ly = s[10], lz = s[11];

        float legShift = -12f * (ly - 1f);           // legs longer -> everything above moves up
        float torsoShift = -12f * (ty - 1f);         // torso taller -> head and arms move up
        float armSpread = 4f * (tx - 1f) + 2f * (ax - 1f);
        float legSpread = 2f * (tx - 1f);

        set(m.head, hx, hy, hz);
        set(m.body, tx, ty, tz);
        set(m.rightArm, ax, ay, az); set(m.leftArm, ax, ay, az);
        set(m.rightLeg, lx, ly, lz); set(m.leftLeg, lx, ly, lz);

        float up = legShift + torsoShift;
        float headY = (state.isCrouching ? 4.2f : 0f) + up;
        float armY = (state.isCrouching ? 6.2f : 2f) + up;
        m.head.y = headY;
        m.body.y = headY;
        m.rightArm.y = armY; m.leftArm.y = armY;
        m.rightLeg.y = 12f + legShift; m.leftLeg.y = 12f + legShift;
        m.rightArm.x = -5f - armSpread; m.leftArm.x = 5f + armSpread;
        m.rightLeg.x = -1.9f - legSpread; m.leftLeg.x = 1.9f + legSpread;
    }

    private static void set(ModelPart p, float x, float y, float z) { p.xScale = x; p.yScale = y; p.zScale = z; }
}
