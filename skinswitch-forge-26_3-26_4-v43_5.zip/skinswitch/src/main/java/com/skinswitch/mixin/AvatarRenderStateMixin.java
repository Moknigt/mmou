package com.skinswitch.mixin;

import com.skinswitch.client.ScaledRenderState;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.UUID;

@Mixin(AvatarRenderState.class)
public abstract class AvatarRenderStateMixin implements ScaledRenderState {
    @Unique private UUID skinswitch$uuid;

    @Override public void skinswitch$setPlayerUuid(UUID id) { this.skinswitch$uuid = id; }
    @Override public UUID skinswitch$getPlayerUuid() { return skinswitch$uuid; }
}
