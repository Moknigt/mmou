package com.skinswitch.mixin;

import com.skinswitch.client.ScaledRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import com.skinswitch.render.CosmeticsRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hooks the 26.3 submit implementation inherited by AvatarRenderer, immediately before it restores the entity pose. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "submit", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"))
    private void skinswitch$submitCosmetics(LivingEntityRenderState baseState, PoseStack pose,
                                             SubmitNodeCollector collector, CameraRenderState camera,
                                             CallbackInfo ci) {
        if (!((Object) this instanceof AvatarRenderer<?> renderer) || !(baseState instanceof AvatarRenderState state)) return;
        if (state.isInvisible || state.isInvisibleToPlayer || state.isSpectator) return;
        var id = ((ScaledRenderState) state).skinswitch$getPlayerUuid();
        if (id == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Player player = mc.level.getPlayerByUUID(id);
        if (player == null || player.isInvisible() || player.isSpectator()) return;
        boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
        PlayerModel model = (PlayerModel) renderer.getModel();
        boolean slim = state.skin.model() == PlayerModelType.SLIM;
        CosmeticsRenderer.submit(player, model, slim, pose, collector, state.lightCoords, firstPerson);
    }
}
