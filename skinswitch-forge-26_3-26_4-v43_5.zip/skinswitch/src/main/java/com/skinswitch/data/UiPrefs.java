package com.skinswitch.data;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * User display settings, saved in <game dir>/skinswitch/ui.properties:
 *  - where the character is shown (left/right) and how big, separately for the title screen and the in-game menus
 *  - body proportions (head / torso / arms / legs, each with width / height / depth)
 */
public final class UiPrefs {
    public static final int HEAD = 0, TORSO = 1, ARMS = 2, LEGS = 3;
    public static final int W = 0, H = 1, D = 2;
    public static final float MIN_PART = 0.5f, MAX_PART = 2.0f, MIN_SIZE = 0.5f, MAX_SIZE = 1.6f;
    private static final String[] PART_KEYS = {"head", "torso", "arms", "legs"}, AXIS_KEYS = {"w", "h", "d"};

    private static UiPrefs instance;

    public static UiPrefs get() {
        if (instance == null) instance = new UiPrefs(Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch").resolve("ui.properties"));
        return instance;
    }

    private final Path file;
    private final Properties p = new Properties();
    private java.util.List<String> accessoriesCache;

    private UiPrefs(Path file) {
        this.file = file;
        if (Files.exists(file)) try (var in = Files.newInputStream(file)) { p.load(in); } catch (IOException ignored) {}
    }

    private float num(String key, float def, float min, float max) {
        try { return Math.max(min, Math.min(max, Float.parseFloat(p.getProperty(key, Float.toString(def))))); }
        catch (NumberFormatException e) { return def; }
    }

    // ---- character display (title = title screen, otherwise pause / options) --------------------------------------
    public boolean rightSide(boolean title) { return Boolean.parseBoolean(p.getProperty((title ? "title" : "menu") + ".right", "true")); }
    public void setRightSide(boolean title, boolean right) { p.setProperty((title ? "title" : "menu") + ".right", Boolean.toString(right)); save(); }
    public float size(boolean title) { return num((title ? "title" : "menu") + ".size", 1f, MIN_SIZE, MAX_SIZE); }
    public void setSize(boolean title, float v) { p.setProperty((title ? "title" : "menu") + ".size", Float.toString(v)); save(); }
    public void resetDisplay(boolean title) {
        p.remove((title ? "title" : "menu") + ".right"); p.remove((title ? "title" : "menu") + ".size"); save();
    }

    // ---- body proportions -----------------------------------------------------------------------------------------
    public float scale(int part, int axis) { return num("scale." + PART_KEYS[part] + "." + AXIS_KEYS[axis], 1f, MIN_PART, MAX_PART); }
    public void setScale(int part, int axis, float v) { p.setProperty("scale." + PART_KEYS[part] + "." + AXIS_KEYS[axis], Float.toString(v)); save(); }
    public void resetPart(int part) { for (int a = 0; a < 3; a++) p.remove("scale." + PART_KEYS[part] + "." + AXIS_KEYS[a]); save(); }
    public void resetAllParts() { for (int i = 0; i < 4; i++) resetPart(i); }

    /** [part][axis] snapshot for the renderer. */
    public float[][] scales() {
        float[][] s = new float[4][3];
        for (int i = 0; i < 4; i++) for (int a = 0; a < 3; a++) s[i][a] = scale(i, a);
        return s;
    }

    // ---- in-game options (body proportions) ------------------------------------------------------------------------
    /** Camera / eye height follows the body height. */
    public boolean cameraFollows() { return Boolean.parseBoolean(p.getProperty("body.camera", "true")); }
    public void setCameraFollows(boolean v) { p.setProperty("body.camera", Boolean.toString(v)); save(); }
    /** First-person hand/arm uses the arm scale. */
    public boolean scaleHand() { return Boolean.parseBoolean(p.getProperty("body.hand", "true")); }
    public void setScaleHand(boolean v) { p.setProperty("body.hand", Boolean.toString(v)); save(); }

    // ---- pet that sits on the character's head (preview) -----------------------------------------------------------
    /** Id of the chosen pet (see PetModels.IDS), or null for none. */
    public String pet() {
        String id = p.getProperty("pet", "none");
        return com.skinswitch.render.PetModels.exists(id) ? id : null;
    }
    public void setPet(String id) { p.setProperty("pet", id == null ? "none" : id); save(); }
    /** Next pet in the list: none -> first -> ... -> last -> none (dir = +1 / -1). */
    public void cyclePet(int dir) {
        String[] ids = com.skinswitch.render.PetModels.IDS;
        String cur = pet();
        int i = cur == null ? -1 : java.util.Arrays.asList(ids).indexOf(cur);
        int n = ids.length + 1, next = ((i + 1 + dir) % n + n) % n - 1; // -1 = none
        setPet(next < 0 ? null : ids[next]);
    }

    // ---- cosmetic accessories worn on the character (see render/Accessories.java) ------------------------------------
    /** Ids of the worn accessories (catalogue order, no conflicting pieces). Saved per player: this file lives in the player's own game folder. */
    public java.util.List<String> accessories() {
        if (accessoriesCache == null) accessoriesCache = com.skinswitch.render.Accessories.parse(p.getProperty("acc", ""));
        return accessoriesCache;
    }
    public boolean wearing(String id) { return accessories().contains(id); }
    /** Puts an accessory on / takes it off (putting one on removes the pieces it would overlap). Returns the new list. */
    public java.util.List<String> toggleAccessory(String id) {
        java.util.List<String> l = com.skinswitch.render.Accessories.toggle(accessories(), id);
        setAccessories(l);
        return l;
    }
    public void setAccessories(java.util.List<String> ids) {
        accessoriesCache = com.skinswitch.render.Accessories.normalize(ids);
        String v = com.skinswitch.render.Accessories.join(accessoriesCache);
        if (v.isEmpty()) p.remove("acc"); else p.setProperty("acc", v);
        save();
    }
    public void clearAccessories() { setAccessories(java.util.List.of()); }

    // ---- display name shown over your head to friends who have Skin Switch ----------------------------------------
    public static final int NAME_MAX = 20;
    /** The custom name friends see above your head, or null = your normal name. */
    public String displayName() {
        String n = clean(p.getProperty("display.name", ""));
        return n.isEmpty() ? null : n;
    }
    public void setDisplayName(String name) {
        String n = clean(name == null ? "" : name);
        if (n.isEmpty()) p.remove("display.name"); else p.setProperty("display.name", n);
        save();
    }
    /** Trims, drops control characters and the section sign (colour codes) and limits the length. */
    public static String clean(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c >= ' ' && c != '\u00a7' && c != 127) sb.append(c); }
        String t = sb.toString().trim();
        return t.length() > NAME_MAX ? t.substring(0, NAME_MAX).trim() : t;
    }

    // ---- zoom preference (persistent across key releases and game restarts) --------------------------------------
    public double zoomLevel() {
        try { return Math.max(1.0, Math.min(50.0, Double.parseDouble(p.getProperty("zoom.level", "4.0")))); }
        catch (NumberFormatException e) { return 4.0; }
    }
    public void setZoomLevel(double value) {
        double v = Math.max(1.0, Math.min(50.0, value));
        p.setProperty("zoom.level", Double.toString(v));
        save();
    }

    // ---- night vision (client side) ----------------------------------------------------------------------------------
    public boolean nightVision() { return Boolean.parseBoolean(p.getProperty("nightvision", "false")); }
    public void setNightVision(boolean v) { p.setProperty("nightvision", Boolean.toString(v)); save(); }

    private void save() {
        try {
            Files.createDirectories(file.getParent());
            try (var out = Files.newOutputStream(file)) { p.store(out, "Skin Switch display settings"); }
        } catch (IOException ignored) {}
    }
}
