package com.skinswitch.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.skinswitch.SkinSwitchMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Small compatibility layer for Minecraft / Forge calls whose names changed in 26.3 (screen handling, action-bar text,
 * key types, scroll delta, file dialog). Everything is looked up once by shape (parameter / return types), so the mod
 * keeps compiling and working even if a method got renamed. If a lookup fails it logs what it found instead of crashing.
 */
public final class Compat {
    private Compat() {}

    // ------------------------------------------------------------------------------------------------------------
    // reflection helpers
    // ------------------------------------------------------------------------------------------------------------

    private static List<Method> allMethods(Class<?> c) {
        List<Method> out = new ArrayList<>();
        for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) {
                if (Modifier.isStatic(m.getModifiers()) || m.isSynthetic() || m.isBridge()) continue;
                try { m.trySetAccessible(); } catch (RuntimeException ignored) { }
                out.add(m);
            }
        }
        return out;
    }

    private static List<Field> allFields(Class<?> c) {
        List<Field> out = new ArrayList<>();
        for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                try { f.trySetAccessible(); } catch (RuntimeException ignored) { }
                out.add(f);
            }
        }
        return out;
    }

    /** Objects that may own the "current screen" logic: the Minecraft instance, its Gui, then its other client objects. */
    private static List<Object> holders(Minecraft mc) {
        List<Object> out = new ArrayList<>();
        out.add(mc);
        if (mc.gui != null) out.add(mc.gui);
        for (Field f : allFields(Minecraft.class)) {
            try {
                Object v = f.get(mc);
                if (v != null && !out.contains(v) && v.getClass().getName().startsWith("net.minecraft.client")) out.add(v);
            } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------------------------
    // current screen / open a screen
    // ------------------------------------------------------------------------------------------------------------

    private static boolean screenResolved;
    private static Object setOwner, getOwner;
    private static Method setScreenM, getScreenM;
    private static Field screenField;

    private static synchronized void resolveScreen() {
        if (screenResolved) return;
        screenResolved = true;
        Minecraft mc = Minecraft.getInstance();
        List<Object> hs = holders(mc);

        // setter: void xxx(Screen)
        outer:
        for (int pass = 0; pass < 2; pass++) {
            for (Object h : hs) {
                for (Method m : allMethods(h.getClass())) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length != 1 || p[0] == Object.class || !p[0].isAssignableFrom(Screen.class)) continue;
                    String n = m.getName().toLowerCase();
                    boolean ok = pass == 0 ? n.equals("setscreen") : (n.contains("screen") && !n.contains("reset"));
                    if (ok) { setOwner = h; setScreenM = m; break outer; }
                }
            }
        }
        // getter: Screen xxx()  or a Screen field
        outer2:
        for (int pass = 0; pass < 3; pass++) {
            for (Object h : hs) {
                if (pass < 2) {
                    for (Method m : allMethods(h.getClass())) {
                        if (m.getParameterCount() != 0 || !Screen.class.isAssignableFrom(m.getReturnType())) continue;
                        String n = m.getName().toLowerCase();
                        boolean ok = pass == 0 ? (n.equals("screen") || n.equals("getscreen") || n.equals("currentscreen")) : n.contains("screen");
                        if (ok) { getOwner = h; getScreenM = m; break outer2; }
                    }
                } else {
                    for (Field f : allFields(h.getClass())) {
                        if (Screen.class.isAssignableFrom(f.getType()) && f.getName().toLowerCase().contains("screen")) {
                            getOwner = h; screenField = f; break outer2;
                        }
                    }
                }
            }
        }
        if (setScreenM == null || (getScreenM == null && screenField == null)) {
            SkinSwitchMod.LOGGER.error("[SkinSwitch] Could not find the screen API. set={} get={}", setScreenM, getScreenM != null ? getScreenM : screenField);
            for (Object h : hs) {
                for (Method m : allMethods(h.getClass())) {
                    if (m.getParameterCount() <= 1 && (m.getName().toLowerCase().contains("screen")))
                        SkinSwitchMod.LOGGER.error("[SkinSwitch]   candidate {}#{}", h.getClass().getName(), m);
                }
            }
        } else {
            SkinSwitchMod.LOGGER.info("[SkinSwitch] screen API: set={}#{} get={}", setOwner.getClass().getSimpleName(), setScreenM.getName(),
                getScreenM != null ? getScreenM.getName() : screenField.getName());
        }
    }

    /** The screen that is open right now (null while playing). */
    public static Screen screen() {
        resolveScreen();
        try {
            if (getScreenM != null) return (Screen) getScreenM.invoke(getOwner);
            if (screenField != null) return (Screen) screenField.get(getOwner);
        } catch (ReflectiveOperationException | RuntimeException e) {
            SkinSwitchMod.LOGGER.error("[SkinSwitch] screen() failed", e);
        }
        return null;
    }

    /** Opens a screen (null = back to the game). */
    public static void setScreen(Screen s) {
        resolveScreen();
        if (setScreenM == null) return;
        try {
            setScreenM.invoke(setOwner, s);
        } catch (ReflectiveOperationException | RuntimeException e) {
            SkinSwitchMod.LOGGER.error("[SkinSwitch] setScreen failed", e);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // action-bar / overlay text
    // ------------------------------------------------------------------------------------------------------------

    private static boolean overlayResolved;
    private static Object overlayOwner;
    private static Method overlayM;

    private static synchronized void resolveOverlay(Minecraft mc) {
        if (overlayResolved) return;
        overlayResolved = true;
        Object[] owners = { mc.gui, mc.player };
        for (int pass = 0; pass < 3 && overlayM == null; pass++) {
            for (Object h : owners) {
                if (h == null || overlayM != null) continue;
                Method best = null;
                for (Method m : allMethods(h.getClass())) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 0 || p.length > 2 || !p[0].isAssignableFrom(Component.class) || p[0] == Object.class) continue;
                    if (p.length == 2 && p[1] != boolean.class) continue;
                    String n = m.getName().toLowerCase();
                    boolean ok = switch (pass) {
                        case 0 -> n.contains("overlay");
                        case 1 -> n.contains("actionbar") || n.contains("action_bar") || n.equals("displayclientmessage");
                        default -> n.equals("sendsystemmessage");
                    };
                    if (ok && (best == null || p.length < best.getParameterCount())) best = m;
                }
                if (best != null) { overlayOwner = h; overlayM = best; }
            }
        }
        if (overlayM == null) SkinSwitchMod.LOGGER.warn("[SkinSwitch] no action-bar message method found; messages are skipped");
    }

    /** Shows a short text above the hotbar (falls back to chat if there is no action bar). */
    public static void overlayMessage(Component text) {
        Minecraft mc = Minecraft.getInstance();
        resolveOverlay(mc);
        if (overlayM == null) return;
        try {
            Object target = overlayOwner;
            // the player / gui object can be replaced (new world), so look the owner up again by type
            if (target != null && mc.player != null && overlayOwner.getClass() == mc.player.getClass()) target = mc.player;
            if (overlayM.getParameterCount() == 2) overlayM.invoke(target, text, !overlayM.getName().toLowerCase().contains("setoverlay"));
            else overlayM.invoke(target, text);
        } catch (ReflectiveOperationException | RuntimeException e) {
            SkinSwitchMod.LOGGER.error("[SkinSwitch] overlayMessage failed", e);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // key mappings
    // ------------------------------------------------------------------------------------------------------------

    private static Object keyboardType() {
        Class<?> t = InputConstants.Type.class;
        Object[] consts = t.getEnumConstants();
        if (consts != null && consts.length > 0) {
            for (Object c : consts) if (((Enum<?>) c).name().equals("KEYSYM")) return c;
            for (Object c : consts) {
                String n = ((Enum<?>) c).name();
                if (n.contains("KEY") && !n.contains("SCAN")) return c;
            }
            return consts[0];
        }
        for (Field f : t.getFields()) {
            if (!Modifier.isStatic(f.getModifiers()) || !t.isAssignableFrom(f.getType())) continue;
            String n = f.getName().toUpperCase();
            if (n.contains("KEY") && !n.contains("SCAN")) {
                try { return f.get(null); } catch (ReflectiveOperationException ignored) { }
            }
        }
        return null;
    }

    /** Creates a keyboard KeyMapping whatever the constructor looks like in this version. */
    public static KeyMapping key(String name, int keyCode, KeyMapping.Category category) {
        Object type = keyboardType();
        for (Constructor<?> c : KeyMapping.class.getConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            Object[] a = new Object[p.length];
            boolean ok = true, usedName = false;
            for (int i = 0; i < p.length && ok; i++) {
                if (p[i] == String.class && !usedName) { a[i] = name; usedName = true; }
                else if (type != null && p[i] != Object.class && p[i].isInstance(type)) a[i] = type;
                else if (p[i] == int.class) a[i] = keyCode;
                else if (p[i] != Object.class && p[i].isInstance(category)) a[i] = category;
                else if (type != null && p[i].getName().endsWith("InputConstants$Key")) {
                    try { a[i] = type.getClass().getMethod("getOrCreate", int.class).invoke(type, keyCode); }
                    catch (ReflectiveOperationException e) { ok = false; }
                }
                else ok = false;
            }
            if (!ok || !usedName) continue;
            try { return (KeyMapping) c.newInstance(a); } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
        throw new IllegalStateException("SkinSwitch: no usable KeyMapping constructor found");
    }

    // ------------------------------------------------------------------------------------------------------------
    // mouse wheel
    // ------------------------------------------------------------------------------------------------------------

    private static Class<?> scrollClass;
    private static Method scrollM;

    /** Vertical scroll amount of a mouse-scroll event (positive = wheel up). */
    public static double scrollY(Object event) {
        if (event == null) return 0;
        if (scrollM == null || scrollClass != event.getClass()) {
            scrollClass = event.getClass();
            scrollM = null;
            String[] wanted = { "getscrolldeltay", "getdeltay", "scrolldeltay", "deltay", "getscrolly", "scrolly", "getyoffset", "yoffset" };
            List<Method> ms = allMethods(event.getClass());
            for (String w : wanted) {
                for (Method m : ms) {
                    if (m.getParameterCount() == 0 && m.getName().toLowerCase().equals(w) && (m.getReturnType() == double.class || m.getReturnType() == float.class)) { scrollM = m; break; }
                }
                if (scrollM != null) break;
            }
            if (scrollM == null) {
                for (Method m : ms) {
                    String n = m.getName().toLowerCase();
                    if (m.getParameterCount() == 0 && (m.getReturnType() == double.class || m.getReturnType() == float.class) && n.contains("y")) { scrollM = m; break; }
                }
            }
            if (scrollM == null) SkinSwitchMod.LOGGER.error("[SkinSwitch] no scroll getter found on {}", event.getClass().getName());
        }
        try {
            if (scrollM != null) return ((Number) scrollM.invoke(event)).doubleValue();
        } catch (ReflectiveOperationException | RuntimeException e) {
            SkinSwitchMod.LOGGER.error("[SkinSwitch] scrollY failed", e);
        }
        return 0;
    }

    // ------------------------------------------------------------------------------------------------------------
    // native file picker (tinyfd is not on the compile classpath any more, but ships with the game at runtime)
    // ------------------------------------------------------------------------------------------------------------

    /** Opens the system "choose PNG files" dialog. Returns the paths joined with '|', or null if cancelled / unavailable. */
    public static String openFileDialog(String title) {
        try {
            ClassLoader cl = Minecraft.class.getClassLoader();
            Class<?> tfd = Class.forName("org.lwjgl.util.tinyfd.TinyFileDialogs", true, cl);
            Class<?> pb = Class.forName("org.lwjgl.PointerBuffer", true, cl);
            Method m = tfd.getMethod("tinyfd_openFileDialog", CharSequence.class, CharSequence.class, pb, CharSequence.class, boolean.class);
            return (String) m.invoke(null, title, "", null, "PNG images", Boolean.TRUE);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException e) {
            SkinSwitchMod.LOGGER.warn("[SkinSwitch] native file dialog unavailable ({}); drag & drop PNG files into the screen instead", e.toString());
            return null;
        }
    }
}
