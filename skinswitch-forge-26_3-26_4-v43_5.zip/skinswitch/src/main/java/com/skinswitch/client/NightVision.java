package com.skinswitch.client;

import com.skinswitch.data.UiPrefs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.ChatFormatting;

/**
 * Client-side night vision: keeps an invisible, icon-less Night Vision effect on you while it is switched on, so you can
 * see in the dark on any server (vanilla / LAN / online) without commands. Toggle with the button in the top-right
 * corner of the pause menu / title screen / options, or with the N key (changeable in Controls).
 */
public final class NightVision {
    private NightVision() {}

    public static boolean on() { return UiPrefs.get().nightVision(); }

    public static void toggle() {
        boolean now = !on();
        UiPrefs.get().setNightVision(now);
        Minecraft mc = Minecraft.getInstance();
        if (!now) remove(mc);
        else apply(mc);
        if (mc.player != null)
            Compat.overlayMessage(Component.translatable("skinswitch.nv.title").append(Component.literal(": "))
                .append(Component.translatable(now ? "skinswitch.body.on" : "skinswitch.body.off")));
    }

    /** Called every client tick. */
    public static void tick(Minecraft mc) {
        if (mc.player != null && on() && mc.player.tickCount % 20 == 0) apply(mc);
    }

    private static void apply(Minecraft mc) {
        if (mc.player == null) return;
        // 600 ticks, refreshed every second: never reaches the "about to run out" flicker
        mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0, false, false, false)); // API-RISK: Holder<MobEffect> ctor in 26.3
    }

    private static void remove(Minecraft mc) {
        if (mc.player == null) return;
        MobEffectInstance e = mc.player.getEffect(MobEffects.NIGHT_VISION);
        // only remove OUR effect (invisible), never a real potion / beacon night vision
        if (e != null && !e.isVisible() && !e.showIcon()) mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }

    private static Component label() {
        return Component.literal("NV").withStyle(on() ? ChatFormatting.GREEN : ChatFormatting.GRAY);
    }

    private static Tooltip tip() {
        return Tooltip.create(Component.translatable("skinswitch.nv.title").append(Component.literal(": "))
            .append(Component.translatable(on() ? "skinswitch.body.on" : "skinswitch.body.off"))
            .append(Component.literal("\n")).append(Component.translatable("skinswitch.nv.desc").withStyle(ChatFormatting.GRAY)));
    }

    /** The small square button for the top-right corner of a screen. */
    public static Button button(int x, int y) {
        return Button.builder(label(), b -> { toggle(); b.setMessage(label()); b.setTooltip(tip()); })
            .bounds(x, y, 22, 20).tooltip(tip()).build();
    }
}
