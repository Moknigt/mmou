package com.skinswitch.client;

import com.skinswitch.SkinSwitchMod;
import com.skinswitch.data.CapeEditorModel;
import com.skinswitch.data.CapeEntry;
import com.skinswitch.data.CapeLibrary;
import com.skinswitch.data.SkinEditorModel;
import com.skinswitch.render.CapeImage;
import com.skinswitch.render.PreviewRenderer;
import com.skinswitch.render.SkinImage;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Cape editor (opened by the "Create Cape" button of the capes view).
 * Left: Cape / Elytra, elytra Auto / Manual, tools, colour picker. Centre: the selected texture part unfolded (1:1 with the
 * cape PNG). Right: live 3D preview wearing your cape (drag to spin). Save writes a new PNG into skinswitch/capes.
 */
public class CapeEditorScreen extends Screen {
    private static final int BG = 0xF00E1116, PANEL = 0xFF2B2F38, EDGE = 0xFF8B93A5, WHITE = 0xFFFFFFFF, GOLD = 0xFFFFD040;
    private static final int LX = 8, LW = 124, PW = 96, PH = 176;
    private static final String[][] FACE_KEYS = {{"top", "bottom", "side", "outer", "side", "inner"}, {"top", "bottom", "side", "front", "side", "back"}};

    private static final String[] I_PENCIL = {"......##.", ".....###.", "....###..", "...###...", "..###....", ".###.....", "###......", "##......."};
    private static final String[] I_ERASER = {"...######", "..#######", ".##....##", "##....##.", "#....##..", "#######..", "######..."};
    private static final String[] I_BUCKET = {"..###....", ".#...#...", ".#...#...", "#######..", "#######.#", "#######.#", ".#####..#", ".#####..."};
    private static final String[] I_PICK = {"......###", ".....#.##", "....###.#", "...###...", "..###....", ".###.....", "###......"};
    private static final String[] I_UNDO = {"...#.....", "..##.....", ".#######.", "..##...##", "...#....#", "........#", "....####."};
    private static final String[] I_REDO = {".....#...", ".....##..", ".#######.", "##...##..", "#....#...", "#........", ".####...."};
    private static final String[] I_SYM = {"....#....", "..#.#.#..", ".##.#.##.", "###.#.###", ".##.#.##.", "..#.#.#..", "....#...."};
    private record IconBtn(Button b, String[] rows) {}
    private final List<IconBtn> icons = new ArrayList<>();

    private final Screen parent;
    private final CapeLibrary lib;
    private final CapeEditorModel m = new CapeEditorModel();
    private final BufferedImage startCape;
    private final boolean slimSkin;
    private final Consumer<String> onSaved;
    private SkinImage skin;

    // editor state
    private int part = CapeEditorModel.CAPE, tool = CapeEditorModel.PENCIL, brush = 1;
    private boolean symmetry;
    private int color = 0x3B8EEA;
    private float hue, sat, val;
    private final List<Integer> recents = new ArrayList<>(List.of(0xC0392B, 0x1A1A1A, 0xF2F2F2, 0xF5C542, 0x3FB950, 0x3B8EEA, 0x8E44AD, 0xE67E22));

    // widgets
    private final Button[] partBtns = new Button[2], toolBtns = new Button[4];
    private Button undoBtn, redoBtn, symBtn, brushBtn, autoBtn;
    private EditBox hexBox, nameBox;
    private String lastHex = "", savedName = "my_cape";
    private boolean lastAuto = true;

    // layout
    private int svX, svY, svW, svH, hueY, hexY, recY;
    private int canvasX, canvasY, canvasScale = 1;
    private int cx0, cy0, cx1, cy1, prevX, prevY;
    private float prevScale = 1f;

    // interaction
    private boolean painting, svDrag, hueDrag, previewDrag, lastValid;
    private int lastNx, lastNy, hoverX, hoverY;
    private float dragYaw = 160f, swayFactor = 1f, time;
    private long lastNanos = System.nanoTime();
    private CapeImage previewCape;
    private int previewVersion = -1;

    public CapeEditorScreen(Screen parent, BufferedImage skinImage, boolean slimSkin, BufferedImage startCape, Consumer<String> onSaved) {
        super(Component.translatable("skinswitch.cape_editor.title"));
        this.parent = parent; this.slimSkin = slimSkin; this.startCape = startCape; this.onSaved = onSaved;
        lib = new CapeLibrary(Minecraft.getInstance().gameDirectory.toPath().resolve("skinswitch"));
        try { lib.load(); } catch (IOException e) { SkinSwitchMod.LOGGER.error("Cannot load capes", e); }
        try { skin = SkinImage.from(skinImage != null ? skinImage : new SkinEditorModel().toImage()); } catch (IOException e) { skin = null; }
        setColor(color, true);
    }

    // ---- setup ---------------------------------------------------------------------------------------------------
    @Override
    protected void init() {
        icons.clear();
        int half = (LW - 4) / 2, y = 22;
        for (int i = 0; i < 2; i++) {
            final int p = i;
            partBtns[i] = addRenderableWidget(Button.builder(partLabel(i), b -> { part = p; refreshLabels(); })
                .bounds(LX + i * (half + 4), y, half, 20).build());
        }
        autoBtn = addRenderableWidget(Button.builder(Component.empty(), b -> { m.setAutoElytra(!m.autoElytra()); refreshLabels(); })
            .bounds(LX, 46, LW, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.cape_editor.elytra.desc"))).build());
        int tw = (LW - 9) / 4;
        String[] toolKeys = {"pencil", "erase", "fill", "pick"};
        String[][] toolIcons = {I_PENCIL, I_ERASER, I_BUCKET, I_PICK};
        y = 72;
        for (int i = 0; i < 4; i++) {
            final int t = i;
            toolBtns[i] = addRenderableWidget(Button.builder(Component.empty(), b -> { tool = t; refreshLabels(); })
                .bounds(LX + i * (tw + 3), y, tw, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.cape_editor.tool." + toolKeys[i]))).build());
            icons.add(new IconBtn(toolBtns[i], toolIcons[i]));
        }
        y = 100;
        undoBtn = addRenderableWidget(Button.builder(Component.empty(), b -> m.undo()).bounds(LX, y, tw, 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.editor.undo"))).build());
        redoBtn = addRenderableWidget(Button.builder(Component.empty(), b -> m.redo()).bounds(LX + (tw + 3), y, tw, 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.editor.redo"))).build());
        symBtn = addRenderableWidget(Button.builder(Component.empty(), b -> { symmetry = !symmetry; refreshLabels(); }).bounds(LX + 2 * (tw + 3), y, tw, 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.cape_editor.sym"))).build());
        brushBtn = addRenderableWidget(Button.builder(Component.literal("1"), b -> { brush = brush % 3 + 1; refreshLabels(); }).bounds(LX + 3 * (tw + 3), y, tw, 20)
            .tooltip(Tooltip.create(Component.translatable("skinswitch.editor.brush"))).build());
        icons.add(new IconBtn(undoBtn, I_UNDO)); icons.add(new IconBtn(redoBtn, I_REDO)); icons.add(new IconBtn(symBtn, I_SYM));
        y = 126;
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.editor.blank"), b -> { m.blank(); refreshLabels(); }).bounds(LX, y, half, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.cape_editor.from_cape"), b -> {
            if (startCape != null) { m.loadFrom(startCape.getSubimage(0, 0, 64, 32)); refreshLabels(); } // step 2: first frame only
        }).bounds(LX + half + 4, y, half, 20).tooltip(Tooltip.create(Component.translatable("skinswitch.cape_editor.from_cape.desc"))).build());

        svX = LX; svW = LW; svY = 152;
        int fixed = 4 + 10 + 4 + 18 + 4 + 12;
        svH = Math.max(28, Math.min(90, height - svY - 8 - fixed));
        hueY = svY + svH + 4; hexY = hueY + 14; recY = hexY + 22;
        String keep = hexBox == null ? String.format("#%06X", color) : hexBox.getValue();
        hexBox = new EditBox(font, LX + 22, hexY, LW - 22, 18, Component.translatable("skinswitch.editor.hex"));
        hexBox.setMaxLength(7);
        hexBox.setValue(keep); lastHex = hexBox.getValue();
        addRenderableWidget(hexBox);

        int by = height - 26, saveW = 80, cancelW = 64, saveX = width - 8 - saveW, cancelX = saveX - 4 - cancelW, nameX = LX + LW + 10;
        if (nameBox != null) savedName = nameBox.getValue();
        nameBox = new EditBox(font, nameX, by, Math.max(80, cancelX - 4 - nameX), 20, Component.translatable("skinswitch.cape_editor.name_hint"));
        nameBox.setHint(Component.translatable("skinswitch.cape_editor.name_hint"));
        nameBox.setMaxLength(24);
        nameBox.setValue(savedName);
        addRenderableWidget(nameBox);
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.editor.cancel"), b -> onClose()).bounds(cancelX, by, cancelW, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("skinswitch.editor.save").withStyle(ChatFormatting.GREEN), b -> save()).bounds(saveX, by, saveW, 20).build());

        prevScale = Math.max(0.5f, Math.min(2f, (height - 26 - 8 - 22) / (float) PH));
        prevX = Math.round(width - 8 - PW * prevScale); prevY = 22;
        cx0 = LX + LW + 10; cx1 = prevX - 10; cy0 = 34; cy1 = height - 26 - 18;
        refreshLabels();
    }

    private Component partLabel(int p) {
        return Component.translatable(p == 0 ? "skinswitch.cape_editor.part.cape" : "skinswitch.cape_editor.part.elytra")
            .withStyle(p == part ? ChatFormatting.GOLD : ChatFormatting.WHITE);
    }

    private void refreshLabels() {
        for (int i = 0; i < 2; i++) if (partBtns[i] != null) partBtns[i].setMessage(partLabel(i));
        if (brushBtn != null) brushBtn.setMessage(Component.literal(Integer.toString(brush)));
        if (autoBtn != null) {
            lastAuto = m.autoElytra();
            autoBtn.setMessage(Component.translatable(lastAuto ? "skinswitch.cape_editor.elytra.auto" : "skinswitch.cape_editor.elytra.manual"));
        }
    }

    // ---- colour --------------------------------------------------------------------------------------------------
    private void setColor(int rgb, boolean updateHsv) {
        color = rgb & 0xFFFFFF;
        if (!updateHsv) return;
        float[] hsb = Color.RGBtoHSB((color >> 16) & 255, (color >> 8) & 255, color & 255, null);
        if (hsb[1] > 0.001f && hsb[2] > 0.001f) hue = hsb[0];
        sat = hsb[1]; val = hsb[2];
    }

    private void syncHex() {
        if (hexBox == null) return;
        hexBox.setValue(String.format("#%06X", color)); lastHex = hexBox.getValue();
    }

    private void pollHex() {
        if (hexBox == null) return;
        String v = hexBox.getValue();
        if (v.equals(lastHex)) return;
        lastHex = v;
        String h = v.startsWith("#") ? v.substring(1) : v;
        if (h.length() != 6) return;
        try { setColor(Integer.parseInt(h, 16), true); } catch (NumberFormatException ignored) {}
    }

    private void applySv(double mx, double my) {
        sat = (float) Math.max(0, Math.min(1, (mx - svX) / (svW - 1)));
        val = 1f - (float) Math.max(0, Math.min(1, (my - svY) / (svH - 1)));
        color = Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF; syncHex();
    }

    private void applyHue(double mx) {
        hue = (float) Math.max(0, Math.min(0.999, (mx - svX) / (svW - 1)));
        color = Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF; syncHex();
    }

    private void rememberColor() {
        recents.remove((Integer) color);
        recents.add(0, color);
        while (recents.size() > 8) recents.remove(recents.size() - 1);
    }

    // ---- drawing -------------------------------------------------------------------------------------------------
    private static void outline(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int c) {
        g.fill(x0, y0, x1, y0 + 1, c); g.fill(x0, y1 - 1, x1, y1, c);
        g.fill(x0, y0, x0 + 1, y1, c); g.fill(x1 - 1, y0, x1, y1, c);
    }

    private static void drawIcon(GuiGraphicsExtractor g, String[] rows, int cx, int cy, int scale, int c) {
        int w = rows[0].length() * scale, h = rows.length * scale, x0 = cx - w / 2, y0 = cy - h / 2;
        for (int r = 0; r < rows.length; r++)
            for (int k = 0; k < rows[r].length(); k++)
                if (rows[r].charAt(k) == '#') g.fill(x0 + k * scale, y0 + r * scale, x0 + (k + 1) * scale, y0 + (r + 1) * scale, c);
    }

    private static int over(int top, int bottom) {
        int a = top >>> 24;
        if (a >= 255) return top;
        if (a == 0) return bottom;
        int r = (((top >> 16) & 255) * a + ((bottom >> 16) & 255) * (255 - a)) / 255;
        int gg = (((top >> 8) & 255) * a + ((bottom >> 8) & 255) * (255 - a)) / 255;
        int b = ((top & 255) * a + (bottom & 255) * (255 - a)) / 255;
        return 0xFF000000 | r << 16 | gg << 8 | b;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) { // API-RISK: name/signature in 26.3
        long now = System.nanoTime();
        float dt = (now - lastNanos) / 1e9f; lastNanos = now; time += dt;
        swayFactor += ((previewDrag ? 0f : 1f) - swayFactor) * Math.min(1f, dt * 4f);
        hoverX = mouseX; hoverY = mouseY;
        pollHex();
        if (m.autoElytra() != lastAuto) refreshLabels(); // painting the wing by hand flips Auto -> Manual
        undoBtn.active = m.canUndo(); redoBtn.active = m.canRedo();

        g.fill(0, 0, width, height, BG);
        g.text(font, Component.translatable("skinswitch.cape_editor.title"), LX, 8, WHITE, true);
        drawCanvas(g);
        drawColorPicker(g);
        drawPreview(g);
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        for (int i = 0; i < 4; i++) if (i == tool) outline(g, toolBtns[i].getX() - 1, toolBtns[i].getY() - 1, toolBtns[i].getX() + toolBtns[i].getWidth() + 1, toolBtns[i].getY() + toolBtns[i].getHeight() + 1, GOLD);
        if (symmetry) outline(g, symBtn.getX() - 1, symBtn.getY() - 1, symBtn.getX() + symBtn.getWidth() + 1, symBtn.getY() + symBtn.getHeight() + 1, GOLD);
        for (IconBtn ib : icons)
            drawIcon(g, ib.rows(), ib.b().getX() + ib.b().getWidth() / 2, ib.b().getY() + ib.b().getHeight() / 2, 2, ib.b().active ? WHITE : 0xFF6B7080);
    }

    private void drawCanvas(GuiGraphicsExtractor g) {
        int nw = m.netW(part), nh = m.netH(part);
        int sc = Math.max(2, Math.min(24, Math.min((cx1 - cx0) / nw, (cy1 - cy0) / nh)));
        int ox = cx0 + ((cx1 - cx0) - nw * sc) / 2, oy = cy0 + ((cy1 - cy0) - nh * sc) / 2;
        canvasX = ox; canvasY = oy; canvasScale = sc;

        int[] arr = new int[nw * nh];
        for (int ny = 0; ny < nh; ny++) for (int nx = 0; nx < nw; nx++) {
            int c;
            if (m.faceAt(part, nx, ny) < 0) c = ((nx + ny) & 1) == 0 ? 0xFF14161B : 0xFF1B1E25; // unused corner of the cape PNG
            else c = over(m.pixel(part, nx, ny), ((nx + ny) & 1) == 0 ? 0xFFC9CCD2 : 0xFFA9ADB6);
            arr[ny * nw + nx] = c;
        }
        g.fill(ox - 3, oy - 3, ox + nw * sc + 3, oy + nh * sc + 3, PANEL);
        PixelPainter.draw(g, arr, nw, nh, ox, oy, sc);
        if (sc >= 6) {
            for (int i = 1; i < nw; i++) g.fill(ox + i * sc, oy, ox + i * sc + 1, oy + nh * sc, 0x30000000);
            for (int j = 1; j < nh; j++) g.fill(ox, oy + j * sc, ox + nw * sc, oy + j * sc + 1, 0x30000000);
        }
        CapeEditorModel.Rect[] faces = m.faces(part);
        for (int fi = 0; fi < faces.length; fi++) {
            var f = faces[fi];
            outline(g, ox + f.x() * sc, oy + f.y() * sc, ox + (f.x() + f.w()) * sc, oy + (f.y() + f.h()) * sc, 0xCC000000);
            if (f.w() * sc < 18 && f.h() * sc >= 18 && part == CapeEditorModel.CAPE) continue; // 1px cape sides: no room for a label
            int lx = ox + Math.round((f.x() + f.w() / 2f) * sc), ly = fi < 2 ? oy - 12 : oy + nh * sc + 5;
            g.centeredText(font, Component.translatable("skinswitch.editor.face." + FACE_KEYS[part][fi]), lx, ly, 0xFFAAB0C0);
        }
        int hx = (int) Math.floor((hoverX - ox) / (double) sc), hy = (int) Math.floor((hoverY - oy) / (double) sc);
        if (hoverX >= ox && hoverY >= oy && hx >= 0 && hy >= 0 && hx < nw && hy < nh && m.faceAt(part, hx, hy) >= 0)
            outline(g, ox + hx * sc, oy + hy * sc, ox + (hx + 1) * sc, oy + (hy + 1) * sc, WHITE);
    }

    private void drawColorPicker(GuiGraphicsExtractor g) {
        int cols = Math.max(2, svW / 4), rows = Math.max(2, svH / 4);
        for (int i = 0; i < cols; i++) {
            int x0 = svX + i * svW / cols, x1 = svX + (i + 1) * svW / cols;
            float s = i / (float) (cols - 1);
            for (int j = 0; j < rows; j++) {
                int y0 = svY + j * svH / rows, y1 = svY + (j + 1) * svH / rows;
                g.fill(x0, y0, x1, y1, Color.HSBtoRGB(hue, s, 1f - j / (float) (rows - 1)));
            }
        }
        int mx = svX + Math.round(sat * (svW - 1)), my = svY + Math.round((1f - val) * (svH - 1));
        outline(g, mx - 3, my - 3, mx + 4, my + 4, 0xFF000000); outline(g, mx - 2, my - 2, mx + 3, my + 3, WHITE);
        for (int i = 0; i < cols; i++)
            g.fill(svX + i * svW / cols, hueY, svX + (i + 1) * svW / cols, hueY + 10, Color.HSBtoRGB(i / (float) cols, 1f, 1f));
        int hx = svX + Math.round(hue * (svW - 1));
        g.fill(hx - 1, hueY - 2, hx + 2, hueY + 12, 0xFF000000); g.fill(hx, hueY - 1, hx + 1, hueY + 11, WHITE);
        g.fill(LX - 1, hexY - 1, LX + 19, hexY + 19, EDGE);
        g.fill(LX, hexY, LX + 18, hexY + 18, 0xFF000000 | color);
        int sw = LW / 8;
        for (int k = 0; k < recents.size(); k++) {
            int x = LX + k * sw;
            if (recents.get(k) == color) g.fill(x - 1, recY - 1, x + sw - 1, recY + 13, WHITE);
            g.fill(x, recY, x + sw - 2, recY + 12, 0xFF000000 | recents.get(k));
        }
    }

    private void drawPreview(GuiGraphicsExtractor g) {
        if (previewCape == null || m.version() != previewVersion) {
            previewCape = new CapeImage(m.toImage());
            previewVersion = m.version();
        }
        g.fill(prevX - 2, prevY - 2, prevX + Math.round(PW * prevScale) + 2, prevY + Math.round(PH * prevScale) + 2, 0x33000000);
        if (skin == null) return;
        float yaw = dragYaw + (float) Math.sin(time * 0.7) * 14f * swayFactor;
        int[] px = PreviewRenderer.render(skin, previewCape, slimSkin, yaw, time, PW, PH, null, 0, null, part == CapeEditorModel.ELYTRA); // Elytra tab = wings on the back
        PixelPainter.drawScaled(g, px, PW, PH, prevX, prevY, prevScale);
    }

    // ---- input ---------------------------------------------------------------------------------------------------
    private boolean overPreview(double mx, double my) {
        return mx >= prevX && mx < prevX + PW * prevScale && my >= prevY && my < prevY + PH * prevScale;
    }

    private int[] cellAt(double mx, double my) {
        int nx = (int) Math.floor((mx - canvasX) / canvasScale), ny = (int) Math.floor((my - canvasY) / canvasScale);
        if (mx < canvasX || my < canvasY || nx < 0 || ny < 0 || nx >= m.netW(part) || ny >= m.netH(part)) return null;
        return new int[]{nx, ny};
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) { // API-RISK: signature in 26.3
        if (super.mouseClicked(event, doubleClick)) return true;
        double mx = event.x(), my = event.y();
        if (mx >= svX && mx < svX + svW && my >= svY && my < svY + svH) { svDrag = true; applySv(mx, my); return true; }
        if (mx >= svX && mx < svX + svW && my >= hueY && my < hueY + 10) { hueDrag = true; applyHue(mx); return true; }
        if (my >= recY && my < recY + 12 && mx >= LX) {
            int k = (int) ((mx - LX) / (LW / 8));
            if (k >= 0 && k < recents.size()) { setColor(recents.get(k), true); syncHex(); return true; }
        }
        if (overPreview(mx, my)) { previewDrag = true; return true; }
        int[] cell = cellAt(mx, my);
        if (cell != null) { startPaint(cell[0], cell[1]); return true; }
        return false;
    }

    private void startPaint(int nx, int ny) {
        if (tool == CapeEditorModel.PICKER) {
            int c = m.pick(part, nx, ny);
            if (c >= 0) { setColor(c, true); syncHex(); }
            tool = CapeEditorModel.PENCIL; refreshLabels();
            return;
        }
        m.beginStroke();
        if (tool == CapeEditorModel.FILL) { m.fill(part, nx, ny, color); m.endStroke(); rememberColor(); return; }
        if (tool == CapeEditorModel.PENCIL) rememberColor();
        painting = true; lastValid = true; lastNx = nx; lastNy = ny;
        m.paint(part, nx, ny, tool, color, brush, symmetry);
    }

    private void strokeTo(int nx, int ny) {
        int x = lastNx, y = lastNy, dx = Math.abs(nx - x), dy = Math.abs(ny - y), sx = x < nx ? 1 : -1, sy = y < ny ? 1 : -1, err = dx - dy;
        while (true) { // Bresenham so fast mouse moves leave no gaps
            m.paint(part, x, y, tool, color, brush, symmetry);
            if (x == nx && y == ny) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x += sx; }
            if (e2 < dx) { err += dx; y += sy; }
        }
        lastNx = nx; lastNy = ny;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) { // API-RISK: signature in 26.3
        if (svDrag) { applySv(event.x(), event.y()); return true; }
        if (hueDrag) { applyHue(event.x()); return true; }
        if (previewDrag) { dragYaw += (float) dragX * 1.2f; return true; }
        if (painting) {
            int[] cell = cellAt(event.x(), event.y());
            if (cell == null) lastValid = false;
            else if (lastValid) strokeTo(cell[0], cell[1]);
            else { lastValid = true; lastNx = cell[0]; lastNy = cell[1]; m.paint(part, cell[0], cell[1], tool, color, brush, symmetry); }
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) { // API-RISK: signature in 26.3
        if (painting || svDrag || hueDrag || previewDrag) {
            if (painting) m.endStroke();
            painting = svDrag = hueDrag = previewDrag = false;
            return true;
        }
        return super.mouseReleased(event);
    }

    private void save() {
        savedName = nameBox.getValue().trim();
        try {
            CapeEntry e = lib.saveNew(savedName, m.toImage());
            onSaved.accept(e.id());
            Compat.setScreen(parent);
        } catch (IOException ex) { SkinSwitchMod.LOGGER.error("Cannot save cape", ex); }
    }

    @Override
    public void onClose() { Compat.setScreen(parent); }
}
