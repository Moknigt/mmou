package com.skinswitch.client;

import com.skinswitch.SkinSwitchMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;

/** Hotkey (default I, changeable in Controls) that opens the skin screen while you are playing. */
public final class KeyBindings {
    // API-RISK: KeyMapping.Category / Identifier factory names in 26.3
    private static final KeyMapping.Category CATEGORY =
        KeyMapping.Category.register(Identifier.fromNamespaceAndPath(SkinSwitchMod.MODID, "main"));
    public static final KeyMapping OPEN = Compat.key("key.skinswitch.open", -1, CATEGORY);

    /** Hold to zoom (mouse wheel changes the level, up to 50x). */
    public static final KeyMapping ZOOM = Compat.key("key.skinswitch.zoom", 67, CATEGORY);
    /** Toggle client-side night vision. */
    public static final KeyMapping NIGHT_VISION = Compat.key("key.skinswitch.night_vision", -1, CATEGORY);

    private KeyBindings() {}

    public static void register() {
        RegisterKeyMappingsEvent.BUS.addListener(e -> { e.register(OPEN); e.register(ZOOM); e.register(NIGHT_VISION); });
        Zoom.register();
        TickEvent.ClientTickEvent.Post.BUS.addListener(e -> {
            Minecraft mc = Minecraft.getInstance();
            while (OPEN.consumeClick()) {
                if (Compat.screen() == null && mc.player != null) Compat.setScreen(new SkinScreen(null));
            }
            while (NIGHT_VISION.consumeClick()) { if (Compat.screen() == null && mc.player != null) NightVision.toggle(); }
            NightVision.tick(mc);
        });
    }
}
