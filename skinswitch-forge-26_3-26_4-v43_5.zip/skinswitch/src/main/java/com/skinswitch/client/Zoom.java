package com.skinswitch.client;

import net.minecraft.client.Minecraft;
import com.skinswitch.data.UiPrefs;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;

/**
 * Hold C (changeable in Controls) to zoom in the game; the mouse wheel changes the zoom from 1x up to 50x (the hotbar
 * does not scroll while you zoom). Mouse sensitivity is lowered while zoomed so aiming stays controllable, and put back
 * when you let go.
 */
public final class Zoom {
    private Zoom() {}

    public static final double MIN = 1.0, MAX = 50.0, START = 4.0, STEP = 1.2;
    private static double level = Double.NaN; // loaded lazily from the saved user preference
    private static double shown = 1.0;         // zoom actually applied; eases smoothly in/out
    private static Double savedSensitivity;   // sensitivity before zooming (null = untouched)
    private static boolean wasActive;

    private static void ensureLoaded() {
        if (Double.isNaN(level)) level = UiPrefs.get().zoomLevel();
    }

    private static boolean active(Minecraft mc) {
        return mc.player != null && Compat.screen() == null && KeyBindings.ZOOM.isDown();
    }

    /** Current zoom factor for the info text / HUD (1 = none). */
    public static double current() { return shown; }

    public static void register() {
        // smooth FOV change, every frame
        ViewportEvent.ComputeFov.BUS.addListener(e -> { // smooth ramp instead of snapping to the selected zoom
            ensureLoaded();
            double target = active(Minecraft.getInstance()) ? level : 1.0;
            // 0.075 per frame gives a short, visible ~0.5-0.7s ease-in/out at normal frame rates.
            shown += (target - shown) * 0.075;
            if (Math.abs(target - shown) < 0.01) shown = target;
            if (shown > 1.001) e.setFOV((float) (e.getFOV() / shown));
        });
        // wheel = zoom level (cancel the hotbar scroll)
        InputEvent.MouseScrollingEvent.BUS.addListener((InputEvent.MouseScrollingEvent e) -> { // API-RISK: cancellable bus listener shape in 26.3
            if (!active(Minecraft.getInstance())) return false;
            ensureLoaded();
            double dy = Compat.scrollY(e);
            if (dy != 0) {
                level = Math.max(MIN, Math.min(MAX, dy > 0 ? level * STEP : level / STEP));
                UiPrefs.get().setZoomLevel(level);
            }
            return true; // cancelled
        });
        TickEvent.ClientTickEvent.Post.BUS.addListener(e -> tick(Minecraft.getInstance()));
    }

    private static void tick(Minecraft mc) {
        ensureLoaded();
        boolean on = active(mc);
        var sens = mc.options.sensitivity(); // API-RISK: OptionInstance<Double> accessor in 26.3
        if (on) {
            if (savedSensitivity == null) savedSensitivity = sens.get();
            sens.set(Math.max(0.0, savedSensitivity / Math.sqrt(Math.max(1.0, shown))));
        } else if (savedSensitivity != null) {
            sens.set(savedSensitivity);
            savedSensitivity = null;
        }
        // Keep the chosen level when C is released; only the visual zoom eases back to 1x.
        if (on && mc.player != null && (!wasActive || mc.player.tickCount % 10 == 0))
            Compat.overlayMessage(net.minecraft.network.chat.Component.literal(String.format("%.1fx", level)));
        wasActive = on;
    }
}
